import { getFirestore, doc, setDoc, onSnapshot, collection, serverTimestamp } from 'firebase/firestore';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { CALIBRATOR_STORAGE_KEY } from '../calibration/MasterRegistryV2';
import firebaseConfig from '../../firebase-applet-config.json';

const TENANT_ID = 'CCMI-DR-SAMIR';

class FirestoreStationerySyncService {
  private isInitialized = false;
  private db: any = null;

  private async getDb() {
    if (!this.db) {
      const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig as any);
      this.db = getFirestore(app, (firebaseConfig as any).firestoreDatabaseId);
    }
    return this.db;
  }

  public async initialize() {
    if (this.isInitialized) return;
    this.isInitialized = true;
    try {
      await this.getDb();
      this.subscribeToCloudCalibration();
      await this.pushLocalCalibrationToCloud();
    } catch (e: any) {
      console.warn('[SYNAPSIS SYNC] Inicialización en modo offline resiliente:', e?.message || e);
    }
  }

  public subscribeToCloudCalibration() {
    try {
      const db = this.db;
      if (!db) return;
      const calDocRef = doc(db, 'tenants', TENANT_ID, 'settings', 'calibration');
      onSnapshot(calDocRef, (snap) => {
        if (snap.exists()) {
          const data = snap.data();
          if (data && data.map && localStorage.getItem(CALIBRATOR_STORAGE_KEY) !== data.map) {
            console.log('[SYNAPSIS SYNC] Descargando calibraciones de la nube Firestore...');
            localStorage.setItem(CALIBRATOR_STORAGE_KEY, data.map);
            if (typeof window !== 'undefined') {
              window.dispatchEvent(new CustomEvent('medical_template_calibrated', { detail: { docType: 'all' } }));
            }
          }
        }
      }, (err) => {
        console.warn('[SYNAPSIS SYNC] Error escuchando calibraciones de Firestore:', err);
      });
    } catch (err) {
      console.warn('[SYNAPSIS SYNC] Error suscribiendo a calibraciones:', err);
    }
  }

  public async pushLocalCalibrationToCloud() {
    try {
      const localMap = typeof window !== 'undefined' ? localStorage.getItem(CALIBRATOR_STORAGE_KEY) : null;
      if (localMap) {
        // 1. Sincronización al servidor en disco
        try {
          await fetch('/api/calibrations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rawMap: localMap }),
          });
        } catch (fetchErr) {
          // Servidor local offline o en preview
        }

        // 2. Sincronización a Firestore
        const db = await this.getDb();
        const calDocRef = doc(db, 'tenants', TENANT_ID, 'settings', 'calibration');
        await setDoc(calDocRef, {
          map: localMap,
          updatedAt: serverTimestamp(),
        }, { merge: true });
      } else {
        // Si el cliente no tiene datos locales, intentar descargar del servidor en disco
        try {
          const res = await fetch('/api/calibrations');
          const data = await res.json();
          if (data && data.rawMap && typeof window !== 'undefined' && !localStorage.getItem(CALIBRATOR_STORAGE_KEY)) {
            localStorage.setItem(CALIBRATOR_STORAGE_KEY, data.rawMap);
            window.dispatchEvent(new CustomEvent('medical_template_calibrated', { detail: { docType: 'all' } }));
          }
        } catch (pullErr) {
          // Continuar con valores por defecto
        }
      }
    } catch (err: any) {
      console.warn('[SYNAPSIS SYNC] Modo offline resiliente (se preservan copias locales):', err?.message || err);
    }
  }

  public async uploadSingleTemplateToCloud(docType: string, templateData: any) {
    try {
      const db = await this.getDb();
      const tmplDocRef = doc(db, 'tenants', TENANT_ID, 'stationery', docType);
      await setDoc(tmplDocRef, {
        ...templateData,
        updatedAt: serverTimestamp(),
      }, { merge: true });
    } catch (err: any) {
      console.warn('[SYNAPSIS SYNC] Error subiendo plantilla:', err?.message || err);
    }
  }
}

export const FirestoreStationerySync = new FirestoreStationerySyncService();
