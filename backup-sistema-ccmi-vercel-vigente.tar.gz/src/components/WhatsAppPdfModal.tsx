import React, { useState, useEffect } from 'react';
import {
  X,
  Share2,
  CheckCircle2,
  Phone,
  Loader2,
  ExternalLink,
  QrCode,
  Smartphone,
  Copy,
  Check,
  Download,
  AlertCircle,
  FileCheck,
} from 'lucide-react';
import { DocType, PatientData } from '../types';
import {
  DOCUMENT_DEFINITIONS,
  generateCanonicalDocumentPDF,
  ClinicalDataBundle,
  buildWhatsAppMessage,
  formatWhatsAppPhone,
  sanitizeFileName,
  uploadPdfForSharing,
} from '../utils/pdfExport';
import { OfficialQrCode } from './OfficialQrCode';

interface WhatsAppPdfModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeDoc: DocType;
  patient: PatientData;
  setActiveDoc?: (doc: DocType) => void;
  clinicalDataBundle?: ClinicalDataBundle;
}

export const WhatsAppPdfModal: React.FC<WhatsAppPdfModalProps> = ({
  isOpen,
  onClose,
  activeDoc,
  patient,
  clinicalDataBundle,
}) => {
  const [phoneNumber, setPhoneNumber] = useState(patient.phone || '0424-912.44.81');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processStep, setProcessStep] = useState<string>('');
  const [delivered, setDelivered] = useState(false);
  const [publicPdfUrl, setPublicPdfUrl] = useState<string | null>(null);
  const [whatsappUniversalUrl, setWhatsappUniversalUrl] = useState<string>('');
  const [whatsappWebUrl, setWhatsappWebUrl] = useState<string>('');
  const [showQrCode, setShowQrCode] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeMessage, setActiveMessage] = useState<string>('');
  const [deliveryError, setDeliveryError] = useState<string | null>(null);

  const activeDef = DOCUMENT_DEFINITIONS?.[activeDoc] || {
    shortName: 'Documento',
    label: 'Documento Médico',
    filenamePrefix: 'DOC',
  };

  // Cada vez que se abre el modal, resetear y disparar entrega directa si se desea
  useEffect(() => {
    if (isOpen) {
      setPhoneNumber(patient.phone || '0424-912.44.81');
      setDelivered(false);
      setPublicPdfUrl(null);
      setShowQrCode(false);
      setCopied(false);
      setDeliveryError(null);
      // Auto-iniciar la preparación veloz
      handleFastDelivery(patient.phone || '0424-912.44.81');
    }
  }, [isOpen, activeDoc, patient.idNumber]);

  const handleFastDelivery = async (targetPhone: string) => {
    setIsProcessing(true);
    setProcessStep('Preparando documento PDF oficial...');
    setDeliveryError(null);

    try {
      const patientSafeName = sanitizeFileName(patient.fullName || 'Paciente');
      const fileName = `${activeDef.filenamePrefix}_${patientSafeName}.pdf`;

      // 1. Generación canónica 300 DPI
      const result = await generateCanonicalDocumentPDF(
        activeDoc,
        patient,
        clinicalDataBundle || {},
        fileName
      );

      // 2. Descarga local automática silenciosa de respaldo
      try {
        const localUrl = URL.createObjectURL(result.file);
        const a = document.createElement('a');
        a.href = localUrl;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(localUrl), 10000);
      } catch (e) {
        // Silencioso
      }

      // 3. Subir al servidor para enlace público seguro
      setProcessStep('Generando enlace directo...');
      let pubUrl: string | null = null;
      try {
        pubUrl = await uploadPdfForSharing(
          result.pdfBytes,
          fileName,
          patient.fullName,
          activeDoc
        );
        setPublicPdfUrl(pubUrl);
      } catch (e) {
        console.warn('No se pudo subir PDF:', e);
      }

      // 4. Construir mensaje médico
      const msg = buildWhatsAppMessage(
        [activeDef.shortName],
        patient.fullName,
        patient.idNumber,
        patient.date,
        pubUrl || undefined
      );
      setActiveMessage(msg);

      const cleanPhone = formatWhatsAppPhone(targetPhone);
      const encodedMsg = encodeURIComponent(msg);

      const webUrl = cleanPhone
        ? `https://web.whatsapp.com/send?phone=${cleanPhone}&text=${encodedMsg}`
        : `https://web.whatsapp.com/send?text=${encodedMsg}`;

      const univUrl = cleanPhone
        ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedMsg}`
        : `https://api.whatsapp.com/send?text=${encodedMsg}`;

      setWhatsappWebUrl(webUrl);
      setWhatsappUniversalUrl(univUrl);

      // Copiar al portapapeles
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(msg);
          setCopied(true);
          setTimeout(() => setCopied(false), 3000);
        }
      } catch (e) {}

      // 5. El usuario debe hacer clic explícitamente en "Abrir en WhatsApp" para evitar
      // que el bloqueador de popups lo detenga o que se pierda la sesión clínica actual al navegar.
      setDelivered(true);
    } catch (err: any) {
      console.error('Error en entrega rápida:', err);
      setDeliveryError(`No se pudo generar el documento PDF: ${err.message || 'Error desconocido'}`);
    } finally {
      setIsProcessing(false);
      setProcessStep('');
    }
  };

  const handleCopy = async () => {
    if (!activeMessage) return;
    try {
      await navigator.clipboard.writeText(activeMessage);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (e) {
      setDeliveryError('No se pudo copiar automáticamente. Por favor seleccione y copie el texto.');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in font-sans">
      <div className="bg-[#0d152a] border border-slate-800/90 w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-100">
        {/* Cabecera Limpia - Stitch */}
        <div className="p-4 sm:p-5 bg-[#070d1e] border-b border-slate-800 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-inner">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black leading-tight">
                Envío de {activeDef.shortName} por WhatsApp
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                Paciente: {patient.fullName || 'Sin nombre'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cuerpo del Modal - Stitch */}
        <div className="p-5 space-y-4">
          {deliveryError && (
            <div
              role="alert"
              aria-live="polite"
              className="p-3 bg-rose-950/60 border border-rose-500/40 rounded-xl text-xs font-bold text-rose-300 flex items-center gap-2 font-mono"
            >
              <span className="w-2 h-2 rounded-full bg-rose-500 flex-shrink-0 animate-ping" />
              <span>{deliveryError}</span>
            </div>
          )}

          {isProcessing ? (
            <div className="py-8 flex flex-col items-center justify-center text-center space-y-3 font-mono">
              <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
              <p className="font-bold text-white text-sm">{processStep}</p>
              <p className="text-xs text-slate-400">
                Por favor, espera mientras preparamos el enlace seguro.
              </p>
            </div>
          ) : (
            <>
              {/* Estado de Envío Exitoso - Stitch */}
              <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 flex items-center gap-3 text-emerald-200">
                <div className="w-8 h-8 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shrink-0 shadow-sm font-bold">
                  <Check className="w-5 h-5 stroke-[3]" />
                </div>
                <div className="text-xs">
                  <p className="font-black text-white text-sm">
                    ¡Documento Listo para Enviar!
                  </p>
                  <p className="text-slate-300 mt-0.5">
                    El enlace seguro del PDF oficial fue generado exitosamente y está listo para adjuntarse en el chat.
                  </p>
                </div>
              </div>

              {/* Teléfono del Paciente */}
              <div className="p-3.5 rounded-2xl bg-[#070d1e] border border-slate-800 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2 text-slate-400 min-w-0 font-mono">
                  <Phone className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span className="truncate">
                    Destinatario: <strong className="text-white font-bold">{phoneNumber}</strong>
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleFastDelivery(phoneNumber)}
                  className="text-[11px] font-mono font-bold text-cyan-400 hover:text-cyan-300 underline shrink-0 cursor-pointer"
                >
                  Generar Nuevamente
                </button>
              </div>

              {/* Botón de apertura directa móvil y opciones */}
              <div className="flex flex-col sm:flex-row items-center gap-2 pt-1 font-mono">
                <a
                  href={whatsappUniversalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-lg shadow-emerald-950/40 border border-emerald-400/40 transition text-center active:scale-95 cursor-pointer"
                >
                  <Share2 className="w-4 h-4 text-white" />
                  <span>Abrir en WhatsApp</span>
                </a>

                <button
                  type="button"
                  onClick={handleCopy}
                  className="w-full sm:w-auto flex items-center justify-center gap-1.5 py-3 px-4 rounded-xl bg-[#070d1e] hover:bg-slate-800 text-slate-200 text-xs font-bold transition cursor-pointer border border-slate-800 hover:border-slate-700 active:scale-95"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-cyan-400" />
                      <span className="text-cyan-300">¡Copiado!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-slate-400" />
                      <span>Copiar Texto</span>
                    </>
                  )}
                </button>
              </div>

              {/* Vista Alternativa: Escanear con Celular si se está usando una PC */}
              {showQrCode ? (
                <div className="p-4 rounded-2xl bg-[#070d1e] border border-slate-800 text-white flex flex-col items-center text-center space-y-3 animate-fade-in font-mono">
                  <div className="p-2.5 bg-white rounded-2xl shadow-md">
                    <OfficialQrCode
                      value={whatsappUniversalUrl}
                      size={140}
                      darkColor="#0f172a"
                      lightColor="#ffffff"
                    />
                  </div>
                  <div className="space-y-1">
                    <p className="font-bold text-xs">Apunte con la cámara de su teléfono</p>
                    <p className="text-[11px] text-slate-400">
                      Se abrirá de inmediato el chat de WhatsApp con {patient.fullName} y el documento listo para enviar.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowQrCode(false)}
                    className="text-xs text-slate-400 hover:text-white underline cursor-pointer"
                  >
                    Ocultar Código QR
                  </button>
                </div>
              ) : (
                <div className="hidden md:flex items-center justify-start pt-1 font-mono">
                  <button
                    type="button"
                    onClick={() => setShowQrCode(true)}
                    className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-400 font-medium cursor-pointer"
                  >
                    <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                    <span>¿Abrir desde otro teléfono? (Ver QR)</span>
                  </button>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer Sencillo - Stitch */}
        <div className="p-4 bg-[#070d1e] border-t border-slate-800 flex items-center justify-end gap-2 font-mono">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition cursor-pointer border border-slate-700"
          >
            Listo, Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
