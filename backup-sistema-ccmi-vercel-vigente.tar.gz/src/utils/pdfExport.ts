import jsPDF from 'jspdf';
import html2canvas from 'html2canvas-pro';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { DocType, PatientData } from '../types';
import { CalibrationEngine } from '../calibration/CalibrationEngine';
import recipeMaster from '../calibration/masters/recipe.master.json';
import labMaster from '../calibration/masters/lab.master.json';
import informeMaster from '../calibration/masters/informe.master.json';
import constanciaMaster from '../calibration/masters/constancia.master.json';
import historiaMaster from '../calibration/masters/historia.master.json';
import { PDFDocumentPipelineV2 } from './PDFDocumentPipelineV2';
import type { ClinicalWorkspaceContext } from '../calibration/SemanticDataMapperV2';

// Re-export canonical definitions and helpers (decoupled to eliminate module cycles)
export { DOCUMENT_DEFINITIONS, TEMPLATE_IMAGE_PATHS } from './documentDefinitions';
export type { DocumentDefinition } from './documentDefinitions';
export {
  formatWhatsAppPhone,
  sanitizeFileName,
  toBlobPart,
  toBufferSource,
  downloadBlob,
  uploadPdfForSharing,
  sharePdfToWhatsApp,
  buildWhatsAppMessage,
} from './pdfExportHelpers';
export type { SharePdfOptions } from './pdfExportHelpers';

import {
  formatWhatsAppPhone,
  sanitizeFileName,
  toBlobPart,
  toBufferSource,
  downloadBlob,
  uploadPdfForSharing,
  sharePdfToWhatsApp,
  buildWhatsAppMessage,
} from './pdfExportHelpers';
import { DOCUMENT_DEFINITIONS } from './documentDefinitions';

// ============================================================================
// MOTOR DE INYECCIÓN DIRECTA SOBRE ARCHIVOS PDF BASE (PDF-LIB)
// INSTITUTO DE CIRUGÍA DE COLUMNA MÍNIMAMENTE INVASIVA (CCMI)
// DR. SAMIR MOUCHARRAFIE NAIME
// ============================================================================

/**
 * Carga el binario PDF original maestro desde /public/templates/ sin alterar
 * ni redibujar nada de su estructura gráfica oficial.
 */
export async function loadBasePdf(filename: string): Promise<PDFDocument> {
  let existingPdfBytes: ArrayBuffer | Uint8Array;
  if (typeof window !== 'undefined') {
    existingPdfBytes = await fetch(`/templates/${filename}`).then((res) => {
      if (!res.ok) throw new Error(`No se pudo cargar la plantilla base: ${filename}`);
      return res.arrayBuffer();
    });
  } else {
    const fs = await import('fs');
    const path = await import('path');
    existingPdfBytes = fs.readFileSync(path.join(process.cwd(), 'public/templates', filename));
  }
  return await PDFDocument.load(existingPdfBytes);
}

// ----------------------------------------------------------------------------
// 1. ORDEN DE LABORATORIO Y ESTUDIOS ESPECIALES (2 PÁGINAS EXACTAS)
// ----------------------------------------------------------------------------
export interface LabOrderExportOptions {
  labTests?: Record<string, boolean> | string[];
  neuroimagingTests?: Record<string, boolean> | string[];
  neuroimagingDetails?: Record<string, string>;
  selectedCheckboxes?: Record<string, { x: number; y: number; page: number }>;
}

/**
 * FUNCIÓN CANÓNICA INTERNA PARA ORDEN DE LABORATORIO Y ESTUDIOS ESPECIALES:
 * Inyecta datos clínicos y marcas sobre el PDF oficial inmutable /templates/orden_lab_base.pdf.
 * Obtiene toda la geometría en milímetros exclusivamente desde labMaster (Única Fuente de Verdad).
 */
export async function createOfficialLabOrderPdf(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string; phone?: string; address?: string },
  orderData: LabOrderExportOptions | Record<string, any>,
  presumptiveDx: string = '',
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const context: ClinicalWorkspaceContext = {
    patient: {
      fullName: patient.fullName || '',
      idNumber: patient.idNumber || '',
      age: patient.age !== undefined && patient.age !== null && patient.age !== '' ? String(patient.age) : '',
      phone: (patient as any).phone || '',
      address: (patient as any).address || '',
    },
    clinical: {
      diagnosisPrincipal: presumptiveDx || '',
      labTests: (orderData as any)?.labTests || orderData,
      neuroimagingTests: (orderData as any)?.neuroimagingTests,
      otherExams: (orderData as any)?.otherExams || '',
    },
    documentDate: patient.date || new Date().toLocaleDateString('es-VE'),
  };

  const result = await PDFDocumentPipelineV2.generateDocument({
    documentType: 'lab_order',
    context,
    customFileName,
  });

  return {
    pdfBytes: result.pdfBytes,
    blob: result.blob,
    file: result.file,
    fileName: result.fileName,
    requiresReview: result.requiresReview,
  };
}

export async function exportOfficialLabOrderPDF(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string; phone?: string; address?: string },
  orderData: LabOrderExportOptions | Record<string, any>,
  presumptiveDxOrFileName?: string,
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const isFileName = presumptiveDxOrFileName && presumptiveDxOrFileName.endsWith('.pdf');
  const actualFileName = isFileName ? presumptiveDxOrFileName : customFileName;
  const presumptiveDx = isFileName
    ? ((orderData as any)?.diagnosticoPresuntivo || (orderData as any)?.diagnosisPrincipal || '')
    : (presumptiveDxOrFileName || (orderData as any)?.diagnosticoPresuntivo || '');

  // Conexión Canónica V2: TemplateRegistry -> Master V2 -> DataResolver -> PDFDocumentPipelineV2
  const context: ClinicalWorkspaceContext = {
    patient: {
      fullName: patient.fullName || '',
      idNumber: patient.idNumber || '',
      age: patient.age ? String(patient.age) : '',
      phone: (patient as any).phone || '',
      address: (patient as any).address || '',
    },
    clinical: {
      diagnosisPrincipal: presumptiveDx || '',
      labTests: (orderData as any)?.perfilPreoperatorio || (orderData as any)?.labTests || orderData,
      neuroimagingTests: (orderData as any)?.neuroimagen || (orderData as any)?.neuroimagingTests,
      otherExams: (orderData as any)?.otrosEstudios || (orderData as any)?.otherExams || '',
    },
    documentDate: patient.date || new Date().toLocaleDateString('es-VE'),
  };

  const result = await PDFDocumentPipelineV2.generateDocument({
    documentType: 'lab_order',
    context,
    customFileName: actualFileName,
  });

  downloadBlob(result.pdfBytes, result.fileName);
  return {
    pdfBytes: result.pdfBytes,
    blob: result.blob,
    file: result.file,
    fileName: result.fileName,
    requiresReview: result.requiresReview,
  };
}

// ----------------------------------------------------------------------------
// 2. HISTORIA CLÍNICA OFICIAL (INYECCIÓN DIRECTA BASADA EN HISTORIA.MASTER)
// ----------------------------------------------------------------------------
/**
 * FUNCIÓN CANÓNICA INTERNA PARA HISTORIA CLÍNICA:
 * Inyecta datos clínicos mediante overlay vectorial directamente sobre
 * el PDF oficial inmutable /templates/historia_base.pdf.
 * Toda la geometría en milímetros se obtiene exclusivamente desde historiaMaster.
 */
export async function createOfficialHistoriaPdf(
  patient: { fullName?: string; idNumber?: string; age?: string | number; phone?: string; address?: string; date?: string },
  clinical: {
    motivo?: string;
    motivoConsulta?: string;
    enfermedadActual?: string;
    antecedentes?: string;
    neuroExam?: string;
    examenNeurologico?: string;
    dx?: string;
    diagnostico?: string;
  },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const context: ClinicalWorkspaceContext = {
    patient: {
      fullName: patient.fullName || '',
      idNumber: patient.idNumber || '',
      age: patient.age ? String(patient.age) : '',
      phone: patient.phone || '',
      address: patient.address || '',
      date: patient.date || new Date().toLocaleDateString('es-VE'),
    },
    clinical: {
      motivoConsulta: clinical.motivoConsulta || clinical.motivo || '',
      enfermedadActual: clinical.enfermedadActual || '',
      antecedentes: clinical.antecedentes || '',
      examenFisico: clinical.examenNeurologico || clinical.neuroExam || '',
      diagnosisPrincipal: clinical.diagnostico || clinical.dx || '',
    },
    documentDate: patient.date || new Date().toLocaleDateString('es-VE'),
  };

  const result = await PDFDocumentPipelineV2.generateDocument({
    documentType: 'history',
    context,
    customFileName,
  });

  return {
    pdfBytes: result.pdfBytes,
    blob: result.blob,
    file: result.file,
    fileName: result.fileName,
    requiresReview: result.requiresReview,
  };
}

export async function exportOfficialHistoriaPDF(
  patient: { fullName?: string; idNumber?: string; age?: string | number; address?: string; phone?: string; date?: string },
  clinical: {
    motivo?: string;
    motivoConsulta?: string;
    enfermedadActual?: string;
    antecedentes?: string;
    neuroExam?: string;
    examenNeurologico?: string;
    dx?: string;
    diagnostico?: string;
  },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const result = await createOfficialHistoriaPdf(patient, clinical, customFileName);
  downloadBlob(result.pdfBytes, result.fileName);
  return result;
}

// ----------------------------------------------------------------------------
// 3. RÉCIPE MÉDICO (DOBLE TALÓN) - INYECCIÓN DIRECTA
// ----------------------------------------------------------------------------
/**
 * FUNCIÓN CANÓNICA INTERNA PARA RÉCIPE MÉDICO (DOBLE TALÓN):
 * Inyecta los datos clínicos mediante overlay vectorial directamente
 * sobre el PDF oficial inmutable /templates/recipe_base.pdf.
 * Toda la geometría en milímetros se obtiene exclusivamente desde recipeMaster.
 */
export async function createOfficialRecipePdf(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string },
  recipeData: { rxLeft?: string; indicationsRight?: string },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const context: ClinicalWorkspaceContext = {
    patient: {
      fullName: patient.fullName || '',
      idNumber: patient.idNumber || '',
      age: patient.age ? String(patient.age) : '',
      date: patient.date || new Date().toLocaleDateString('es-VE'),
    },
    recipeLeft: recipeData.rxLeft || '',
    recipeRight: recipeData.indicationsRight || '',
    documentDate: patient.date || new Date().toLocaleDateString('es-VE'),
  };

  const result = await PDFDocumentPipelineV2.generateDocument({
    documentType: 'recipe',
    context,
    customFileName,
  });

  return {
    pdfBytes: result.pdfBytes,
    blob: result.blob,
    file: result.file,
    fileName: result.fileName,
    requiresReview: result.requiresReview,
  };
}

export async function exportOfficialRecipePDF(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string },
  recipeData: { rxLeft?: string; indicationsRight?: string },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const result = await createOfficialRecipePdf(patient, recipeData, customFileName);
  downloadBlob(result.pdfBytes, result.fileName);
  return result;
}

// ----------------------------------------------------------------------------
// 4. INFORME MÉDICO OFICIAL (INYECCIÓN DIRECTA BASADA EN INFORME.MASTER)
// ----------------------------------------------------------------------------
/**
 * FUNCIÓN CANÓNICA INTERNA PARA INFORME MÉDICO:
 * Inyecta datos clínicos mediante overlay vectorial directamente sobre
 * el PDF oficial inmutable /templates/informe_base.pdf.
 * Toda la geometría en milímetros se obtiene exclusivamente desde informeMaster.
 */
export async function createOfficialInformePdf(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string },
  reportData: { content?: string; diagnosis?: string; bodyText?: string } | string,
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const bodyText = typeof reportData === 'string'
    ? reportData
    : (reportData.bodyText || reportData.content || reportData.diagnosis || '');
  const context: ClinicalWorkspaceContext = {
    patient: {
      fullName: patient.fullName || '',
      idNumber: patient.idNumber || '',
      age: patient.age ? String(patient.age) : '',
      date: patient.date || new Date().toLocaleDateString('es-VE'),
    },
    clinical: {
      clinicalReport: bodyText,
      reportText: bodyText,
      diagnosisPrincipal: typeof reportData === 'object' ? (reportData.diagnosis || '') : '',
    },
    documentDate: patient.date || new Date().toLocaleDateString('es-VE'),
  };

  const result = await PDFDocumentPipelineV2.generateDocument({
    documentType: 'report',
    context,
    customFileName,
  });

  return {
    pdfBytes: result.pdfBytes,
    blob: result.blob,
    file: result.file,
    fileName: result.fileName,
    requiresReview: result.requiresReview,
  };
}

export async function exportOfficialInformePDF(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string },
  reportData: { content?: string; diagnosis?: string; bodyText?: string } | string,
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const result = await createOfficialInformePdf(patient, reportData, customFileName);
  downloadBlob(result.pdfBytes, result.fileName);
  return result;
}

// ----------------------------------------------------------------------------
// 5. CONSTANCIA MÉDICA DE REPOSO (INYECCIÓN DIRECTA BASADA EN CONSTANCIA.MASTER)
// ----------------------------------------------------------------------------
/**
 * FUNCIÓN CANÓNICA INTERNA PARA CONSTANCIA MÉDICA DE REPOSO:
 * Inyecta datos clínicos mediante overlay vectorial directamente sobre
 * el PDF oficial inmutable /templates/constancia_base.pdf.
 * Toda la geometría en milímetros se obtiene exclusivamente desde constanciaMaster.
 */
export async function createOfficialConstanciaPdf(
  patient: { fullName?: string; idNumber?: string; date?: string; guideNumber?: string; condition?: string },
  certificateData: {
    restDays?: string | number;
    diagnosis?: string;
    idx?: string;
    condition?: string;
    needsRest?: boolean;
    attendedDate?: string;
    restFrom?: string;
    restTo?: string;
    requestDay?: string;
    requestMonth?: string;
    requestYear?: string;
    isPaciente?: boolean;
    isFamiliar?: boolean;
  },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const context: ClinicalWorkspaceContext = {
    patient: {
      fullName: patient.fullName || '',
      idNumber: patient.idNumber || '',
      date: patient.date || new Date().toLocaleDateString('es-VE'),
    },
    clinical: {
      diagnosisPrincipal: certificateData.idx || certificateData.diagnosis || '',
    },
    certificateText: certificateData.idx || certificateData.diagnosis || '',
    documentDate: patient.date || new Date().toLocaleDateString('es-VE'),
    ...({
      certificateData: {
        restDays: certificateData.restDays,
        diagnosis: certificateData.idx || certificateData.diagnosis,
        needsRest: certificateData.needsRest,
        attendedDate: certificateData.attendedDate || patient.date || new Date().toLocaleDateString('es-VE'),
        restFrom: certificateData.restFrom,
        restTo: certificateData.restTo,
        requestDay: certificateData.requestDay,
        requestMonth: certificateData.requestMonth,
        requestYear: certificateData.requestYear,
        isPaciente: certificateData.isPaciente ?? (certificateData.condition?.toLowerCase() === 'paciente' || !certificateData.condition),
        isFamiliar: certificateData.isFamiliar ?? (certificateData.condition?.toLowerCase() === 'familiar'),
      }
    } as any),
  };

  const result = await PDFDocumentPipelineV2.generateDocument({
    documentType: 'certificate',
    context,
    customFileName,
  });

  return {
    pdfBytes: result.pdfBytes,
    blob: result.blob,
    file: result.file,
    fileName: result.fileName,
    requiresReview: result.requiresReview,
  };
}

export async function exportOfficialConstanciaPDF(
  patient: { fullName?: string; idNumber?: string; date?: string; guideNumber?: string; condition?: string },
  certificateData: {
    restDays?: string | number;
    diagnosis?: string;
    idx?: string;
    condition?: string;
    needsRest?: boolean;
    attendedDate?: string;
    restFrom?: string;
    restTo?: string;
    requestDay?: string;
    requestMonth?: string;
    requestYear?: string;
  },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const result = await createOfficialConstanciaPdf(patient, certificateData, customFileName);
  downloadBlob(result.pdfBytes, result.fileName);
  return result;
}

// ----------------------------------------------------------------------------
// DISPATCHER CANÓNICO UNIFICADO (ÚNICA FUENTE DE VERDAD PARA TODOS LOS CANALES)
// ----------------------------------------------------------------------------
export interface ClinicalDataBundle {
  recipeData?: { pharmacy?: string; patientIndications?: string; rxLeft?: string; indicationsRight?: string };
  labData?: {
    labTests?: Record<string, boolean> | string[];
    neuroimagingTests?: Record<string, boolean> | string[];
    neuroimagingDetails?: Record<string, string>;
    presumptiveDx?: string;
    otherExams?: string;
  };
  informeData?: { bodyText?: string };
  constanciaData?: {
    restDays?: string | number;
    diagnosis?: string;
    idx?: string;
    condition?: string;
    needsRest?: boolean;
    attendedDate?: string;
    restFrom?: string;
    restTo?: string;
    requestDay?: string;
    requestMonth?: string;
    requestYear?: string;
  };
  historiaData?: {
    motivo?: string;
    motivoConsulta?: string;
    enfermedadActual?: string;
    antecedentes?: string;
    neuroExam?: string;
    examenNeurologico?: string;
    dx?: string;
    diagnostico?: string;
  };
}

/**
 * GENERADOR CANÓNICO ÚNICO:
 * Punto de entrada centralizado para Descarga, Previsualización y WhatsApp.
 * Garantiza de forma innegociable que TODO documento oficial emitido por cualquier canal
 * provenga exclusivamente de: PDF ORIGINAL INMUTABLE + OVERLAY VECTORIAL = PDF FINAL.
 */
export async function generateCanonicalDocumentPDF(
  docKey: DocType,
  patient: PatientData,
  bundle: ClinicalDataBundle,
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  switch (docKey) {
    case 'RECIPES':
      return await createOfficialRecipePdf(
        {
          fullName: patient.fullName,
          idNumber: patient.idNumber,
          age: patient.age,
          date: patient.date,
        },
        {
          rxLeft: bundle.recipeData?.rxLeft || bundle.recipeData?.pharmacy,
          indicationsRight: bundle.recipeData?.indicationsRight || bundle.recipeData?.patientIndications,
        },
        customFileName
      );

    case 'ORDEN_LAB':
      return await createOfficialLabOrderPdf(
        {
          fullName: patient.fullName,
          idNumber: patient.idNumber,
          age: patient.age,
          date: patient.date,
        },
        {
          labTests: bundle.labData?.labTests || [],
          neuroimagingTests: bundle.labData?.neuroimagingTests,
          neuroimagingDetails: bundle.labData?.neuroimagingDetails,
          otherExams: bundle.labData?.otherExams || '',
        },
        bundle.labData?.presumptiveDx || '',
        customFileName
      );

    case 'INFORME':
      return await createOfficialInformePdf(
        {
          fullName: patient.fullName,
          idNumber: patient.idNumber,
          age: patient.age,
          date: patient.date,
        },
        {
          bodyText: bundle.informeData?.bodyText,
        },
        customFileName
      );

    case 'CONSTANCIA':
      return await createOfficialConstanciaPdf(
        {
          fullName: patient.fullName,
          idNumber: patient.idNumber,
          date: patient.date,
          guideNumber: patient.guideNumber,
          condition: bundle.constanciaData?.condition || patient.condition,
        },
        {
          restDays: bundle.constanciaData?.restDays,
          diagnosis: bundle.constanciaData?.diagnosis || bundle.constanciaData?.idx,
          idx: bundle.constanciaData?.idx || bundle.constanciaData?.diagnosis,
          condition: bundle.constanciaData?.condition || patient.condition,
          needsRest: bundle.constanciaData?.needsRest,
          attendedDate: bundle.constanciaData?.attendedDate,
          restFrom: bundle.constanciaData?.restFrom,
          restTo: bundle.constanciaData?.restTo,
          requestDay: bundle.constanciaData?.requestDay,
          requestMonth: bundle.constanciaData?.requestMonth,
          requestYear: bundle.constanciaData?.requestYear,
        },
        customFileName
      );

    case 'HISTORIA':
      return await createOfficialHistoriaPdf(
        {
          fullName: patient.fullName,
          idNumber: patient.idNumber,
          age: patient.age,
          phone: patient.phone,
          address: patient.address,
          date: patient.date,
        },
        {
          motivoConsulta: bundle.historiaData?.motivoConsulta || bundle.historiaData?.motivo,
          enfermedadActual: bundle.historiaData?.enfermedadActual,
          antecedentes: bundle.historiaData?.antecedentes,
          examenNeurologico: bundle.historiaData?.examenNeurologico || bundle.historiaData?.neuroExam,
          diagnostico: bundle.historiaData?.diagnostico || bundle.historiaData?.dx,
        },
        customFileName
      );

    default:
      throw new Error(`Tipo de documento clínico oficial desconocido: ${docKey}`);
  }
}

/**
 * GENERADOR OFICIAL DE RÉCIPE MÉDICO (DELEGADO A createOfficialRecipePdf):
 * Mantiene compatibilidad total con invocadores que requieren los bytes/blob
 * del récipe sin forzar la descarga automática en el navegador.
 */
export async function generateOfficialRecipePDF(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string },
  recipeData: { rxLeft?: string; indicationsRight?: string },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  return await createOfficialRecipePdf(patient, recipeData, customFileName);
}

/**
 * EXPORTACIÓN WYSIWYG EXACTA A4 (300 DPI):
 * Captura el contenedor visible en pantalla con la plantilla física de fondo
 * y los textos/inputs transparentes sobre ella, garantizando fidelidad 1:1 absoluta.
 */
/**
 * @deprecated ARQUITECTURA LEGACY (RASTERIZADO DOM):
 * Esta función utiliza html2canvas para rasterizar el DOM del navegador.
 * PROHIBIDO su uso para la emisión de documentos oficiales en Arquitectura V2.
 * Los documentos oficiales deben generarse exclusivamente con la ruta canónica
 * PDF ORIGINAL + VECTOR OVERLAY (CanonicalDocumentGeneratorV2 / PDFDocumentPipelineV2).
 * Se mantiene temporalmente solo para compatibilidad retrospectiva si alguna vista antigua lo invoca.
 */
export async function exportElementToExactA4PDF(
  elementId: string,
  filename: string
): Promise<{ pdf: jsPDF; blob: Blob; file: File; success: boolean }> {
  console.warn('[V2 MANDATE WARNING] Invocación de exportElementToExactA4PDF (html2canvas raster legacy). Los documentos oficiales deben generarse exclusivamente con PDFDocumentPipelineV2.');
  const element = document.getElementById(elementId);
  if (!element) {
    console.error(`Elemento #${elementId} no encontrado en el DOM.`);
    throw new Error(`Elemento #${elementId} no encontrado en el DOM.`);
  }

  // Captura el contenedor exactamente como se ve (plantilla de fondo + texto encima)
  const canvas = await html2canvas(element, {
    scale: 3, // 300 DPI de resolución médica
    useCORS: true,
    allowTaint: true,
    backgroundColor: '#ffffff',
    logging: false,
    windowWidth: 794,
    windowHeight: 1123,
    onclone: (clonedDoc: Document) => {
      const clonedContainer = clonedDoc.getElementById(elementId);
      if (!clonedContainer) return;

      clonedContainer.style.width = '794px';
      clonedContainer.style.minHeight = '1123px';
      clonedContainer.style.maxHeight = '1123px';
      clonedContainer.style.height = '1123px';

      // Preservar exactamente los valores de inputs como divs con estilos calculados
      const inputs = clonedContainer.querySelectorAll<HTMLInputElement>('input');
      inputs.forEach((input) => {
        const div = clonedDoc.createElement('div');
        const comp = window.getComputedStyle(input);
        div.textContent = input.value || input.placeholder || '';
        div.className = input.className;
        div.style.fontFamily = comp.fontFamily;
        div.style.fontSize = comp.fontSize;
        div.style.fontWeight = comp.fontWeight;
        div.style.lineHeight = comp.lineHeight;
        div.style.textAlign = comp.textAlign;
        div.style.color = comp.color;
        div.style.backgroundColor = 'transparent';
        div.style.borderRadius = comp.borderRadius;
        div.style.border = 'none';
        div.style.padding = comp.padding;
        div.style.width = comp.width;
        div.style.height = comp.height;
        div.style.display = 'inline-flex';
        div.style.alignItems = 'center';
        div.style.boxSizing = 'border-box';
        div.style.boxShadow = 'none';
        div.style.outline = 'none';
        input.parentNode?.replaceChild(div, input);
      });

      // Preservar textareas manteniendo saltos de línea y espaciados
      const textareas = clonedContainer.querySelectorAll<HTMLTextAreaElement>('textarea');
      textareas.forEach((ta) => {
        const div = clonedDoc.createElement('div');
        const comp = window.getComputedStyle(ta);
        div.textContent = ta.value || ta.placeholder || '';
        div.className = ta.className;
        div.style.fontFamily = comp.fontFamily;
        div.style.fontSize = comp.fontSize;
        div.style.fontWeight = comp.fontWeight;
        div.style.lineHeight = comp.lineHeight;
        div.style.textAlign = comp.textAlign;
        div.style.color = comp.color;
        div.style.backgroundColor = 'transparent';
        div.style.border = 'none';
        div.style.borderRadius = comp.borderRadius;
        div.style.padding = comp.padding;
        div.style.whiteSpace = 'pre-wrap';
        div.style.wordBreak = 'break-word';
        div.style.minHeight = comp.height;
        div.style.boxSizing = 'border-box';
        div.style.boxShadow = 'none';
        div.style.outline = 'none';
        ta.parentNode?.replaceChild(div, ta);
      });
    },
  });

  const imgData = canvas.toDataURL('image/jpeg', 0.98);

  // Hoja estándar A4: 210mm x 297mm
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  pdf.addImage(imgData, 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
  pdf.save(filename);

  const blob = pdf.output('blob');
  const file = new File([blob], filename, { type: 'application/pdf' });

  return { pdf, blob, file, success: true };
}

/**
 * Captura directa del contenedor A4 oficial con la plantilla original de fondo
 * ejecutando html2canvas a 300 DPI y jsPDF en formato A4 retrato (210mm x 297mm).
 * Sustituye completamente cualquier generador antiguo de texto plano en blanco y negro.
 */
/**
 * @deprecated ARQUITECTURA LEGACY (RASTERIZADO DOM):
 * Utiliza html2canvas para rasterizar el DOM del navegador.
 * PROHIBIDO para la emisión de documentos oficiales en Arquitectura V2.
 */
export const exportOfficialSheetToPDF = async (
  containerId: string,
  filename: string
): Promise<{ pdf: jsPDF; success: boolean }> => {
  console.warn('[V2 MANDATE WARNING] Invocación de exportOfficialSheetToPDF (html2canvas raster legacy). Toda emisión oficial debe usar PDFDocumentPipelineV2.');
  const element = document.getElementById(containerId);
  if (!element) {
    console.error(`Contenedor #${containerId} no encontrado.`);
    throw new Error(`Contenedor #${containerId} no encontrado.`);
  }

  // Captura el contenedor exactamente como se ve en pantalla (fondo original + texto encima)
  const canvas = await html2canvas(element, {
    scale: 3, // Alta resolución 300 DPI
    useCORS: true,
    allowTaint: true,
    backgroundColor: null,
    logging: false,
    windowWidth: 794,
    windowHeight: 1123,
  });

  const imgData = canvas.toDataURL('image/jpeg', 0.98);
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  pdf.addImage(imgData, 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
  pdf.save(filename);
  return { pdf, success: true };
};

// Aliases explícitos para marcar funciones legadas
export const LEGACY_DEPRECATED_rasterExport = exportElementToExactA4PDF;
export const LEGACY_DEPRECATED_exportOfficialSheetToPDF = exportOfficialSheetToPDF;

/**
 * Enviar PDF por WhatsApp:
 * 1. Sube el PDF oficial al servidor seguro para obtener un enlace público permanente de descarga.
 * 2. Si el dispositivo soporta Web Share con archivos adjuntos (Android/iOS/iPadOS), lo envía directamente como archivo.
 * 3. Si se encuentra en una computadora/PC (con o sin WhatsApp Desktop instalado), descarga el PDF,
 *    copia el mensaje y enlace al portapapeles y abre WhatsApp (Web o App) de manera instantánea.
 */
// ----------------------------------------------------------------------------
// ARQUITECTURA V2: RE-EXPORTACIONES COMPATIBLES Y EXTENSIBLES
// ----------------------------------------------------------------------------
export { PDFDocumentPipelineV2 } from './PDFDocumentPipelineV2';
export type { DocumentPipelineRequest, DocumentPipelineResponse } from './PDFDocumentPipelineV2';
