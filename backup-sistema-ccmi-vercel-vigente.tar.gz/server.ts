import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));

// Global CORS headers for cross-origin preview iframes and image loading
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Explicitly serve original stationery templates from public/templates with permissive CORS
app.use('/templates', express.static(path.join(process.cwd(), 'public/templates'), {
  setHeaders: (res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  }
}));

// Explicitly serve static assets and images from public with permissive CORS
app.use('/assets', express.static(path.join(process.cwd(), 'public/assets'), {
  setHeaders: (res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  }
}));

app.use('/images', express.static(path.join(process.cwd(), 'public/images'), {
  setHeaders: (res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  }
}));

// Robust Initializer for Gemini API client with multi-source fallback
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY || (typeof globalThis !== 'undefined' ? (globalThis as any).GEMINI_API_KEY : '');
    if (apiKey) {
      aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
      console.log('[Gemini Init] Cliente AI inicializado correctamente con API Key activa.');
    } else {
      console.warn('[Gemini Init] ADVERTENCIA: GEMINI_API_KEY no se encuentra configurada en las variables de entorno.');
    }
  }
  return aiClient;
}

// API Health Check
app.get('/api/health', (req, res) => {
  const client = getGeminiClient();
  res.json({
    status: 'ok',
    hasApiKey: !!client || !!process.env.GEMINI_API_KEY,
    service: 'SOCS CCMI Clinical Engine',
    doctor: 'Dr. Samir Moucharrafie Naime',
  });
});

// Calibrations persistence file path
const CALIBRATIONS_FILE = path.join(process.cwd(), 'data', 'calibrations.json');
const CALIBRATOR_MAP_V10_FILE = path.join(process.cwd(), 'data', 'calibrator_elements_map_v10.json');

// API: Get Saved Calibrations (Both structured matrix and vector calibrator map)
app.get('/api/calibrations', (req, res) => {
  try {
    let calibrations: Record<string, any> = {};
    if (fs.existsSync(CALIBRATIONS_FILE)) {
      try {
        calibrations = JSON.parse(fs.readFileSync(CALIBRATIONS_FILE, 'utf-8'));
      } catch (e) {
        calibrations = {};
      }
    }

    let rawMap: string | null = null;
    let calibratorMap: any = null;
    if (fs.existsSync(CALIBRATOR_MAP_V10_FILE)) {
      try {
        rawMap = fs.readFileSync(CALIBRATOR_MAP_V10_FILE, 'utf-8');
        calibratorMap = JSON.parse(rawMap);
      } catch (e) {
        console.warn('[Calibrations] Error parsing calibrator map file:', e);
      }
    }

    return res.json({
      success: true,
      calibrations,
      rawMap,
      calibratorMap,
      hasServerCalibrations: Object.keys(calibrations).length > 0 || !!rawMap
    });
  } catch (err: any) {
    console.error('Error reading calibrations:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

// API: Save Calibrations (Dual persistence to server disk and sync layer)
app.post('/api/calibrations', (req, res) => {
  try {
    const { docType, calibration, allCalibrations, rawMap, calibratorMap } = req.body;
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // 1. Persist vector map if provided
    if (rawMap && typeof rawMap === 'string') {
      fs.writeFileSync(CALIBRATOR_MAP_V10_FILE, rawMap, 'utf-8');
      console.log(`[Calibrations Sync] Vector map persistido en ${CALIBRATOR_MAP_V10_FILE}`);
    } else if (calibratorMap && typeof calibratorMap === 'object') {
      fs.writeFileSync(CALIBRATOR_MAP_V10_FILE, JSON.stringify(calibratorMap, null, 2), 'utf-8');
      console.log(`[Calibrations Sync] Vector map object persistido en ${CALIBRATOR_MAP_V10_FILE}`);
    }

    // 2. Persist structured coordinate matrix
    let current: Record<string, any> = {};
    if (fs.existsSync(CALIBRATIONS_FILE)) {
      try {
        current = JSON.parse(fs.readFileSync(CALIBRATIONS_FILE, 'utf-8'));
      } catch (e) {
        current = {};
      }
    }

    if (allCalibrations && typeof allCalibrations === 'object') {
      current = { ...current, ...allCalibrations };
    } else if (docType && calibration) {
      current[docType] = calibration;
    }

    fs.writeFileSync(CALIBRATIONS_FILE, JSON.stringify(current, null, 2), 'utf-8');
    console.log(`[Calibrations Sync] Calibración estructurada guardada exitosamente en ${CALIBRATIONS_FILE}`);

    return res.json({
      success: true,
      saved: true,
      message: 'Calibración persistida en el servidor'
    });
  } catch (err: any) {
    console.error('Error saving calibrations to server:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

// SYSTEM PROMPT FOR NEUROSURGICAL CLINICAL SUMMARY EXTRACTION
const CLINICAL_SYSTEM_INSTRUCTION = `Eres el Asistente Clínico Inteligente de Neurocirugía del Dr. Samir Moucharrafie Naime (Especialista en Neurocirugía formado en la Université Claude Bernard Lyon 1, Francia / MPPS: 61231, CMEB: 5331).
Tu objetivo es procesar un dictado de voz clínico o texto médico continuo realizado por el Dr. Samir al evaluar a un paciente.
Debes extraer y estructurar los hallazgos de forma estrictamente fiel en un objeto JSON para los 5 documentos médicos oficiales.

REGLA CLÍNICA FUNDAMENTAL (INTEGRIDAD Y SEGURIDAD MÉDICA):
1. NUNCA INVENTES, ASUMAS NI FABRIQUES INFORMACIÓN CLÍNICA.
2. Si un campo (nombre, cédula, edad, teléfono, diagnóstico, medicamentos, posología, días de reposo, estudios paraclínicos, etc.) NO fue mencionado explícitamente en el dictado o en los datos previos, déjalo como cadena vacía ("") o arreglo vacío ([]).
3. NUNCA utilices pacientes de demostración, nombres genéricos ("Paciente Evaluado"), cédulas ficticias ("V-12.887.723"), teléfonos ficticios ("0424-912.44.81") ni tratamientos predeterminados.
4. Si un dato es ambiguo, dudoso o se presta a más de una interpretación médica, NO elijas silenciosamente: agrégalo a la lista "uncertainFields" y marca el campo.
5. NO agregues prefijos o etiquetas estáticas fijas en los valores (ej. NO escribir "DIAGNÓSTICO: Hernia", sino solo "Hernia discal lumbar L5-S1...").

ESTRUCTURA DE EXTRACCIÓN:
1. patient: fullName, idNumber, age, phone, date, address, guideNumber, condition ("Paciente" | "Familiar").
2. diagnosisPrincipal: Diagnóstico formal neuroquirúrgico expresado en la fuente (con nivel vertebral y lateralidad si se mencionaron). Si no hay diagnóstico explícito, dejarlo vacío ("").
3. cie10Suggestions: Códigos CIE-10 correspondientes únicamente al diagnóstico explícito.
4. recipeDual:
   * pharmacy: Lista estructurada de medicamentos para dispensar (Talón Farmacia). 
     Formato obligatorio: "1. [Nombre del Fármaco] [Concentración] - [Presentación]. Dispensar: [Cantidad o 'Tratamiento completo']". 
     Si no hay medicamentos explícitos, dejar vacío ("").
   * patientIndications: Instrucciones detalladas de toma para el paciente (Talón Indicaciones). 
     Formato obligatorio: "1. [Nombre del Fármaco]: Tomar [Dosis] cada [Horario] por [Duración]". 
     [REGLA DE SIMETRÍA ESTRICTA E INQUEBRANTABLE]: Por CADA medicamento que listes en el campo 'pharmacy', ESTÁS OBLIGADO a generar su contraparte exacta en el campo 'patientIndications'. Si el médico dicta una frase muy corta (ej. "Acetaminofén 500mg cada 5 horas"), debes deducir y estructurar ambos lados. JAMÁS dejes 'patientIndications' vacío si 'pharmacy' contiene información. Si faltan detalles (ej. duración), asume una indicación segura como "Tomar según dolor" o "Hasta finalizar tratamiento".
5. clinicalReport: Redacción continua y formal para el Informe Médico de Neurocirugía basada estrictamente en los hechos dictados.
6. labAndImagesOrder: Estudios clasificados explícitamente solicitados. Si no se solicitaron estudios, dejar vacío ("").
7. restCertificate:
   * needsRest: booleano (true si se indicó reposo; false si no amerita reposo o no se mencionó).
   * restDays: número de días de reposo indicados (0 si no amerita o no se especificó).
   * restFrom, restTo: fechas en formato DD/MM/AAAA.
   * condition: "PACIENTE" o "FAMILIAR".
   * idx: diagnóstico justificativo.
8. clinicalHistory: motivoConsulta, enfermedadActual, antecedentes, examenNeurologico, diagnostico.
9. uncertainFields: Arreglo de strings con nombres de campos ambiguos, incompletos o que requieren confirmación clínica manual.
10. extractedTranscript: Transcripción textual fiel de todo lo dictado.

Responde SIEMPRE en formato JSON válido conforme al esquema requerido.`;

// Exact JSON Schema for Clinical Extraction (Gemini)
const CLINICAL_EXTRACTION_SCHEMA = {
  type: "object",
  properties: {
    patient: {
      type: "object",
      properties: {
        fullName: { type: "string" },
        idNumber: { type: "string" },
        age: { type: "string" },
        phone: { type: "string" },
        date: { type: "string" },
        address: { type: "string" },
        guideNumber: { type: "string" },
        condition: { type: "string" }
      }
    },
    diagnosisPrincipal: { type: "string" },
    cie10Suggestions: { type: "array", items: { type: "string" } },
    recipeDual: {
      type: "object",
      properties: {
        pharmacy: { type: "string" },
        patientIndications: { type: "string" }
      }
    },
    clinicalReport: { type: "string" },
    labAndImagesOrder: { type: "string" },
    ordenLab: {
      type: "object",
      properties: {
        perfilPreoperatorio: { type: "array", items: { type: "string" } },
        neuroimagen: { type: "array", items: { type: "string" } },
        otrosEstudios: { type: "array", items: { type: "string" } },
        diagnosticoPresuntivo: { type: "string" }
      }
    },
    restCertificate: {
      type: "object",
      properties: {
        needsRest: { type: "boolean" },
        restDays: { type: "number" },
        restFrom: { type: "string" },
        restTo: { type: "string" },
        condition: { type: "string", enum: ["PACIENTE", "FAMILIAR"] },
        idx: { type: "string" }
      }
    },
    clinicalHistory: {
      type: "object",
      properties: {
        consultReason: { type: "string" },
        currentIllness: { type: "string" },
        background: { type: "string" },
        neuroExam: { type: "string" },
        diagnosis: { type: "string" }
      }
    },
    uncertainFields: {
      type: "array",
      items: { type: "string" }
    },
    extractedTranscript: {
      type: "string"
    }
  }
};

// Structural schema validator for clinical extraction
function validateClinicalExtractionSchema(raw: any): { valid: boolean; errors: string[]; data: any } {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { valid: false, errors: ['El cuerpo de la respuesta no es un objeto JSON válido.'], data: null };
  }

  const errors: string[] = [];

  // Validate patient
  const p = raw.patient || {};
  if (typeof p !== 'object' || Array.isArray(p)) {
    errors.push('Campo patient debe ser un objeto.');
  }

  // Validate uncertainFields
  const uncertainFields: string[] = Array.isArray(raw.uncertainFields)
    ? raw.uncertainFields.filter((item: any) => typeof item === 'string')
    : [];

  return {
    valid: errors.length === 0,
    errors,
    data: raw
  };
}

// Helper: Formateador unificado de respuesta clínica sin invención de datos
function formatClinicalData(parsedData: any, currentData?: any) {
  const p = parsedData.patient || {};
  const cp = currentData?.patient || {};

  const fullName = typeof p.fullName === 'string' && p.fullName.trim() ? p.fullName.trim() : (cp.fullName || '');
  const idNumber = typeof p.idNumber === 'string' && p.idNumber.trim() ? p.idNumber.trim() : (cp.idNumber || '');
  const age = typeof p.age === 'string' && p.age.trim() ? p.age.trim() : (cp.age || '');
  const phone = typeof p.phone === 'string' && p.phone.trim() ? p.phone.trim() : (cp.phone || '');
  const date = typeof p.date === 'string' && p.date.trim() ? p.date.trim() : (cp.date || new Date().toLocaleDateString('es-VE'));
  const address = typeof p.address === 'string' && p.address.trim() ? p.address.trim() : (cp.address || '');
  const guideNumber = typeof p.guideNumber === 'string' && p.guideNumber.trim() ? p.guideNumber.trim() : (cp.guideNumber || '');
  const condition = (p.condition === 'Familiar' || p.condition === 'FAMILIAR' || parsedData.restCertificate?.condition === 'FAMILIAR') ? 'Familiar' : (cp.condition || 'Paciente');

  const diagnosisPrincipal = typeof parsedData.diagnosisPrincipal === 'string' ? parsedData.diagnosisPrincipal.trim() : '';

  const pharmacy = typeof parsedData.recipeDual?.pharmacy === 'string' ? parsedData.recipeDual.pharmacy.trim() : '';
  
  // LÓGICA DE ROBUSTEZ: Si Gemini deja las indicaciones vacías pero hay fármacos en farmacia, se usa un fallback inteligente para garantizar la simetría del récipe
  let patientIndications = typeof parsedData.recipeDual?.patientIndications === 'string' ? parsedData.recipeDual.patientIndications.trim() : '';
  
  if (pharmacy !== '' && patientIndications === '') {
    patientIndications = `INDICACIONES:\n\n${pharmacy}\n(Tomar según pauta médica recomendada)`;
  }

  const clinicalReport = typeof parsedData.clinicalReport === 'string' ? parsedData.clinicalReport.trim() : '';

  // Lab order
  const rawOrdenLab = parsedData.ordenLab || {};
  const perfilPreoperatorio = Array.isArray(rawOrdenLab.perfilPreoperatorio) ? rawOrdenLab.perfilPreoperatorio : [];
  const neuroimagen = Array.isArray(rawOrdenLab.neuroimagen) ? rawOrdenLab.neuroimagen : [];
  const otrosEstudios = Array.isArray(rawOrdenLab.otrosEstudios) ? rawOrdenLab.otrosEstudios : [];
  const labOrderText = typeof parsedData.labAndImagesOrder === 'string' ? parsedData.labAndImagesOrder.trim() : '';

  // Rest certificate
  const rc = parsedData.restCertificate || {};
  const restDaysNum = typeof rc.restDays === 'number' && rc.restDays >= 0 ? rc.restDays : 0;
  const needsRest = typeof rc.needsRest === 'boolean' ? rc.needsRest : restDaysNum > 0;
  const restFrom = typeof rc.restFrom === 'string' && rc.restFrom.trim() ? rc.restFrom.trim() : (needsRest ? date : '');
  let restTo = typeof rc.restTo === 'string' && rc.restTo.trim() ? rc.restTo.trim() : '';
  if (!restTo && needsRest && restDaysNum > 0) {
    const d = new Date();
    const future = new Date(d.getTime() + restDaysNum * 86400000);
    restTo = future.toLocaleDateString('es-VE');
  }

  // Clinical history
  const ch = parsedData.clinicalHistory || {};
  const motivoConsulta = typeof ch.consultReason === 'string' ? ch.consultReason.trim() : (typeof ch.motivoConsulta === 'string' ? ch.motivoConsulta.trim() : '');
  const enfermedadActual = typeof ch.currentIllness === 'string' ? ch.currentIllness.trim() : (typeof ch.enfermedadActual === 'string' ? ch.enfermedadActual.trim() : '');
  const antecedentes = typeof ch.background === 'string' ? ch.background.trim() : (typeof ch.antecedentes === 'string' ? ch.antecedentes.trim() : '');
  const examenNeurologico = typeof ch.neuroExam === 'string' ? ch.neuroExam.trim() : (typeof ch.examenNeurologico === 'string' ? ch.examenNeurologico.trim() : '');
  const historiaDiag = typeof ch.diagnosis === 'string' ? ch.diagnosis.trim() : (typeof ch.diagnostico === 'string' ? ch.diagnostico.trim() : diagnosisPrincipal);

  const uncertainFields: string[] = Array.isArray(parsedData.uncertainFields)
    ? parsedData.uncertainFields.filter((item: any) => typeof item === 'string')
    : [];

  const requiresReview = uncertainFields.length > 0 || !fullName || !idNumber || !diagnosisPrincipal;

  return {
    extractedTranscript: typeof parsedData.extractedTranscript === 'string' ? parsedData.extractedTranscript : '',
    requiresReview,
    uncertainFields,
    patient: {
      fullName,
      idNumber,
      age,
      phone,
      date,
      address,
      guideNumber,
      condition,
    },
    diagnosisPrincipal,
    cie10Suggestions: Array.isArray(parsedData.cie10Suggestions) ? parsedData.cie10Suggestions : [],
    recipeDual: {
      pharmacy,
      patientIndications,
    },
    recipe: {
      rxLeft: pharmacy,
      indicationsRight: patientIndications,
    },
    clinicalReport,
    informe: {
      bodyText: clinicalReport,
      diagnostico: diagnosisPrincipal,
      motivo: motivoConsulta,
      antecedentes,
      enfermedadActual,
      examenFisico: examenNeurologico,
      estudiosParaclinicos: labOrderText,
      planConducta: '',
    },
    labAndImagesOrder: labOrderText,
    ordenLab: {
      perfilPreoperatorio,
      neuroimagen,
      otrosEstudios,
      diagnosticoPresuntivo: typeof rawOrdenLab.diagnosticoPresuntivo === 'string' ? rawOrdenLab.diagnosticoPresuntivo : diagnosisPrincipal,
    },
    restCertificate: {
      needsRest,
      restDays: restDaysNum,
      restFrom,
      restTo,
      condition: condition === 'Familiar' ? 'FAMILIAR' : 'PACIENTE',
      idx: typeof rc.idx === 'string' && rc.idx.trim() ? rc.idx.trim() : diagnosisPrincipal,
    },
    constancia: {
      attendedDate: date,
      condition,
      needsRest,
      restDays: restDaysNum > 0 ? String(restDaysNum).padStart(2, '0') : '00',
      restDaysWords: restDaysNum > 0 ? `${restDaysNum} días continuos` : 'Cero (00) días',
      restFrom,
      restTo: needsRest ? restTo : '',
      idx: typeof rc.idx === 'string' && rc.idx.trim() ? rc.idx.trim() : diagnosisPrincipal,
      requestDay: String(new Date().getDate()).padStart(2, '0'),
      requestMonth: new Intl.DateTimeFormat('es-VE', { month: 'long' }).format(new Date()).toUpperCase(),
      requestYear: String(new Date().getFullYear()),
    },
    clinicalHistory: {
      consultReason: motivoConsulta,
      currentIllness: enfermedadActual,
      background: antecedentes,
      neuroExam: examenNeurologico,
      diagnosis: historiaDiag,
    },
    historia: {
      motivoConsulta,
      enfermedadActual,
      antecedentes,
      examenNeurologico,
      diagnostico: historiaDiag,
    },
  };
}

// Robust JSON cleaning & extraction helper
function safelyParseJsonResponse(rawText: string): any {
  if (!rawText || typeof rawText !== 'string') {
    throw new Error('Texto de respuesta vacío o no válido.');
  }

  let text = rawText.trim();

  // Strip markdown code block fences if present
  if (text.startsWith('```json')) {
    text = text.substring(7);
  } else if (text.startsWith('```')) {
    text = text.substring(3);
  }
  if (text.endsWith('```')) {
    text = text.substring(0, text.length - 3);
  }
  text = text.trim();

  // 1. Direct parse attempt
  try {
    return JSON.parse(text);
  } catch (e1) {
    // 2. Try extracting the first valid JSON object / array substring
    const firstOpenBrace = text.indexOf('{');
    const lastCloseBrace = text.lastIndexOf('}');
    if (firstOpenBrace !== -1 && lastCloseBrace > firstOpenBrace) {
      const candidate = text.substring(firstOpenBrace, lastCloseBrace + 1);
      try {
        return JSON.parse(candidate);
      } catch (e2) {
        // 3. Attempt common truncation repair: close unterminated strings, arrays, objects
        try {
          let repaired = candidate;
          const quoteMatches = repaired.match(/(?<!\\)"/g);
          if (quoteMatches && quoteMatches.length % 2 !== 0) {
            repaired += '"';
          }
          const openBrackets = (repaired.match(/\[/g) || []).length;
          const closeBrackets = (repaired.match(/\]/g) || []).length;
          for (let i = 0; i < openBrackets - closeBrackets; i++) {
            repaired += ']';
          }
          const openBraces = (repaired.match(/\{/g) || []).length;
          const closeBraces = (repaired.match(/\}/g) || []).length;
          for (let i = 0; i < openBraces - closeBraces; i++) {
            repaired += '}';
          }
          return JSON.parse(repaired);
        } catch (e3) {
          throw new Error(`JSON no parseable tras intentos de saneamiento: ${(e1 as Error).message}`);
        }
      }
    }
    throw e1;
  }
}

// Lista prioritaria de modelos Gemini para Failover / Fallback (conmutación inteligente de alta disponibilidad)
const FALLBACK_MODELS = [
  'gemini-flash-latest',
  'gemini-3.8-flash',
  'gemini-3.1-flash-lite',
  'gemini-3.5-transcribe',
  'gemini-3.1-pro-preview',
];

// API Endpoint: Extract Clinical Summary (Texto / Dictado)
app.post('/api/gemini/extract-clinical-summary', async (req, res) => {
  try {
    const { transcript, currentData } = req.body;

    if (!transcript || typeof transcript !== 'string' || transcript.trim().length === 0) {
      return res.status(400).json({
        success: false,
        requiresReview: true,
        data: {},
        error: 'El texto del dictado clínico no puede estar vacío.'
      });
    }

    const ai = getGeminiClient();

    if (!ai) {
      return res.status(503).json({
        success: false,
        requiresReview: true,
        data: {},
        error: 'Servicio de IA no configurado en el servidor (GEMINI_API_KEY no presente).'
      });
    }

    const prompt = `Analiza el siguiente dictado clínico continuo del Dr. Samir Moucharrafie Naime (Especialista en Neurocirugía / UCBL Lyon 1) y extrae de forma estructurada los datos para los 5 documentos clínicos oficiales.
Fecha de referencia: ${new Date().toLocaleDateString('es-VE')}

DICTADO CLÍNICO:
"""
${transcript}
"""

${currentData ? `DATOS PREVIOS EXISTENTES (conservar solo los datos que correspondan al paciente actual):\n${JSON.stringify(currentData, null, 2)}` : ''}

RECUERDA: NO inventar ningún dato que no aparezca en la fuente. Dejar campos no mencionados como strings vacíos.`;

    let responseText = '';
    let usedModel = '';

    // PIPELINE DE CONMUTACIÓN DE MODELOS GEMINI
    for (const modelName of FALLBACK_MODELS) {
      try {
        console.log(`[AI Pipeline] Intentando extracción con modelo: ${modelName}...`);
        const response = await ai.models.generateContent({
          model: modelName,
          contents: prompt,
          config: {
            systemInstruction: CLINICAL_SYSTEM_INSTRUCTION,
            temperature: 0.05,
            topP: 0.95,
            responseMimeType: 'application/json',
            responseSchema: CLINICAL_EXTRACTION_SCHEMA,
          },
        });

        if (response.text) {
          responseText = response.text;
          usedModel = modelName;
          console.log(`[AI Pipeline] Éxito en extracción estructurada con: ${modelName}`);
          break;
        }
      } catch (modelErr: any) {
        const is503 = modelErr?.message?.includes('503') || modelErr?.status === 503 || String(modelErr).includes('503');
        console.warn(`[AI Pipeline] ${is503 ? 'Alta demanda temporal (503)' : 'Fallo'} en modelo ${modelName}, conmutando a siguiente modelo de respaldo.`);
        if (is503) {
          await new Promise((r) => setTimeout(r, 200));
        }
      }
    }

    if (!responseText) {
      return res.status(502).json({
        success: false,
        requiresReview: true,
        data: {},
        error: 'No fue posible extraer los datos clínicos con suficiente confianza tras consultar los modelos de IA.'
      });
    }

    let parsedData: any = null;
    try {
      parsedData = safelyParseJsonResponse(responseText);
    } catch (parseErr: any) {
      return res.status(422).json({
        success: false,
        requiresReview: true,
        data: {},
        error: 'La respuesta de IA no pudo ser parseada como JSON válido.'
      });
    }

    const validation = validateClinicalExtractionSchema(parsedData);
    if (!validation.valid) {
      return res.status(422).json({
        success: false,
        requiresReview: true,
        data: {},
        error: `Respuesta de IA con esquema inválido: ${validation.errors.join(', ')}`
      });
    }

    const formattedData = formatClinicalData(parsedData, currentData);

    return res.json({
      success: true,
      requiresReview: formattedData.requiresReview,
      uncertainFields: formattedData.uncertainFields,
      source: usedModel,
      usedModel,
      isLocalFallback: false,
      data: formattedData,
    });
  } catch (error: any) {
    console.error('Error no controlado en extracción clínica:', error);
    return res.status(500).json({
      success: false,
      requiresReview: true,
      data: {},
      error: `Error interno al procesar extracción clínica: ${error.message || 'Error desconocido'}`
    });
  }
});

// API Endpoint: Extract Clinical Summary Directly From Audio (Multimodal Audio Gemini)
app.post('/api/gemini/extract-from-audio', async (req, res) => {
  try {
    const { audioBase64, mimeType, currentData } = req.body;

    if (!audioBase64 || typeof audioBase64 !== 'string' || audioBase64.trim().length < 100) {
      return res.status(400).json({
        success: false,
        requiresReview: true,
        data: {},
        error: 'El archivo de audio está vacío, incompleto o no es legible.'
      });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        success: false,
        requiresReview: true,
        data: {},
        error: 'Servicio Gemini no configurado en servidor. Configure GEMINI_API_KEY.',
      });
    }

    const promptText = `Escucha con máxima atención el dictado clínico continuo de voz del Dr. Samir Moucharrafie Naime (Neurocirujano / UCBL Lyon 1 - Francia).
1. Transcribe exactamente palabra por palabra todo lo dictado por el Dr. Samir en el campo "extractedTranscript".
2. Normaliza la terminología neuroquirúrgica (maniobras radiculares, niveles discales, fármacos con posología).
3. Estructura y mapea los datos a los 5 documentos médicos oficiales (patient, diagnosisPrincipal, cie10Suggestions, recipeDual, clinicalReport, labAndImagesOrder, restCertificate, clinicalHistory, uncertainFields).
4. REGLA FUNDAMENTAL: NUNCA inventes datos no mencionados. Deja los campos no dichos como "".
${currentData ? `DATOS PREVIOS:\n${JSON.stringify(currentData, null, 2)}` : ''}
Fecha de referencia: ${new Date().toLocaleDateString('es-VE')}`;

    const cleanMimeType = (mimeType || 'audio/webm').split(';')[0];
    let responseText = '';
    let usedAudioModel = '';

    // Intentar con la cadena de modelos prioritarios para audio multimodal
    for (const modelName of FALLBACK_MODELS) {
      try {
        console.log(`[AI Audio Pipeline] Intentando extracción multimodal con: ${modelName}...`);
        const response = await ai.models.generateContent({
          model: modelName,
          contents: [
            {
              role: 'user',
              parts: [
                {
                  inlineData: {
                    mimeType: cleanMimeType,
                    data: audioBase64,
                  },
                },
                {
                  text: promptText,
                },
              ],
            },
          ],
          config: {
            systemInstruction: CLINICAL_SYSTEM_INSTRUCTION,
            temperature: 0.05,
            topP: 0.95,
            responseMimeType: 'application/json',
            responseSchema: CLINICAL_EXTRACTION_SCHEMA,
          },
        });

        if (response.text) {
          responseText = response.text;
          usedAudioModel = modelName;
          console.log(`[AI Audio Pipeline] Éxito en audio multimodal con: ${modelName}`);
          break;
        }
      } catch (audioModelErr: any) {
        const is503 = audioModelErr?.message?.includes('503') || audioModelErr?.status === 503 || String(audioModelErr).includes('503');
        console.warn(`[AI Audio Pipeline] ${is503 ? 'Alta demanda temporal (503)' : 'Fallo'} en modelo ${modelName}, conmutando a siguiente modelo de respaldo.`);
        // Pequeño backoff no bloqueante de 200ms si es 503 para aliviar congestión
        if (is503) {
          await new Promise((r) => setTimeout(r, 200));
        }
      }
    }

    if (!responseText) {
      return res.status(502).json({
        success: false,
        requiresReview: true,
        data: {},
        error: 'No fue posible procesar el audio clínico tras consultar los modelos de IA.'
      });
    }

    let parsedData: any = null;
    try {
      parsedData = safelyParseJsonResponse(responseText);
    } catch (parseErr: any) {
      return res.status(422).json({
        success: false,
        requiresReview: true,
        data: {},
        error: 'La respuesta de audio de la IA no pudo ser parseada como JSON válido.'
      });
    }

    const validation = validateClinicalExtractionSchema(parsedData);
    if (!validation.valid) {
      return res.status(422).json({
        success: false,
        requiresReview: true,
        data: {},
        error: `Respuesta de audio de IA con esquema inválido: ${validation.errors.join(', ')}`
      });
    }

    const formattedData = formatClinicalData(parsedData, currentData);

    return res.json({
      success: true,
      requiresReview: formattedData.requiresReview,
      uncertainFields: formattedData.uncertainFields,
      source: usedAudioModel || 'gemini-audio-multimodal',
      usedModel: usedAudioModel,
      isLocalFallback: false,
      transcript: parsedData.extractedTranscript || '',
      data: formattedData,
    });
  } catch (error: any) {
    console.error('[AI Audio Pipeline] Error controlado:', error?.message || 'Error desconocido');
    return res.status(500).json({
      success: false,
      requiresReview: true,
      data: {},
      error: `Error interno al procesar audio clínico: ${error.message || 'Error desconocido'}`
    });
  }
});

// API Endpoint: Quick Voice Correction (Edición Quirúrgica de Documentos)
app.post('/api/gemini/quick-correction', async (req, res) => {
  const startTime = Date.now();
  const requestId = `corr_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  try {
    const { command, currentDocumentState, docType } = req.body;
    if (!command || typeof command !== 'string' || command.trim().length === 0) {
      return res.status(400).json({
        success: false,
        error: 'El comando de corrección no puede estar vacío.'
      });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        success: false,
        error: 'Servicio Gemini no disponible.'
      });
    }

    const promptText = `Eres el Asistente Clínico de Neurocirugía del Dr. Samir Moucharrafie Naime.
Aplica quirúrgicamente la siguiente corrección o ajuste puntual al documento médico tipo "${docType}".
COMANDO DEL MÉDICO: "${command}"
ESTADO ACTUAL DEL DOCUMENTO:
${JSON.stringify(currentDocumentState || {}, null, 2)}

REGLAS ESTRICTAS DE SEGURIDAD CLÍNICA:
1. Aplica EXCLUSIVAMENTE el cambio ordenado por el médico.
2. Conserva intactos todos los demás campos existentes del documento sin modificarlos ni borrarlos.
3. NUNCA agregues medicamentos, dosis ni diagnósticos no especificados en el comando.
4. Devuelve ÚNICAMENTE el objeto JSON con la estructura actualizada del documento.`;

    let responseText = '';
    for (const modelName of FALLBACK_MODELS) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: promptText,
          config: {
            temperature: 0.05,
            responseMimeType: 'application/json',
          }
        });
        if (response.text) {
          responseText = response.text;
          break;
        }
      } catch (err: any) {
        // Fallback al siguiente modelo
      }
    }

    if (!responseText) {
      return res.status(502).json({
        success: false,
        error: 'No se pudo generar la corrección con los modelos de IA.'
      });
    }

    const parsed = safelyParseJsonResponse(responseText);
    const durationMs = Date.now() - startTime;
    console.log(`[Quick Correction] Request ${requestId} completada en ${durationMs}ms para docType: ${docType}`);

    return res.json({
      success: true,
      data: parsed,
      command,
    });
  } catch (error: any) {
    console.error(`[Quick Correction] Error en request ${requestId}:`, error.message);
    return res.status(500).json({
      success: false,
      error: `Error al procesar corrección: ${error.message || 'Error desconocido'}`
    });
  }
});

// Helper: Rasterizar páginas de un documento PDF oficial a buffers JPEG usando Ghostscript & Sharp
interface RasterizedPdfPage {
  pageNumber: number;
  buffer: Buffer;
  width: number;
  height: number;
}

async function rasterizePdfToJpegBuffers(
  pdfBuffer: Buffer,
  width = 2480,
  height = 3508,
  pageNumber?: number,
  maxPages = 10
): Promise<RasterizedPdfPage[]> {
  const tmpId = `pdf_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const tmpDir = path.join('/tmp', tmpId);
  fs.mkdirSync(tmpDir, { recursive: true });
  const tmpIn = path.join(tmpDir, 'in.pdf');
  const outPattern = path.join(tmpDir, 'page_%03d.jpg');

  try {
    fs.writeFileSync(tmpIn, pdfBuffer);
    const { execSync } = await import('child_process');

    // Si se solicitó una página específica, limitar Ghostscript a esa página
    const pageArg = pageNumber && pageNumber > 0
      ? `-dFirstPage=${pageNumber} -dLastPage=${pageNumber}`
      : `-dFirstPage=1 -dLastPage=${maxPages}`;

    execSync(`gs -q -dNOPAUSE -dBATCH -sDEVICE=jpeg -r200 ${pageArg} -sOutputFile="${outPattern}" "${tmpIn}"`);

    const pageFiles = fs.readdirSync(tmpDir)
      .filter((f) => f.startsWith('page_') && f.endsWith('.jpg'))
      .sort();

    if (pageFiles.length === 0) {
      throw new Error('Ghostscript no generó imágenes del archivo PDF.');
    }

    const sharp = (await import('sharp')).default;
    const results: RasterizedPdfPage[] = [];

    for (let i = 0; i < pageFiles.length; i++) {
      const rawJpeg = fs.readFileSync(path.join(tmpDir, pageFiles[i]));
      const processed = await sharp(rawJpeg)
        .resize(width, height, { fit: 'fill' })
        .jpeg({ quality: 92 })
        .toBuffer();

      const actualPageNum = pageNumber && pageNumber > 0 ? pageNumber : (i + 1);
      results.push({
        pageNumber: actualPageNum,
        buffer: processed,
        width,
        height,
      });
    }

    return results;
  } finally {
    try {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    } catch (_) {}
  }
}

// API Endpoint: Rasterizar plantilla PDF a imagen de alta resolución (WebP/JPEG) con soporte multipágina
app.post('/api/templates/rasterize-pdf', async (req, res) => {
  try {
    let { pdfBase64, maxWidth = 2480, maxHeight = 3508, pageNumber } = req.body;
    if (!pdfBase64) {
      return res.status(400).json({ success: false, error: 'No se recibió pdfBase64' });
    }
    if (pdfBase64.includes('base64,')) {
      pdfBase64 = pdfBase64.split('base64,')[1];
    }

    const pdfBuffer = Buffer.from(pdfBase64, 'base64');
    const sharp = (await import('sharp')).default;
    const rasterizedPages = await rasterizePdfToJpegBuffers(
      pdfBuffer,
      maxWidth,
      maxHeight,
      pageNumber ? Number(pageNumber) : undefined
    );

    const pages = [];
    for (const p of rasterizedPages) {
      const optimized = await sharp(p.buffer)
        .webp({ quality: 90 })
        .toBuffer();

      const dataUrl = `data:image/webp;base64,${optimized.toString('base64')}`;
      const lqipHeight = Math.max(20, Math.round((36 * p.height) / p.width));
      const lqip = await sharp(p.buffer)
        .resize(36, lqipHeight)
        .jpeg({ quality: 40 })
        .toBuffer();
      const lqipDataUrl = `data:image/jpeg;base64,${lqip.toString('base64')}`;

      const origSize = Math.round(pdfBuffer.length / rasterizedPages.length);
      const optSize = optimized.length;
      const savedPct = Math.max(0, Math.round(((origSize - optSize) / origSize) * 100));

      pages.push({
        pageNumber: p.pageNumber,
        dataUrl,
        lqipDataUrl,
        width: p.width,
        height: p.height,
        mimeType: 'image/webp',
        originalSizeBytes: origSize,
        optimizedSizeBytes: optSize,
        savedPercentage: savedPct,
      });
    }

    const firstPage = pages[0];
    const totalOptimizedSize = pages.reduce((acc, pg) => acc + pg.optimizedSizeBytes, 0);

    return res.json({
      success: true,
      pageCount: pages.length,
      dataUrl: firstPage.dataUrl,
      lqipDataUrl: firstPage.lqipDataUrl,
      width: firstPage.width,
      height: firstPage.height,
      mimeType: 'image/webp',
      originalSizeBytes: pdfBuffer.length,
      optimizedSizeBytes: totalOptimizedSize,
      savedPercentage: Math.max(0, Math.round(((pdfBuffer.length - totalOptimizedSize) / pdfBuffer.length) * 100)),
      pages,
    });
  } catch (err: any) {
    console.error('Error rasterizando PDF a imagen:', err);
    return res.status(500).json({ success: false, error: err.message || 'Error al rasterizar PDF' });
  }
});

// API Endpoint: Intelligent Visual Template Calibration (DESACTIVADA RE-CALIBRACIÓN DINÁMICA - HARDCODED MASTER)
app.post('/api/gemini/calibrate-template-image', async (req, res) => {
  try {
    const { docType = 'RECIPES' } = req.body;
    console.log(`[Master Calibration] Entregando coordenadas fijas oficiales para ${docType} (re-calibración dinámica desactivada).`);
    return res.json({
      success: true,
      source: 'hardcoded-master-calibration',
      calibration: getOpticalLinedFallback(docType),
    });
  } catch (error: any) {
    console.error('Error en calibración fija:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Error al obtener calibración maestra',
    });
  }
});

function normalizeCalibrationResponse(raw: any, docType: string): Record<string, any> {
  const fallback = getOpticalLinedFallback(docType);
  if (!raw || typeof raw !== 'object') return fallback;

  const result: Record<string, any> = { ...fallback };

  // Aplanar si viene anidado en left_prescription_side, right_indications_side, etc.
  const flatMap: Record<string, any> = {};
  function extractFields(obj: any, prefix = '') {
    for (const key of Object.keys(obj)) {
      const val = obj[key];
      if (val && typeof val === 'object' && typeof val.top === 'number') {
        flatMap[key] = val;
        if (prefix) flatMap[`${prefix}.${key}`] = val;
      } else if (val && typeof val === 'object' && !Array.isArray(val)) {
        extractFields(val, key);
      }
    }
  }
  extractFields(raw);

  // Mapear según tipo de documento
  if (docType === 'RECIPES') {
    const leftName = flatMap['patient.fullName'] || flatMap['left_prescription_side.patient_name'] || flatMap['patient_name'] || flatMap['fullName'];
    if (leftName) result['patient.fullName'] = { ...result['patient.fullName'], ...leftName, id: 'patient.fullName' };

    const leftId = flatMap['patient.idNumber'] || flatMap['left_prescription_side.patient_id'] || flatMap['patient_id'] || flatMap['idNumber'] || flatMap['cedula'];
    if (leftId) result['patient.idNumber'] = { ...result['patient.idNumber'], ...leftId, id: 'patient.idNumber' };

    const leftAge = flatMap['patient.age'] || flatMap['left_prescription_side.age'] || flatMap['age'] || flatMap['edad'];
    if (leftAge) result['patient.age'] = { ...result['patient.age'], ...leftAge, id: 'patient.age' };

    const leftDate = flatMap['patient.date'] || flatMap['left_prescription_side.date'] || flatMap['date'] || flatMap['fecha'];
    if (leftDate) result['patient.date'] = { ...result['patient.date'], ...leftDate, id: 'patient.date' };

    const leftRx = flatMap['recipe.rxLeft'] || flatMap['left_prescription_side.rx_body'] || flatMap['rx_body'] || flatMap['rx'];
    if (leftRx) result['recipe.rxLeft'] = { ...result['recipe.rxLeft'], ...leftRx, id: 'recipe.rxLeft' };

    const leftStamp = flatMap['stamp.left'] || flatMap['left_prescription_side.signature_seal'] || flatMap['stamp'];
    if (leftStamp) result['stamp.left'] = { ...result['stamp.left'], ...leftStamp, id: 'stamp.left' };

    const rightName = flatMap['patient.fullNameRight'] || flatMap['right_indications_side.patient_name'] || flatMap['patient_name_right'];
    if (rightName) result['patient.fullNameRight'] = { ...result['patient.fullNameRight'], ...rightName, id: 'patient.fullNameRight' };

    const rightId = flatMap['patient.idNumberRight'] || flatMap['right_indications_side.patient_id'] || flatMap['patient_id_right'];
    if (rightId) result['patient.idNumberRight'] = { ...result['patient.idNumberRight'], ...rightId, id: 'patient.idNumberRight' };

    const rightAge = flatMap['patient.ageRight'] || flatMap['right_indications_side.age'] || flatMap['age_right'];
    if (rightAge) result['patient.ageRight'] = { ...result['patient.ageRight'], ...rightAge, id: 'patient.ageRight' };

    const rightDate = flatMap['patient.dateRight'] || flatMap['right_indications_side.date'] || flatMap['date_right'];
    if (rightDate) result['patient.dateRight'] = { ...result['patient.dateRight'], ...rightDate, id: 'patient.dateRight' };

    const rightInd = flatMap['recipe.indicationsRight'] || flatMap['right_indications_side.indications_body'] || flatMap['indications_body'] || flatMap['indications'];
    if (rightInd) result['recipe.indicationsRight'] = { ...result['recipe.indicationsRight'], ...rightInd, id: 'recipe.indicationsRight' };

    const rightStamp = flatMap['stamp.right'] || flatMap['right_indications_side.signature_seal'];
    if (rightStamp) result['stamp.right'] = { ...result['stamp.right'], ...rightStamp, id: 'stamp.right' };
  } else {
    // Si viene con claves exactas, incorporarlas
    for (const key of Object.keys(result)) {
      if (flatMap[key]) {
        result[key] = { ...result[key], ...flatMap[key], id: key };
      }
    }
  }

  return result;
}

function getOpticalLinedFallback(docType: string): Record<string, any> {
  // Intentar cargar directamente del archivo maestro data/calibrations.json
  try {
    if (fs.existsSync(CALIBRATIONS_FILE_PATH)) {
      const data = JSON.parse(fs.readFileSync(CALIBRATIONS_FILE_PATH, 'utf-8'));
      if (data && data[docType]) {
        return data[docType];
      }
    }
  } catch {
    // Continuar al fallback estático
  }

  if (docType === 'RECIPES') {
    return {
      'patient.fullName': { id: 'patient.fullName', label: 'Talón Izq: Nombre del Paciente', top: 198, left: 118, width: 240, height: 26, fontSize: 11, fontWeight: 'bold', textAlign: 'left' },
      'patient.idNumber': { id: 'patient.idNumber', label: 'Talón Izq: Cédula de Identidad', top: 247, left: 35, width: 130, height: 26, fontSize: 11, fontWeight: 'bold', textAlign: 'left' },
      'patient.age': { id: 'patient.age', label: 'Talón Izq: Edad', top: 250, left: 145, width: 105, height: 26, fontSize: 11, fontWeight: 'bold', textAlign: 'center' },
      'patient.date': { id: 'patient.date', label: 'Talón Izq: Fecha', top: 249, left: 244, width: 150, height: 26, fontSize: 11, fontWeight: 'bold', textAlign: 'center' },
      'recipe.rxLeft': { id: 'recipe.rxLeft', label: 'Talón Izq: Rp. (Farmacia)', top: 303, left: 21, width: 335, height: 650, fontSize: 12, lineHeight: 21, fontWeight: 'semibold', textAlign: 'left' },
      'stamp.left': { id: 'stamp.left', label: 'Talón Izq: Sello Médico', top: 898, left: 230, width: 140, height: 70, scale: 0.75 },
      'patient.fullNameRight': { id: 'patient.fullNameRight', label: 'Talón Der: Nombre del Paciente', top: 196, left: 511, width: 240, height: 26, fontSize: 11, fontWeight: 'bold', textAlign: 'left' },
      'patient.idNumberRight': { id: 'patient.idNumberRight', label: 'Talón Der: Cédula de Identidad', top: 244, left: 435, width: 130, height: 26, fontSize: 11, fontWeight: 'bold', textAlign: 'left' },
      'patient.ageRight': { id: 'patient.ageRight', label: 'Talón Der: Edad', top: 245, left: 545, width: 105, height: 26, fontSize: 11, fontWeight: 'bold', textAlign: 'center' },
      'patient.dateRight': { id: 'patient.dateRight', label: 'Talón Der: Fecha', top: 246, left: 645, width: 150, height: 26, fontSize: 11, fontWeight: 'bold', textAlign: 'center' },
      'recipe.indicationsRight': { id: 'recipe.indicationsRight', label: 'Talón Der: Indicaciones al Paciente', top: 301, left: 428, width: 335, height: 650, fontSize: 12, lineHeight: 21, fontWeight: 'semibold', textAlign: 'left' },
      'stamp.right': { id: 'stamp.right', label: 'Talón Der: Sello Médico', top: 893, left: 630, width: 140, height: 70, scale: 0.75 }
    };
  } else if (docType === 'INFORME') {
    return {
      'patient.fullName': { id: 'patient.fullName', label: 'Nombre del Paciente', top: 152, left: 65, width: 420, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.idNumber': { id: 'patient.idNumber', label: 'Cédula de Identidad', top: 152, left: 495, width: 235, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.age': { id: 'patient.age', label: 'Edad', top: 184, left: 65, width: 340, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.date': { id: 'patient.date', label: 'Fecha', top: 184, left: 415, width: 315, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'informe.bodyText': { id: 'informe.bodyText', label: 'Cuerpo del Informe Médico', top: 225, left: 65, width: 665, height: 710, fontSize: 12.5, lineHeight: 24, fontWeight: 'normal', textAlign: 'justify' },
      'stamp': { id: 'stamp', label: 'Sello Médico Oficial (Dr. Samir Moucharrafie)', top: 940, left: 540, width: 160, height: 80, scale: 0.85 }
    };
  } else if (docType === 'ORDEN_LAB') {
    return {
      'patient.fullName': { id: 'patient.fullName', label: 'Nombre y Apellido', top: 152, left: 65, width: 420, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.idNumber': { id: 'patient.idNumber', label: 'Cédula de Identidad', top: 152, left: 495, width: 235, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.age': { id: 'patient.age', label: 'Edad', top: 184, left: 65, width: 340, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.date': { id: 'patient.date', label: 'Fecha', top: 184, left: 415, width: 315, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'orden.col_izquierda': { id: 'orden.col_izquierda', label: 'Columna Izquierda', top: 235, left: 55, width: 220, height: 615, fontSize: 11, lineHeight: 20, fontWeight: 'semibold', textAlign: 'left' },
      'orden.col_centro': { id: 'orden.col_centro', label: 'Columna Centro', top: 235, left: 280, width: 220, height: 615, fontSize: 11, lineHeight: 20, fontWeight: 'semibold', textAlign: 'left' },
      'orden.col_derecha': { id: 'orden.col_derecha', label: 'Columna Derecha', top: 235, left: 510, width: 220, height: 615, fontSize: 11, lineHeight: 20, fontWeight: 'semibold', textAlign: 'left' },
      'stamp': { id: 'stamp', label: 'Sello Médico (Página 1)', top: 935, left: 540, width: 160, height: 80, scale: 0.85 }
    };
  } else if (docType === 'ORDEN_LAB_P2') {
    return {
      'orden_p2.patientName': { id: 'orden_p2.patientName', label: 'Agradezco practicar a (Nombre)', top: 285, left: 230, width: 480, height: 26, fontSize: 11, fontWeight: 'bold', textAlign: 'left' },
      'orden_p2.idNumber': { id: 'orden_p2.idNumber', label: 'Cédula de Identidad (P2)', top: 285, left: 620, width: 150, height: 26, fontSize: 11, fontWeight: 'bold', textAlign: 'left' },
      'orden_p2.date': { id: 'orden_p2.date', label: 'Fecha (P2)', top: 315, left: 230, width: 150, height: 26, fontSize: 11, fontWeight: 'bold', textAlign: 'left' },
      'orden_p2.diagnosis': { id: 'orden_p2.diagnosis', label: 'Con Impresión Diagnóstica (IDX)', top: 325, left: 260, width: 450, height: 80, fontSize: 11, lineHeight: 18, fontWeight: 'bold', textAlign: 'left' },
      'orden_p2.rmn_cerebral': { id: 'orden_p2.rmn_cerebral', label: 'Resonancia Magnética (RMN) [X]', top: 380, left: 65, width: 20, height: 20, shapeType: 'checkbox_x', markStyle: 'X', fieldType: 'checkbox', fontSize: 13, fontWeight: 'bold', textAlign: 'center' },
      'orden_p2.tac_cerebral': { id: 'orden_p2.tac_cerebral', label: 'Tomografía Axial (TAC) [X]', top: 420, left: 65, width: 20, height: 20, shapeType: 'checkbox_x', markStyle: 'X', fieldType: 'checkbox', fontSize: 13, fontWeight: 'bold', textAlign: 'center' },
      'orden_p2.radiologia': { id: 'orden_p2.radiologia', label: 'Radiología [X]', top: 460, left: 65, width: 20, height: 20, shapeType: 'checkbox_x', markStyle: 'X', fieldType: 'checkbox', fontSize: 13, fontWeight: 'bold', textAlign: 'center' },
      'orden_p2.emg': { id: 'orden_p2.emg', label: 'Electromiografía (EMG) [X]', top: 500, left: 65, width: 20, height: 20, shapeType: 'checkbox_x', markStyle: 'X', fieldType: 'checkbox', fontSize: 13, fontWeight: 'bold', textAlign: 'center' },
      'orden_p2.eeg': { id: 'orden_p2.eeg', label: 'Electroencefalograma (EEG) [X]', top: 540, left: 65, width: 20, height: 20, shapeType: 'checkbox_x', markStyle: 'X', fieldType: 'checkbox', fontSize: 13, fontWeight: 'bold', textAlign: 'center' },
      'orden_p2.pess': { id: 'orden_p2.pess', label: 'Potenciales Evocados (PESS) [X]', top: 580, left: 65, width: 20, height: 20, shapeType: 'checkbox_x', markStyle: 'X', fieldType: 'checkbox', fontSize: 13, fontWeight: 'bold', textAlign: 'center' },
      'stamp': { id: 'stamp', label: 'Sello Médico (Página 2)', top: 940, left: 540, width: 160, height: 80, scale: 0.85 }
    };
  } else if (docType === 'CONSTANCIA') {
    return {
      'patient.fullName': { id: 'patient.fullName', label: 'Nombre y Apellido', top: 240, left: 65, width: 440, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.idNumber': { id: 'patient.idNumber', label: 'Cédula de Identidad', top: 240, left: 515, width: 215, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.date': { id: 'patient.date', label: 'Fecha de Consulta', top: 282, left: 65, width: 320, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'center' },
      'constancia.condition_label': { id: 'constancia.condition_label', label: 'Condición (Paciente / Familiar)', top: 320, left: 65, width: 300, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'constancia.cond_paciente': { id: 'constancia.cond_paciente', label: 'Casilla Paciente [X]', top: 320, left: 170, width: 16, height: 16, shapeType: 'checkbox_x', markStyle: 'X', fieldType: 'checkbox', fontSize: 12, fontWeight: 'bold', textAlign: 'center' },
      'constancia.cond_familiar': { id: 'constancia.cond_familiar', label: 'Casilla Familiar [X]', top: 320, left: 260, width: 16, height: 16, shapeType: 'checkbox_x', markStyle: 'X', fieldType: 'checkbox', fontSize: 12, fontWeight: 'bold', textAlign: 'center' },
      'constancia.amerita_label': { id: 'constancia.amerita_label', label: 'Amerita Reposo Médico', top: 320, left: 390, width: 340, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'constancia.reposo_si': { id: 'constancia.reposo_si', label: 'Casilla Sí [X]', top: 320, left: 515, width: 16, height: 16, shapeType: 'checkbox_x', markStyle: 'X', fieldType: 'checkbox', fontSize: 12, fontWeight: 'bold', textAlign: 'center' },
      'constancia.reposo_no': { id: 'constancia.reposo_no', label: 'Casilla No [X]', top: 320, left: 565, width: 16, height: 16, shapeType: 'checkbox_x', markStyle: 'X', fieldType: 'checkbox', fontSize: 12, fontWeight: 'bold', textAlign: 'center' },
      'constancia.restDays': { id: 'constancia.restDays', label: 'Campo Días (Número y Letras)', top: 320, left: 620, width: 110, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'center' },
      'constancia.rango_label': { id: 'constancia.rango_label', label: 'Rango de Reposo (Desde / Hasta)', top: 360, left: 65, width: 665, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'constancia.restFrom': { id: 'constancia.restFrom', label: 'Fecha Desde', top: 360, left: 290, width: 200, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'center' },
      'constancia.restTo': { id: 'constancia.restTo', label: 'Fecha Hasta', top: 360, left: 520, width: 210, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'center' },
      'constancia.idx': { id: 'constancia.idx', label: 'Diagnóstico Formal (IDX)', top: 410, left: 65, width: 665, height: 320, fontSize: 12.5, lineHeight: 24, fontWeight: 'semibold', textAlign: 'left' },
      'constancia.requestDay': { id: 'constancia.requestDay', label: 'Expedición (Días, Mes, Año)', top: 765, left: 65, width: 665, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'stamp': { id: 'stamp', label: 'Sello Médico Oficial (Dr. Samir Moucharrafie)', top: 890, left: 540, width: 160, height: 80, scale: 0.85 }
    };
  } else if (docType === 'HISTORIA') {
    return {
      'patient.fullName': { id: 'patient.fullName', label: 'Nombre y Apellido', top: 176, left: 142, width: 359, height: 29, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.idNumber': { id: 'patient.idNumber', label: 'Cédula de Identidad', top: 174, left: 556, width: 189, height: 29, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.age': { id: 'patient.age', label: 'Edad', top: 214, left: 45, width: 142, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.phone': { id: 'patient.phone', label: 'Teléfono', top: 214, left: 228, width: 142, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'patient.address': { id: 'patient.address', label: 'Dirección de Habitación', top: 217, left: 444, width: 297, height: 28, fontSize: 12, fontWeight: 'bold', textAlign: 'left' },
      'historia.motivo': { id: 'historia.motivo', label: 'Motivo de Consulta', top: 288, left: 42, width: 704, height: 63, fontSize: 12, lineHeight: 22, fontWeight: 'normal', textAlign: 'left' },
      'historia.enfermedad': { id: 'historia.enfermedad', label: 'Enfermedad Actual', top: 365, left: 36, width: 721, height: 141, fontSize: 12, lineHeight: 22, fontWeight: 'normal', textAlign: 'left' },
      'historia.antecedentes': { id: 'historia.antecedentes', label: 'Antecedentes Personales y Familiares', top: 547, left: 38, width: 721, height: 147, fontSize: 12, lineHeight: 22, fontWeight: 'normal', textAlign: 'left' },
      'historia.examen': { id: 'historia.examen', label: 'Examen Físico y Neurológico', top: 707, left: 38, width: 715, height: 171, fontSize: 12, lineHeight: 22, fontWeight: 'normal', textAlign: 'left' },
      'historia.diagnostico': { id: 'historia.diagnostico', label: 'Diagnóstico Definitivo / Presuntivo', top: 911, left: 39, width: 716, height: 126, fontSize: 12, lineHeight: 22, fontWeight: 'semibold', textAlign: 'left' },
      'stamp': { id: 'stamp', label: 'Sello Médico', top: 1036, left: 550, width: 160, height: 80, scale: 0.85 }
    };
  }
  return {};
}

// API Endpoint: Quick Voice Correction
app.post('/api/gemini/quick-correction', async (req, res) => {
  try {
    const { command, currentDocumentState, docType } = req.body;

    if (!command || typeof command !== 'string') {
      return res.status(400).json({ error: 'El comando de corrección no puede estar vacío.' });
    }

    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        success: false,
        error: 'Servicio de IA no disponible para corrección contextual.',
      });
    }

    const prompt = `Aplica la siguiente corrección puntual rápida dictada por el Dr. Samir sobre el documento tipo "${docType}".
COMANDO DE VOZ DEL DR. SAMIR: "${command}"

ESTADO ACTUAL DEL DOCUMENTO:
${JSON.stringify(currentDocumentState, null, 2)}

Aplica únicamente la modificación pedida (por ejemplo: agregar un medicamento, corregir días de reposo, actualizar cédula, cambiar fecha) sin perder ni borrar el resto de los datos existentes.
Devuelve el JSON del estado del documento actualizado en el mismo formato.`;

    let responseText = '';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction: 'Eres el motor de corrección rápida de SOCS. Aplica modificaciones puntuales en el JSON conservando el resto intacto.',
          temperature: 0.1,
          responseMimeType: 'application/json',
        },
      });
      responseText = response.text || '';
    } catch {
      const fallbackResponse = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: prompt,
        config: {
          temperature: 0.1,
          responseMimeType: 'application/json',
        },
      });
      responseText = fallbackResponse.text || '';
    }

    const updatedData = safelyParseJsonResponse(responseText);
    return res.json({
      success: true,
      data: updatedData,
    });
  } catch (err: any) {
    console.error('Error en corrección rápida:', err);
    return res.status(500).json({ error: err.message || 'Error al aplicar corrección.' });
  }
});

// Start Server with Vite Middleware
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SOCS] Servidor clínico CCMI activo en http://0.0.0.0:${PORT}`);
  });
}

startServer();
