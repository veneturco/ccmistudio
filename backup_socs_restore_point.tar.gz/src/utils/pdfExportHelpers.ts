export interface SharePdfOptions {
  phone?: string;
  patientName?: string;
  doctorName?: string;
  docTitle?: string;
  documentDate?: string;
  message?: string;
}

export function formatWhatsAppPhone(phone: string): string {
  if (!phone) return '';
  let cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('0') && cleaned.length === 11) {
    cleaned = '58' + cleaned.substring(1);
  } else if (!cleaned.startsWith('58') && cleaned.length === 10) {
    cleaned = '58' + cleaned;
  }
  return cleaned;
}

export function sanitizeFileName(name: string): string {
  return name
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9_\-\.]/g, '_')
    .replace(/_+/g, '_');
}

export function toBlobPart(data: Uint8Array | ArrayBuffer | Blob): BlobPart {
  if (data instanceof Blob) return data;
  if (data instanceof ArrayBuffer) return data;
  return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
}

export function toBufferSource(data: Uint8Array | ArrayBuffer): ArrayBuffer {
  if (data instanceof ArrayBuffer) return data;
  return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) as ArrayBuffer;
}

export function downloadBlob(blobOrBytes: Blob | Uint8Array, fileName: string): void {
  const blob = blobOrBytes instanceof Blob ? blobOrBytes : new Blob([blobOrBytes], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 200);
}

export async function uploadPdfForSharing(
  pdfBlob: Blob | Uint8Array,
  fileName: string
): Promise<{ shareUrl: string; directUrl: string }> {
  const blob = pdfBlob instanceof Blob ? pdfBlob : new Blob([pdfBlob], { type: 'application/pdf' });
  const formData = new FormData();
  formData.append('file', blob, fileName);

  const res = await fetch('/api/documents/share', {
    method: 'POST',
    body: formData,
  });

  if (!res.ok) {
    throw new Error('Error al subir el documento para compartir');
  }

  return res.json();
}

export function buildWhatsAppMessage(opts: SharePdfOptions, shareUrl?: string): string {
  const greeting = `Estimado(a) ${opts.patientName || 'Paciente'}:`;
  const docInfo = `Le adjuntamos su *${opts.docTitle || 'Documento Médico'}* emitido por el *Dr. Samir Moucharrafie Naime* (CCMI).`;
  const linkInfo = shareUrl ? `\n\nPuede ver y descargar su documento oficial aquí:\n${shareUrl}` : '';
  const footer = `\n\n_Instituto de Cirugía de Columna Mínimamente Invasiva (CCMI)_\n_Caracas, Venezuela_`;
  return encodeURIComponent(`${greeting}\n\n${docInfo}${linkInfo}${footer}`);
}

export function sharePdfToWhatsApp(phone: string, text: string): void {
  const cleanPhone = formatWhatsAppPhone(phone);
  const url = `https://wa.me/${cleanPhone}?text=${text}`;
  window.open(url, '_blank');
}
