import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  X,
  Send,
  Mic,
  MicOff,
  Copy,
  Check,
  Maximize2,
  Minimize2,
  Trash2,
  User,
  ShieldCheck,
  Zap,
  ChevronDown,
  Stethoscope,
  Pill,
  FileSpreadsheet,
  BrainCircuit,
  MessageSquare,
  HelpCircle,
  Activity,
  Layers,
  AlertTriangle,
} from 'lucide-react';
import { SamiAvatar } from './SamiAvatar';
import { PatientData } from '../types';
import { useClinicalDictation } from '../hooks/useClinicalDictation';

export interface SamiChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  modelUsed?: string;
  isError?: boolean;
}

interface SamiCopilotProps {
  activePatient?: PatientData | null;
  activeView?: string;
  userRole?: string;
}

const STORAGE_KEY = 'ccmi_sami_chat_history_v1';

export const SamiCopilot: React.FC<SamiCopilotProps> = ({
  activePatient,
  activeView = 'home',
  userRole = 'MEDICO',
}) => {
  const isMounted = useRef<boolean>(true);
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [includePatientContext, setIncludePatientContext] = useState<boolean>(true);
  const [inputQuery, setInputQuery] = useState<string>('');
  const [isThinking, setIsThinking] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [redFlags, setRedFlags] = useState<string[]>([]);

  // Desmontaje seguro para evitar fugas de memoria
  useEffect(() => {
    return () => {
      isMounted.current = false;
    };
  }, []);

  // Hook de dictado clínico por voz en español
  const { isListening, toggleDictation, isSupported: speechSupported } = useClinicalDictation((text) => {
    setInputQuery((prev) => (prev ? `${prev} ${text}` : text));
  });

  // Triage Inteligente: Detección proactiva de banderas rojas clínicas (Diabetes, HTA, Alergias, Cardiopatías)
  useEffect(() => {
    if (!activePatient) {
      setRedFlags([]);
      return;
    }
    const flags: string[] = [];
    const patientAny = activePatient as any;
    const historyText = `${patientAny.history || ''} ${patientAny.antecedents || ''} ${patientAny.antecedentes || ''} ${activePatient.diagnosisPrincipal || ''} ${activePatient.diagnosis || ''}`.toLowerCase();
    const allergiesText = `${patientAny.allergies || ''} ${patientAny.alergias || ''}`.toLowerCase();

    if (historyText.includes('diabet') || historyText.includes('dm2') || historyText.includes('dm1') || historyText.includes('dbt')) {
      flags.push('Diabetes Mellitus (Riesgo metabólico / Cicatrización e Infección quirúrgica)');
    }
    if (
      historyText.includes('hta') ||
      historyText.includes('hipertens') ||
      historyText.includes('hipertension') ||
      historyText.includes('presion alta') ||
      historyText.includes('presión alta')
    ) {
      flags.push('Hipertensión Arterial (HTA) (Riesgo cardiovascular / Control hemodinámico)');
    }
    if (
      allergiesText.trim() &&
      allergiesText.trim() !== 'no' &&
      allergiesText.trim() !== 'ninguna' &&
      allergiesText.trim() !== 'niega' &&
      allergiesText.trim() !== 'no refiere' &&
      allergiesText.trim() !== 'no conocidas'
    ) {
      flags.push(`Alergia confirmada: ${patientAny.allergies || patientAny.alergias}`);
    }
    if (historyText.includes('cardiopat') || historyText.includes('infarto') || historyText.includes('arritmia') || historyText.includes('stent')) {
      flags.push('Cardiopatía / Riesgo cardiovascular mayor');
    }

    setRedFlags(flags);
  }, [activePatient]);

  const [messages, setMessages] = useState<SamiChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // Ignore parse error
    }
    return [
      {
        id: 'welcome-1',
        role: 'model',
        text: `Hola, soy **SAMI** (Synapsis Advanced Medical Intelligence), tu copiloto clínico y guía de operaciones de **CORTEX AXIS** en el CCMI.\n\nPuedes consultarme sobre:\n* 🧠 **Escalas neuroquirúrgicas** (Nurick, mJOA, ASIA, VAS/EVA, Glasgow).\n* 💊 **Esquemas farmacológicos** y posología en patología raquimedular.\n* 📋 **Técnicas quirúrgicas y protocolos** de columna.\n* 📄 **Guía de uso** de los 5 documentos oficiales, secretaría y nube.\n\n¿En qué puedo ayudarte hoy?`,
        timestamp: new Date().toISOString(),
        modelUsed: 'SAMI-Core',
      },
    ];
  });

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Auto-scroll to latest message
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isThinking]);

  // Persist messages in localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
    } catch (e) {
      console.warn('Error saving SAMI history:', e);
    }
  }, [messages]);

  const handleSendMessage = async (queryText?: string) => {
    const textToSend = (queryText || inputQuery).trim();
    if (!textToSend || isThinking) return;

    const userMessage: SamiChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: textToSend,
      timestamp: new Date().toISOString(),
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setInputQuery('');
    setIsThinking(true);

    try {
      const payload: any = {
        messages: newHistory.map((m) => ({
          role: m.role,
          text: m.text,
        })),
        activeView,
        userRole,
      };

      if (includePatientContext && activePatient) {
        payload.patientContext = {
          fullName: activePatient.fullName,
          idNumber: activePatient.idNumber,
          age: activePatient.age,
          diagnosis: activePatient.diagnosis || (activePatient as any).diagnosisPrincipal,
          medications: (activePatient as any).medications,
          allergies: (activePatient as any).allergies,
        };
      }

      const response = await fetch('/api/sami/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`Error en servidor SAMI (${response.status})`);
      }

      const data = await response.json();

      const modelMessage: SamiChatMessage = {
        id: `model-${Date.now()}`,
        role: 'model',
        text: data.reply || 'No obtuve una respuesta clara. ¿Podrías reformular tu consulta médica?',
        timestamp: new Date().toISOString(),
        modelUsed: data.usedModel || data.source || 'Gemini 2.5 Pro',
      };

      if (isMounted.current) {
        setMessages((prev) => [...prev, modelMessage]);
      }
    } catch (err: any) {
      const errorMessage: SamiChatMessage = {
        id: `error-${Date.now()}`,
        role: 'model',
        text: `⚠️ **Aviso de Conexión:** ${err.message || 'No se pudo contactar al motor de Gemini.'}\n\n*Nota:* Puedes seguir consultando escalas y protocolos esenciales en modo local.`,
        timestamp: new Date().toISOString(),
        isError: true,
      };
      if (isMounted.current) {
        setMessages((prev) => [...prev, errorMessage]);
      }
    } finally {
      if (isMounted.current) {
        setIsThinking(false);
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleClearHistory = () => {
    if (confirm('¿Deseas reiniciar la conversación con SAMI?')) {
      const initial: SamiChatMessage[] = [
        {
          id: 'welcome-new',
          role: 'model',
          text: `Conversación reiniciada. Estoy listo para asistirte en tus decisiones clínicas, posología o manejo del sistema CCMI.`,
          timestamp: new Date().toISOString(),
          modelUsed: 'SAMI-Core',
        },
      ];
      setMessages(initial);
      localStorage.removeItem(STORAGE_KEY);
    }
  };

  const quickPrompts = [
    { label: '🧠 Escala Nurick / mJOA', query: 'Explícame las escalas de Nurick y mJOA para mielopatía cervical y sus puntos de corte quirúrgico.' },
    { label: '⚡ Escala ASIA', query: 'Cuáles son los grados de la escala ASIA para lesión medular y cómo clasificar cada nivel?' },
    { label: '📊 Escala VAS / EVA', query: 'Cómo clasificar la escala analógica del dolor EVA/VAS y su esquema analgésico sugerido?' },
    { label: '💊 Posología Columna', query: 'Cuál es la posología recomendada de Pregabalina, Tiocolchicósido y Ketoprofeno en crisis radicular aguda?' },
    { label: '📋 Protocolo Artrodesis Lumbar', query: 'Cuáles son los pasos e indicaciones clínicas para una artrodesis lumbar instrumentada TLIF L4-L5/L5-S1?' },
    { label: '📄 ¿Cómo emitir récipe doble?', query: 'Explícame cómo funciona el récipe oficial duplicado con talón farmacia e indicaciones al paciente en CCMI.' },
  ];

  // Render basic markdown with headers, bold, bullet points
  const renderFormattedMarkdown = (rawText: string) => {
    const lines = rawText.split('\n');
    return lines.map((line, idx) => {
      // Headers
      if (line.startsWith('### ')) {
        return (
          <h4 key={idx} className="text-base font-bold text-cyan-300 mt-2 mb-1 flex items-center gap-1.5">
            <BrainCircuit className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>{line.replace('### ', '')}</span>
          </h4>
        );
      }
      if (line.startsWith('## ')) {
        return (
          <h3 key={idx} className="text-lg font-bold text-cyan-200 mt-3 mb-1.5 border-b border-cyan-800/40 pb-1">
            {line.replace('## ', '')}
          </h3>
        );
      }
      if (line.startsWith('# ')) {
        return (
          <h2 key={idx} className="text-xl font-black text-cyan-100 mt-3 mb-2">
            {line.replace('# ', '')}
          </h2>
        );
      }

      // Bullet points
      if (line.trim().startsWith('* ') || line.trim().startsWith('- ')) {
        const content = line.trim().substring(2);
        return (
          <li key={idx} className="ml-4 list-disc text-slate-200 leading-relaxed text-sm my-0.5">
            {parseInlineFormatting(content)}
          </li>
        );
      }

      // Numbered lists
      const numMatch = line.trim().match(/^(\d+)\.\s+(.*)$/);
      if (numMatch) {
        return (
          <div key={idx} className="flex items-start gap-2 text-slate-200 text-sm my-1 pl-1">
            <span className="text-cyan-400 font-semibold shrink-0">{numMatch[1]}.</span>
            <span>{parseInlineFormatting(numMatch[2])}</span>
          </div>
        );
      }

      // Empty line
      if (!line.trim()) {
        return <div key={idx} className="h-1.5" />;
      }

      // Regular line
      return (
        <p key={idx} className="text-sm text-slate-200 leading-relaxed my-0.5">
          {parseInlineFormatting(line)}
        </p>
      );
    });
  };

  const parseInlineFormatting = (text: string) => {
    // Process **bold** and `code`
    const parts = text.split(/(\*\*.*?\*\*|`.*?`)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className="font-semibold text-cyan-100">
            {part.slice(2, -2)}
          </strong>
        );
      }
      if (part.startsWith('`') && part.endsWith('`')) {
        return (
          <code key={i} className="px-1.5 py-0.5 rounded bg-slate-800/80 text-cyan-300 font-mono text-xs border border-cyan-900/40">
            {part.slice(1, -1)}
          </code>
        );
      }
      return part;
    });
  };

  return (
    <>
      {/* BOTÓN FLOTANTE DISCRETO DE SAMI (Bottom Right) */}
      {!isOpen && (
        <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40">
          <button
            type="button"
            onClick={() => setIsOpen(true)}
            className="group relative flex items-center gap-3 p-2.5 sm:px-4 sm:py-2.5 bg-gradient-to-r from-slate-900/95 via-cyan-950/90 to-slate-900/95 border border-cyan-500/40 hover:border-cyan-400 rounded-full shadow-[0_8px_30px_rgba(6,182,212,0.25)] hover:shadow-[0_12px_40px_rgba(6,182,212,0.4)] transition-all duration-300 transform hover:-translate-y-1 active:scale-95 text-left"
            title="Abrir SAMI Copilot (Asistente Clínico y Guía CCMI)"
          >
            {/* Halo Pulsante de fondo */}
            <div className="absolute -inset-0.5 rounded-full bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 opacity-30 group-hover:opacity-60 blur-sm transition-opacity" />

            <div className="relative flex items-center gap-2.5">
              <SamiAvatar size="sm" isThinking={false} isOnline={true} showHalo={false} />
              
              <div className="hidden sm:flex flex-col pr-1">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-sm text-cyan-100 tracking-wide">SAMI</span>
                  <span className="px-1.5 py-0.2 bg-cyan-500/20 border border-cyan-500/40 rounded text-[10px] font-semibold text-cyan-300 uppercase tracking-wider">
                    Copilot AI
                  </span>
                </div>
                <span className="text-[11px] text-slate-400 font-medium">Asistente Clínico CCMI</span>
              </div>

              {/* Indicador de destello */}
              <div className="relative flex h-2.5 w-2.5 sm:hidden">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500"></span>
              </div>
            </div>
          </button>
        </div>
      )}

      {/* PANEL DESLIZANTE / DRAWER LATERAL DE SAMI */}
      {isOpen && (
        <div
          className={`fixed z-50 transition-all duration-300 ease-out flex flex-col bg-slate-950/95 backdrop-blur-xl border-cyan-500/30 shadow-[0_0_50px_rgba(0,0,0,0.8)] ${
            isExpanded
              ? 'inset-2 sm:inset-6 rounded-2xl border'
              : 'bottom-0 right-0 w-full sm:w-[460px] md:w-[500px] h-[92vh] sm:h-[680px] sm:max-h-[90vh] sm:bottom-4 sm:right-4 rounded-t-2xl sm:rounded-2xl border-t sm:border'
          }`}
        >
          {/* HEADER DEL COPILOT */}
          <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-slate-900 via-cyan-950/70 to-slate-900 border-b border-cyan-500/20 rounded-t-2xl shrink-0">
            <div className="flex items-center gap-3">
              <SamiAvatar size="md" isThinking={isThinking} isOnline={true} />
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-base text-cyan-100 tracking-wide">SAMI Copilot</h3>
                  <span className="px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 text-[10px] font-semibold uppercase tracking-wider border border-cyan-500/30 flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5 text-cyan-400 animate-pulse" />
                    Gemini AI
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 flex items-center gap-1">
                  <span>Synapsis Medical Intelligence</span>
                  <span className="text-cyan-500">•</span>
                  <span className="text-emerald-400 font-medium">Clínica CCMI</span>
                </p>
              </div>
            </div>

            {/* Acciones del Header */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleClearHistory}
                className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-lg transition-colors"
                title="Reiniciar conversación"
              >
                <Trash2 className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => setIsExpanded(!isExpanded)}
                className="hidden sm:inline-flex p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-lg transition-colors"
                title={isExpanded ? 'Restaurar tamaño normal' : 'Expandir ventana'}
              >
                {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>

              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                title="Cerrar panel"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* BANNER DE ALERTA ROJO: TRIAGE INTELIGENTE & RED FLAGS */}
          {redFlags.length > 0 && (
            <div className="px-3.5 py-2.5 bg-gradient-to-r from-red-950/95 via-red-900/90 to-red-950/95 border-b border-red-500/50 flex items-start gap-2.5 text-xs text-red-100 shrink-0 shadow-md animate-fade-in">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5 animate-pulse" />
              <div className="flex-1 min-w-0">
                <div className="font-extrabold text-red-200 flex items-center justify-between">
                  <span className="tracking-wide">TRIAGE INTELIGENTE • RED FLAGS CLÍNICAS ({redFlags.length})</span>
                  <span className="text-[10px] bg-red-500/30 text-red-200 px-1.5 py-0.5 rounded border border-red-500/40 uppercase font-mono font-bold">
                    Alerta Clínica
                  </span>
                </div>
                <ul className="mt-1 space-y-0.5 list-disc list-inside text-[11px] text-red-100 font-medium">
                  {redFlags.map((flag, idx) => (
                    <li key={idx} className="truncate">{flag}</li>
                  ))}
                </ul>
                <p className="text-[10px] text-red-300/80 mt-1 italic">
                  Aviso de seguridad para el médico tratante: verifique ajuste metabólico y estabilidad hemodinámica.
                </p>
              </div>
            </div>
          )}

          {/* BANNER DE CONTEXTO DEL PACIENTE ACTIVO */}
          {activePatient && activePatient.fullName && (
            <div className="px-3.5 py-2 bg-slate-900/90 border-b border-cyan-500/15 flex items-center justify-between text-xs shrink-0">
              <div className="flex items-center gap-2 truncate">
                <User className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span className="text-slate-400 shrink-0">Paciente en foco:</span>
                <span className="font-semibold text-cyan-200 truncate">{activePatient.fullName}</span>
                {activePatient.idNumber && (
                  <span className="text-slate-400 font-mono text-[11px] truncate">({activePatient.idNumber})</span>
                )}
              </div>
              <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px] text-slate-300 shrink-0 ml-2">
                <input
                  type="checkbox"
                  checked={includePatientContext}
                  onChange={(e) => setIncludePatientContext(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0 focus:ring-offset-0 w-3.5 h-3.5"
                />
                <span className={includePatientContext ? 'text-cyan-300 font-medium' : 'text-slate-500'}>
                  {includePatientContext ? 'Contexto Activo' : 'Sin Contexto'}
                </span>
              </label>
            </div>
          )}

          {/* ATAJOS RÁPIDOS CLÍNICOS HORIZONTALES */}
          <div className="px-3 py-2 bg-slate-950/60 border-b border-slate-800/80 overflow-x-auto no-scrollbar flex items-center gap-1.5 shrink-0">
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendMessage(qp.query)}
                disabled={isThinking}
                className="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-900/90 hover:bg-cyan-950/80 text-cyan-200 hover:text-cyan-100 border border-cyan-900/50 hover:border-cyan-500/50 whitespace-nowrap transition-all active:scale-95 disabled:opacity-50 shrink-0 flex items-center gap-1"
              >
                {qp.label}
              </button>
            ))}
          </div>

          {/* ÁREA DE MENSAJES CON SCROLL */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 text-sm">
            {messages.map((msg) => {
              const isUser = msg.role === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 items-start ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  {/* Avatar */}
                  {isUser ? (
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center shrink-0 shadow-md text-white font-bold text-xs border border-cyan-400/40">
                      Dr
                    </div>
                  ) : (
                    <SamiAvatar size="sm" isThinking={false} isOnline={true} showHalo={false} />
                  )}

                  {/* Burbuja de Mensaje */}
                  <div
                    className={`max-w-[85%] rounded-2xl p-3.5 shadow-md ${
                      isUser
                        ? 'bg-gradient-to-br from-blue-600/90 to-cyan-600/90 text-white rounded-tr-none border border-cyan-400/30'
                        : msg.isError
                        ? 'bg-red-950/40 border border-red-500/40 text-red-200 rounded-tl-none'
                        : 'bg-slate-900/90 border border-cyan-500/20 text-slate-100 rounded-tl-none shadow-[0_4px_20px_rgba(0,0,0,0.3)]'
                    }`}
                  >
                    {isUser ? (
                      <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                    ) : (
                      <div className="space-y-1">{renderFormattedMarkdown(msg.text)}</div>
                    )}

                    {/* Barra de utilidades del mensaje (Copiar, Modelo, Hora) */}
                    <div
                      className={`flex items-center justify-between mt-2 pt-1.5 border-t text-[10px] ${
                        isUser ? 'border-cyan-400/20 text-cyan-100/70' : 'border-slate-800 text-slate-400'
                      }`}
                    >
                      <span className="flex items-center gap-1 font-mono">
                        {msg.modelUsed && <span className="text-cyan-400">{msg.modelUsed}</span>}
                        {msg.modelUsed && <span>•</span>}
                        <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </span>

                      {!isUser && (
                        <button
                          type="button"
                          onClick={() => handleCopyText(msg.text, msg.id)}
                          className="flex items-center gap-1 hover:text-cyan-300 transition-colors px-1.5 py-0.5 rounded hover:bg-slate-800/80"
                          title="Copiar respuesta al portapapeles"
                        >
                          {copiedId === msg.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span className="text-emerald-400 font-semibold">Copiado</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copiar</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Animación de Pensamiento (Thinking Indicator) */}
            {isThinking && (
              <div className="flex gap-3 items-start">
                <SamiAvatar size="sm" isThinking={true} isOnline={true} showHalo={false} />
                <div className="bg-slate-900/90 border border-cyan-500/30 rounded-2xl rounded-tl-none p-3.5 shadow-lg flex items-center gap-2 text-cyan-300 text-xs">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                  <span className="font-medium text-slate-300">SAMI analizando conocimiento neuroquirúrgico...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* INPUT BARRA DE CONSULTA CON DICTADO */}
          <div className="p-3 bg-slate-900/95 border-t border-cyan-500/20 rounded-b-2xl shrink-0">
            <div className="relative flex items-end gap-2 bg-slate-950/90 border border-cyan-500/30 focus-within:border-cyan-400 rounded-xl p-2 transition-all shadow-inner">
              <textarea
                ref={textareaRef}
                value={inputQuery}
                onChange={(e) => setInputQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Pregúntale a SAMI (ej: posología pregabalina, escala Nurick, técnica TLIF)..."
                rows={1}
                className="flex-1 bg-transparent text-sm text-slate-100 placeholder-slate-500 focus:outline-none resize-none max-h-28 py-1.5 px-1 leading-relaxed"
                style={{ minHeight: '36px' }}
              />

              {/* Botón de Dictado por Voz */}
              {speechSupported && (
                <button
                  type="button"
                  onClick={toggleDictation}
                  className={`p-2 rounded-lg transition-all ${
                    isListening
                      ? 'bg-red-500 text-white animate-pulse shadow-[0_0_12px_#ef4444]'
                      : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-800'
                  }`}
                  title={isListening ? 'Detener dictado por voz' : 'Dictar consulta médica'}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>
              )}

              {/* Botón de Enviar */}
              <button
                type="button"
                onClick={() => handleSendMessage()}
                disabled={!inputQuery.trim() || isThinking}
                className="p-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-lg transition-all shadow-md active:scale-95 shrink-0"
                title="Enviar mensaje a SAMI (Enter)"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

            {/* Disclaimer Médico de Seguridad */}
            <p className="text-[10px] text-slate-400 text-center mt-1.5 flex items-center justify-center gap-1">
              <ShieldCheck className="w-3 h-3 text-cyan-400 inline" />
              <span>SAMI es un copiloto clínico asistencial orientativo para el médico tratante del CCMI.</span>
            </p>
          </div>
        </div>
      )}
    </>
  );
};
