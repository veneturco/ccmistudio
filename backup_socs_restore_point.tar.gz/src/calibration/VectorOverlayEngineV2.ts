/**
 * VectorOverlayEngineV2.ts
 * 
 * MOTOR UNIVERSAL DE RENDERIZADO VECTORIAL OVERLAY (ARQUITECTURA V2)
 * ===================================================================
 * REGLAS FUNDAMENTALES:
 * 1. PDF MAESTRO INMUTABLE: Se utiliza como background original no rasterizado.
 * 2. OVERLAY VECTORIAL PURO: El texto, marcas y firmas se inyectan como streams vectoriales nativos.
 * 3. NO INVENCIÓN DE DATOS: Si un dato no existe, no se inyecta nada ni se inventa contenido.
 * 4. PROTECCIÓN DE REGIONES BLOQUEADAS: Detecta colisiones geométricas con membretes o sellos.
 * 5. AUTOAJUSTE TIPOGRÁFICO: Aplica Shrink-to-fit o advertencia de revisión sin truncamiento destructivo.
 */

import { PDFDocument, PDFPage, PDFFont, rgb } from 'pdf-lib';
import {
  MasterTemplateV2,
  PageTemplate,
  OverlayElement,
  TextElement,
  MultilineTextElement,
  CheckboxElement,
  StampElement,
  SignatureElement,
  ImageElement,
  LineElement,
  LockedRegion,
  ElementGeometry,
} from './types/MasterTemplateV2';
import { CalibrationEngine } from './CalibrationEngine';
import { DataResolver } from './DataResolver';

export interface OverlayRenderOptions {
  doctorStampBase64?: string;
  signatureBase64?: string;
  debugOverlay?: boolean;
  debugMode?: boolean;
}

export interface OverlayRenderResult {
  pdfBytes: Uint8Array;
  requiresReview: boolean;
  warnings: string[];
  injectedElementsCount: number;
}

export class VectorOverlayEngineV2 {
  /**
   * Resuelve el valor semántico a partir de una clave con notación de puntos
   * Ej: 'patient.fullName' -> data.patient?.fullName
   */
  public static resolveDataKey(data: Record<string, any>, key: string): any {
    if (!data || !key) return undefined;
    return DataResolver.resolve(data, key);
  }

  /**
   * Comprueba si una geometría colisiona con alguna región bloqueada
   */
  public static checkCollision(
    geom: ElementGeometry,
    lockedRegions: LockedRegion[] = []
  ): { collides: boolean; regionId?: string } {
    for (const region of lockedRegions) {
      const xOverlap = Math.max(0, Math.min(geom.xMm + geom.widthMm, region.xMm + region.widthMm) - Math.max(geom.xMm, region.xMm));
      const yOverlap = Math.max(0, Math.min(geom.yMm + geom.heightMm, region.yMm + region.heightMm) - Math.max(geom.yMm, region.yMm));
      if (xOverlap > 0.5 && yOverlap > 0.5) {
        return { collides: true, regionId: region.id };
      }
    }
    return { collides: false };
  }

  /**
   * Aplica un MasterTemplateV2 con datos semánticos sobre un PDF o imagen original
   */
  public static async applyOverlay(
    originalPdfBytes: Uint8Array,
    template: MasterTemplateV2,
    patientData: Record<string, any>,
    options: OverlayRenderOptions = {}
  ): Promise<OverlayRenderResult> {
    let pdfDoc: PDFDocument;

    // Detección de formato del buffer maestro
    const isPdf =
      originalPdfBytes &&
      originalPdfBytes.length > 4 &&
      originalPdfBytes[0] === 0x25 &&
      originalPdfBytes[1] === 0x50 &&
      originalPdfBytes[2] === 0x44 &&
      originalPdfBytes[3] === 0x46;

    const isJpg =
      originalPdfBytes &&
      originalPdfBytes.length > 3 &&
      originalPdfBytes[0] === 0xff &&
      originalPdfBytes[1] === 0xd8 &&
      originalPdfBytes[2] === 0xff;

    const isPng =
      originalPdfBytes &&
      originalPdfBytes.length > 4 &&
      originalPdfBytes[0] === 0x89 &&
      originalPdfBytes[1] === 0x50 &&
      originalPdfBytes[2] === 0x4e &&
      originalPdfBytes[3] === 0x47;

    if (isPdf) {
      pdfDoc = await PDFDocument.load(originalPdfBytes, { ignoreEncryption: true });
    } else if (isJpg || isPng) {
      // Si el buffer es una imagen de alta resolución, se genera un PDF contenedor con fondo incrustado
      pdfDoc = await PDFDocument.create();
      const defaultWidthMm = template?.pages?.[0]?.widthMm || 210.0;
      const defaultHeightMm = template?.pages?.[0]?.heightMm || 297.0;
      const widthPt = (defaultWidthMm * 72) / 25.4;
      const heightPt = (defaultHeightMm * 72) / 25.4;

      const page = pdfDoc.addPage([widthPt, heightPt]);
      try {
        const bgImg = isPng
          ? await pdfDoc.embedPng(originalPdfBytes)
          : await pdfDoc.embedJpg(originalPdfBytes);
        page.drawImage(bgImg, {
          x: 0,
          y: 0,
          width: widthPt,
          height: heightPt,
        });
      } catch (imgErr) {
        console.warn('[VectorOverlayEngineV2] Advertencia al incrustar fondo de imagen:', imgErr);
      }
    } else {
      // Fallback: Si no es reconocible como PDF ni imagen, crear un documento en blanco con las dimensiones maestras
      pdfDoc = await PDFDocument.create();
      for (const pageTpl of (template?.pages || [])) {
        const wMm = pageTpl.widthMm || 210.0;
        const hMm = pageTpl.heightMm || 297.0;
        pdfDoc.addPage([(wMm * 72) / 25.4, (hMm * 72) / 25.4]);
      }
    }

    const fontRegular = await pdfDoc.embedFont('Helvetica');
    const fontBold = await pdfDoc.embedFont('Helvetica-Bold');

    const warnings: string[] = [];
    let requiresReview = false;
    let injectedElementsCount = 0;

    // Embeber sello/firma si está disponible en opciones
    let embeddedStampImage: any = null;
    if (options.doctorStampBase64) {
      try {
        const cleanBase64 = options.doctorStampBase64.replace(/^data:image\/\w+;base64,/, '');
        const imageBytes = Uint8Array.from(atob(cleanBase64), (c) => c.charCodeAt(0));
        embeddedStampImage = options.doctorStampBase64.includes('image/png')
          ? await pdfDoc.embedPng(imageBytes)
          : await pdfDoc.embedJpg(imageBytes);
      } catch (err: any) {
        warnings.push(`No se pudo embeber el sello del médico: ${err.message}`);
      }
    }

    // Asegurar que existan suficientes páginas en el documento
    const tplPages = template?.pages || [];
    while (pdfDoc.getPageCount() < tplPages.length) {
      const pIdx = pdfDoc.getPageCount();
      const pageTpl = tplPages[pIdx];
      const wMm = pageTpl?.widthMm || 210.0;
      const hMm = pageTpl?.heightMm || 297.0;
      pdfDoc.addPage([(wMm * 72) / 25.4, (hMm * 72) / 25.4]);
    }

    const pages = pdfDoc.getPages();

    for (const pageTemplate of tplPages) {
      if (pageTemplate.pageIndex >= pages.length) {
        warnings.push(`Página ${pageTemplate.pageIndex + 1} no existe en el PDF base (total páginas: ${pages.length}).`);
        continue;
      }

      const page = pages[pageTemplate.pageIndex];
      const actualPageWidthPt = page.getWidth();
      const actualPageHeightPt = page.getHeight();
      const actualPageWidthMm = (actualPageWidthPt * 25.4) / 72;
      const actualPageHeightMm = (actualPageHeightPt * 25.4) / 72;

      // Validación estricta de dimensiones físicas reales vs MasterTemplateV2
      const templatePageWidthMm = pageTemplate.widthMm ?? (pageTemplate as any).pageSize?.widthMm ?? actualPageWidthMm;
      const templatePageHeightMm = pageTemplate.heightMm ?? (pageTemplate as any).pageSize?.heightMm ?? actualPageHeightMm;

      const widthDiffMm = Math.abs(templatePageWidthMm - actualPageWidthMm);
      const heightDiffMm = Math.abs(templatePageHeightMm - actualPageHeightMm);
      const DIMENSION_TOLERANCE_MM = 3.0;

      if (widthDiffMm > DIMENSION_TOLERANCE_MM || heightDiffMm > DIMENSION_TOLERANCE_MM) {
        const errorMsg = `[VectorOverlayEngineV2] ADVERTENCIA DE DIMENSIÓN DEL MASTER: La página ${pageTemplate.pageIndex + 1} del PDF base mide ${actualPageWidthMm.toFixed(1)} × ${actualPageHeightMm.toFixed(1)} mm (${actualPageWidthPt.toFixed(1)} × ${actualPageHeightPt.toFixed(1)} pt), mientras que el MasterTemplateV2 '${template.masterId}' declara ${templatePageWidthMm.toFixed(1)} × ${templatePageHeightMm.toFixed(1)} mm.`;
        console.warn(errorMsg);
        warnings.push(errorMsg);
        requiresReview = true;
      }

      // La altura física real de la página para la transformación top-down a bottom-up
      const pageHeightMm = actualPageHeightMm;
      const combinedLockedRegions = [
        ...(template.lockedRegions || []),
        ...(pageTemplate.lockedRegions || []),
      ];

      // Factor de escala dinámico en caso de que el PDF cargado difiera del diseño de referencia (ej. Carta vs A4)
      const scaleX = templatePageWidthMm > 0 && Math.abs(templatePageWidthMm - actualPageWidthMm) > 1.5
        ? actualPageWidthMm / templatePageWidthMm
        : 1.0;
      const scaleY = templatePageHeightMm > 0 && Math.abs(templatePageHeightMm - actualPageHeightMm) > 1.5
        ? actualPageHeightMm / templatePageHeightMm
        : 1.0;

      for (const element of pageTemplate.elements) {
        const rawGeom = element.geometry || {
          xMm: (element as any).xMm ?? 20,
          yMm: (element as any).yMm ?? 20,
          widthMm: (element as any).widthMm ?? 40,
          heightMm: (element as any).heightMm ?? 6,
        };

        const geom: ElementGeometry = {
          xMm: Number((rawGeom.xMm * scaleX).toFixed(2)),
          yMm: Number((rawGeom.yMm * scaleY).toFixed(2)),
          widthMm: Number((rawGeom.widthMm * scaleX).toFixed(2)),
          heightMm: Number((rawGeom.heightMm * scaleY).toFixed(2)),
        };

        switch (element.type) {
          case 'text': {
            const rawVal = VectorOverlayEngineV2.resolveDataKey(patientData, element.dataKey);
            if (rawVal === undefined || rawVal === null || String(rawVal).trim() === '') {
              break;
            }
            const textToDraw = element.labelPrefix ? `${element.labelPrefix}${String(rawVal).trim()}` : String(rawVal).trim();
            const font = (element.typography?.fontWeight ?? (element as any).fontWeight) === 'bold' ? fontBold : fontRegular;
            let fontSize = element.typography?.fontSizePt ?? (element as any).fontSizePt ?? 9.5;

            // Medición tipográfica exacta y autoajuste (shrink) sin partir en múltiples líneas
            const maxAllowedWidthPt = CalibrationEngine.xMmToPdfPt(geom.widthMm);
            let textWidth = font.widthOfTextAtSize(textToDraw, fontSize);
            if (textWidth > maxAllowedWidthPt) {
              if (element.overflow === 'shrink') {
                const shrinkFactor = maxAllowedWidthPt / textWidth;
                fontSize = Math.max(fontSize * shrinkFactor, 6.0);
                textWidth = font.widthOfTextAtSize(textToDraw, fontSize);
              }
            }

            const alignedX = CalibrationEngine.calculateAlignedXPt(
              geom.xMm,
              geom.widthMm,
              element.typography?.align ?? (element as any).align ?? 'left',
              textWidth
            );
            const baselineY = CalibrationEngine.calculateBaselineYPt(
              geom.yMm,
              fontSize,
              pageHeightMm,
              font.heightAtSize(fontSize),
              geom.heightMm
            );

            // Importante: No pasar maxWidth en 'text' de una sola línea para evitar saltos de línea no deseados en pdf-lib
            page.drawText(textToDraw, {
              x: alignedX,
              y: baselineY,
              size: fontSize,
              font,
              color: rgb(0.08, 0.12, 0.2),
            });
            injectedElementsCount++;
            break;
          }

          case 'multilineText': {
            const rawVal = VectorOverlayEngineV2.resolveDataKey(patientData, element.dataKey);
            if (!rawVal || String(rawVal).trim() === '') break;

            const textToDraw = String(rawVal).trim();
            const font = (element.typography?.fontWeight ?? (element as any).fontWeight) === 'bold' ? fontBold : fontRegular;
            const baseFontSize = element.typography?.fontSizePt ?? (element as any).fontSizePt ?? 9.5;

            const shrinkResult = CalibrationEngine.calculateShrinkFontSize(
              textToDraw,
              geom.heightMm,
              baseFontSize,
              7.5,
              geom.widthMm
            );

            if (shrinkResult.requiresReview) {
              requiresReview = true;
              warnings.push(`El texto en '${element.id}' excede el espacio visual asignado y requiere revisión.`);
            }

            const activeFontSize = shrinkResult.fontSizePt;
            const lineHeightPt = element.typography?.lineHeightPt ?? ((element as any).lineHeightPt || (activeFontSize * 1.35));

            // Renderizar párrafos y líneas
            const lines = VectorOverlayEngineV2.wrapText(textToDraw, font, activeFontSize, CalibrationEngine.xMmToPdfPt(geom.widthMm));
            let currentYMm = geom.yMm;

            for (let i = 0; i < Math.min(lines.length, element.maxLines || 40); i++) {
              const line = lines[i];
              const textWidth = font.widthOfTextAtSize(line, activeFontSize);
              const alignedX = CalibrationEngine.calculateAlignedXPt(
                geom.xMm,
                geom.widthMm,
                element.typography?.align ?? (element as any).align ?? 'left',
                textWidth
              );
              const baselineY = CalibrationEngine.calculateBaselineYPt(
                currentYMm,
                activeFontSize,
                pageHeightMm,
                font.heightAtSize(activeFontSize)
              );

              page.drawText(line, {
                x: alignedX,
                y: baselineY,
                size: activeFontSize,
                font,
                maxWidth: CalibrationEngine.xMmToPdfPt(geom.widthMm),
                color: rgb(0.1, 0.15, 0.25),
              });
              currentYMm += CalibrationEngine.ptToMm(lineHeightPt);
            }
            injectedElementsCount++;
            break;
          }

          case 'checkbox': {
            const rawVal = VectorOverlayEngineV2.resolveDataKey(patientData, element.dataKey);
            const isChecked = Boolean(rawVal);
            const isDebug = Boolean(options.debugMode || options.debugOverlay);
            if (!isChecked && !isDebug) break;

            const markChar = element.markStyle === 'CHECK' ? '✓' : 'X';
            const fontSize = element.fontSizePt ?? (element as any).fontSizePt ?? 8;
            const markWidth = fontBold.widthOfTextAtSize(markChar, fontSize);
            const boxWidthPt = CalibrationEngine.mmToPt(geom.widthMm);
            const boxHeightPt = CalibrationEngine.mmToPt(geom.heightMm);
            const originXPt = CalibrationEngine.xMmToPdfPt(geom.xMm);
            const originYPt = CalibrationEngine.yMmToPdfPt(geom.yMm, pageHeightMm);

            // Centrado geométrico exacto usando métricas reales de la fuente
            const alignedX = originXPt + (boxWidthPt - markWidth) / 2;
            const capHeight = fontSize * 0.718;
            const baselineY = originYPt - (boxHeightPt + capHeight) / 2;

            if (isChecked) {
              page.drawText(markChar, {
                x: alignedX,
                y: baselineY,
                size: fontSize,
                font: fontBold,
                color: isDebug ? rgb(0.85, 0.1, 0.1) : rgb(0.04, 0.22, 0.43),
              });
              injectedElementsCount++;
            }

            if (isDebug) {
              // Caja de diagnóstico de alta visibilidad para comprobación de superposición
              page.drawRectangle({
                x: originXPt,
                y: originYPt - boxHeightPt,
                width: boxWidthPt,
                height: boxHeightPt,
                borderColor: rgb(0.1, 0.7, 0.2),
                borderWidth: 0.5,
              });
            }
            break;
          }

          case 'stamp':
          case 'signature': {
            if (embeddedStampImage) {
              const xPt = CalibrationEngine.xMmToPdfPt(geom.xMm);
              const yPt = CalibrationEngine.yMmToPdfPt(geom.yMm + geom.heightMm, pageHeightMm);
              const widthPt = CalibrationEngine.xMmToPdfPt(geom.widthMm);
              const heightPt = CalibrationEngine.xMmToPdfPt(geom.heightMm);

              page.drawImage(embeddedStampImage, {
                x: xPt,
                y: yPt,
                width: widthPt,
                height: heightPt,
                opacity: element.opacity !== undefined ? element.opacity : 0.92,
              });
              injectedElementsCount++;
            }
            break;
          }

          case 'line': {
            const startX = CalibrationEngine.xMmToPdfPt(geom.xMm);
            const endX = CalibrationEngine.xMmToPdfPt(geom.xMm + geom.widthMm);
            const yPt = CalibrationEngine.yMmToPdfPt(geom.yMm, pageHeightMm);

            page.drawLine({
              start: { x: startX, y: yPt },
              end: { x: endX, y: yPt },
              thickness: element.thicknessPt || 1,
              color: rgb(0.3, 0.35, 0.4),
            });
            injectedElementsCount++;
            break;
          }
        }
      }
    }

    const pdfBytes = await pdfDoc.save();
    return {
      pdfBytes,
      requiresReview,
      warnings,
      injectedElementsCount,
    };
  }

  /**
   * Divide un texto en líneas respetando el ancho máximo en puntos
   */
  public static wrapText(text: string, font: PDFFont, fontSize: number, maxWidthPt: number): string[] {
    const paragraphs = text.split('\n');
    const resultLines: string[] = [];

    for (const paragraph of paragraphs) {
      if (paragraph.trim() === '') {
        resultLines.push('');
        continue;
      }
      const words = paragraph.split(' ');
      let currentLine = '';

      for (const word of words) {
        const testLine = currentLine === '' ? word : `${currentLine} ${word}`;
        const testWidth = font.widthOfTextAtSize(testLine, fontSize);

        if (testWidth <= maxWidthPt) {
          currentLine = testLine;
        } else {
          if (currentLine !== '') {
            resultLines.push(currentLine);
          }
          currentLine = word;
        }
      }
      if (currentLine !== '') {
        resultLines.push(currentLine);
      }
    }

    return resultLines;
  }
}
