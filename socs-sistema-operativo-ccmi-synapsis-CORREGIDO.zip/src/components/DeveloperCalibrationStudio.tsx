import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Save, 
  RotateCcw, 
  X, 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight,
  Type,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Bold,
  Check,
  Sliders,
  Code2,
  Copy,
  Layers,
  HelpCircle,
  AlertTriangle,
  CheckCircle2,
  Maximize2,
  Minimize2,
  Eye,
  FileSpreadsheet,
  UploadCloud,
  Download,
  Upload,
  ShieldCheck
} from 'lucide-react';
import { DocType } from '../types';
import { DocumentCalibration, FieldCalibration } from '../types/calibration';
import { DOCUMENT_DEFINITIONS } from '../utils/pdfExport';
import { exportCalibrationsToJsonFile, importCalibrationsFromJson } from '../utils/calibrationStorage';
import { runPdfFidelitySuite, FullFidelityReport } from '../utils/pdfFidelityTest';
import { runMasterTemplateV2Audit, V2ArchitectureAuditReport } from '../utils/masterTemplateV2Test';
import { TestCalibrationRunner } from '../calibration/TestCalibrationRunner';
import { downloadBlob } from '../utils/pdfExport';
import { 
  autoCalibrateWithAI, 
  scanAndCalibrateWithGeminiVision,
  pxToMm, 
  mmToPx, 
  AIPresetProfile, 
  diagnoseLayout, 
  LayoutDiagnostic,
  generateTypeScriptCode 
} from '../utils/aiLayoutEngine';

interface Props {
  activeDoc: DocType;
  onChangeDoc: (doc: DocType) => void;
  calibration: DocumentCalibration;
  selectedFieldId: string | null;
  onSelectField: (id: string | null) => void;
  onUpdateField: (updated: FieldCalibration) => void;
  onApplyWholeCalibration: (newCalib: DocumentCalibration) => void;
  onSaveAsFactoryDefault: () => void;
  onResetDefaults: () => void;
  onClose: () => void;
  hasUnsavedChanges: boolean;
  testMode: 'real' | 'stress';
  onToggleTestMode: (mode: 'real' | 'stress') => void;
  activeBgUrl?: string;
  onOpenUploader?: () => void;
}

export const DeveloperCalibrationStudio: React.FC<Props> = ({
  activeDoc,
  onChangeDoc,
  calibration,
  selectedFieldId,
  onSelectField,
  onUpdateField,
  onApplyWholeCalibration,
  onSaveAsFactoryDefault,
  onResetDefaults,
  onClose,
  hasUnsavedChanges,
  testMode,
  onToggleTestMode,
  activeBgUrl,
  onOpenUploader,
}) => {
  const [unit, setUnit] = useState<'mm' | 'px'>('mm');
  const [aiProfile, setAiProfile] = useState<AIPresetProfile>('printed_lines');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [aiStatusMsg, setAiStatusMsg] = useState<string | null>(null);
  const [isVisionScanning, setIsVisionScanning] = useState<boolean>(false);
  const [showCodeModal, setShowCodeModal] = useState<boolean>(false);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [backupToast, setBackupToast] = useState<string | null>(null);
  const [fidelityReport, setFidelityReport] = useState<FullFidelityReport | null>(null);
  const [isRunningFidelity, setIsRunningFidelity] = useState<boolean>(false);
  const [showFidelityModal, setShowFidelityModal] = useState<boolean>(false);
  const [v2Report, setV2Report] = useState<V2ArchitectureAuditReport | null>(null);
  const [isRunningV2Audit, setIsRunningV2Audit] = useState<boolean>(false);
  const [showV2Modal, setShowV2Modal] = useState<boolean>(false);
  const [isGeneratingTestPdf, setIsGeneratingTestPdf] = useState<boolean>(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleGenerateTestCalibrationPdf = async () => {
    setIsGeneratingTestPdf(true);
    try {
      // Mapear activeDoc a su archivo base
      const pdfMap: Record<string, string> = {
        RECIPES: '/templates/recipe_base.pdf',
        REPORTS: '/templates/informe_base.pdf',
        CERTIFICATES: '/templates/constancia_base.pdf',
        HISTORY: '/templates/historia_base.pdf',
        LAB_ORDER: '/templates/orden_lab_base.pdf',
      };
      const docTypeMap: Record<string, string> = {
        RECIPES: 'RECIPE-001',
        REPORTS: 'INFORME-001',
        CERTIFICATES: 'CONSTANCIA-001',
        HISTORY: 'HISTORIA-001',
        LAB_ORDER: 'LAB-001',
      };
      const pdfPath = pdfMap[activeDoc] || '/templates/recipe_base.pdf';
      const masterId = docTypeMap[activeDoc] || 'RECIPE-001';

      const resp = await fetch(pdfPath);
      if (!resp.ok) throw new Error(`No se pudo cargar el PDF maestro base desde ${pdfPath}`);
      const pdfBytes = new Uint8Array(await resp.arrayBuffer());

      const result = await TestCalibrationRunner.generateTestPdf(masterId, pdfBytes, {
        debugMode: true,
      });

      downloadBlob(result.pdfBytes, `CALIBRACION_TEST_V2_${masterId}.pdf`);
      setBackupToast(`🎯 PDF de prueba de calibración generado con cajas de depuración para ${masterId}`);
      setTimeout(() => setBackupToast(null), 5000);
    } catch (err: any) {
      alert(`Error generando PDF de calibración: ${err?.message || err}`);
    } finally {
      setIsGeneratingTestPdf(false);
    }
  };

  const handleRunV2Audit = async () => {
    setIsRunningV2Audit(true);
    try {
      const report = await runMasterTemplateV2Audit();
      setV2Report(report);
      setShowV2Modal(true);
    } catch (err: any) {
      alert(`Error ejecutando auditoría V2: ${err?.message || err}`);
    } finally {
      setIsRunningV2Audit(false);
    }
  };

  const handleRunFidelityAudit = async () => {
    setIsRunningFidelity(true);
    try {
      const report = await runPdfFidelitySuite();
      setFidelityReport(report);
      setShowFidelityModal(true);
    } catch (err: any) {
      alert(`Error ejecutando auditoría de fidelidad: ${err?.message || err}`);
    } finally {
      setIsRunningFidelity(false);
    }
  };

  const handleExportBackup = () => {
    exportCalibrationsToJsonFile();
    setBackupToast('💾 ¡Copia de seguridad (.json) descargada a su equipo con éxito!');
    setTimeout(() => setBackupToast(null), 4000);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const all = importCalibrationsFromJson(text);
        if (all[activeDoc]) {
          onApplyWholeCalibration(all[activeDoc]);
        }
        setBackupToast('✨ ¡Calibraciones importadas y aplicadas a todas las plantillas!');
        setTimeout(() => setBackupToast(null), 4000);
      } catch (err) {
        alert('Error al leer el archivo de calibraciones. Verifique que sea un archivo JSON exportado previamente.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const fields: FieldCalibration[] = Object.values(calibration);
  const selectedField: FieldCalibration | null = selectedFieldId ? calibration[selectedFieldId] || null : null;

  // Real-time layout diagnostics
  const diagnostics: LayoutDiagnostic[] = diagnoseLayout(calibration);
  const hasErrors = diagnostics.some((d) => d.severity === 'error');

  // Keyboard navigation for precision nudging (Arrow keys)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) {
        if (!e.altKey && !e.ctrlKey && !e.metaKey) return;
      }

      if (!selectedField) return;

      const step = e.shiftKey ? 10 : (e.altKey ? 5 : 1);

      if (e.key === 'ArrowUp') {
        e.preventDefault();
        onUpdateField({ ...selectedField, top: Math.max(0, selectedField.top - step) });
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        onUpdateField({ ...selectedField, top: Math.min(1123 - selectedField.height, selectedField.top + step) });
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        onUpdateField({ ...selectedField, left: Math.max(0, selectedField.left - step) });
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        onUpdateField({ ...selectedField, left: Math.min(794 - selectedField.width, selectedField.left + step) });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedField, onUpdateField]);

  // Ejecución de la Auto-Calibración Inteligente con IA
  const handleAutoCalibrate = (profileToUse: AIPresetProfile = aiProfile) => {
    const aiCalib = autoCalibrateWithAI(activeDoc, profileToUse);
    onApplyWholeCalibration(aiCalib);
    setAiStatusMsg(`✨ ¡Auto-calibrado con IA! Perfil aplicado: ${getProfileName(profileToUse)}.`);
    setTimeout(() => setAiStatusMsg(null), 5000);
  };

  // Escaneo visual con Gemini Vision sobre el fondo real
  const handleVisionScan = async () => {
    setIsVisionScanning(true);
    setAiStatusMsg('👁️ Analizando papelería original con Gemini Vision: detectando "Nombre", "Cédula", "Fecha", renglones preimpresos...');
    try {
      const result = await scanAndCalibrateWithGeminiVision(activeDoc, activeBgUrl);
      if (result.success && result.calibration) {
        onApplyWholeCalibration(result.calibration);
        setAiStatusMsg(`✨ ¡Encuadre por Visión IA completado! Campos colocados al lado de las etiquetas preimpresas de la papelería.`);
      } else {
        // Fallback
        handleAutoCalibrate('printed_lines');
      }
    } catch (err: any) {
      handleAutoCalibrate('printed_lines');
    } finally {
      setIsVisionScanning(false);
      setTimeout(() => setAiStatusMsg(null), 6000);
    }
  };

  const getProfileName = (p: AIPresetProfile) => {
    switch (p) {
      case 'printed_lines':
        return 'Papelería con Renglones Físicos (Nombre, Cédula y Fecha en líneas separadas)';
      case 'magic_graphic':
        return 'Oficial Magic Graphic (Cabecera Estándar)';
      case 'high_capacity':
        return 'Alta Capacidad (Texto Extenso)';
      case 'compact':
        return 'Compacto Simétrico';
    }
  };

  // Nudge helpers
  const nudge = (dTop: number, dLeft: number) => {
    if (!selectedField) return;
    onUpdateField({
      ...selectedField,
      top: Math.max(0, Math.min(1123 - selectedField.height, selectedField.top + dTop)),
      left: Math.max(0, Math.min(794 - selectedField.width, selectedField.left + dLeft)),
    });
  };

  const resize = (dW: number, dH: number) => {
    if (!selectedField) return;
    onUpdateField({
      ...selectedField,
      width: Math.max(20, Math.min(794 - selectedField.left, selectedField.width + dW)),
      height: Math.max(16, Math.min(1123 - selectedField.top, selectedField.height + dH)),
    });
  };

  const adjustFontSize = (delta: number) => {
    if (!selectedField) return;
    const current = selectedField.fontSize || 12;
    onUpdateField({
      ...selectedField,
      fontSize: Math.max(8, Math.min(32, current + delta)),
    });
  };

  const adjustLineHeight = (delta: number) => {
    if (!selectedField) return;
    const current = selectedField.lineHeight || 20;
    onUpdateField({
      ...selectedField,
      lineHeight: Math.max(12, Math.min(50, current + delta)),
    });
  };

  const toggleBold = () => {
    if (!selectedField) return;
    const isBold = selectedField.fontWeight === 'bold' || selectedField.fontWeight === '900';
    onUpdateField({
      ...selectedField,
      fontWeight: isBold ? 'normal' : 'bold',
    });
  };

  const setAlign = (align: 'left' | 'center' | 'right' | 'justify') => {
    if (!selectedField) return;
    onUpdateField({
      ...selectedField,
      textAlign: align,
    });
  };

  const handleCopyCode = () => {
    const code = generateTypeScriptCode(calibration, activeDoc);
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 3000);
  };

  const docTypes: DocType[] = ['RECIPES', 'INFORME', 'ORDEN_LAB', 'CONSTANCIA', 'HISTORIA'];

  if (isMinimized) {
    return (
      <div className="fixed bottom-4 right-4 z-50 flex items-center gap-2 bg-slate-900 border-2 border-cyan-400 text-white px-4 py-2.5 rounded-2xl shadow-2xl animate-fade-in print:hidden">
        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
        <span className="text-xs font-bold font-mono">MODO PROGRAMADOR ACTIVO</span>
        <button
          type="button"
          onClick={() => setIsMinimized(false)}
          className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 ml-2 cursor-pointer"
          title="Expandir Estudio de Calibración"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="sticky top-2 z-50 w-full max-w-[840px] mb-4 bg-slate-950/95 backdrop-blur-xl border-2 border-cyan-500/80 rounded-3xl p-4 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.8)] text-white animate-fade-in print:hidden">
      {/* 1. Barra Superior del Programador: Título, Selector de Documento y Botones Clave */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/30">
            <Sparkles className="w-5 h-5 text-cyan-200 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black tracking-tight text-white flex items-center gap-1.5">
                <span>Taller de Calibración Maestra & Motor IA</span>
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-cyan-950 text-cyan-300 border border-cyan-700/80 uppercase tracking-wider">
                Exclusivo Programador
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Alinee las cajas sobre la papelería física. Puede usar el botón de <strong>Auto-Calibrar con IA</strong> para resolver todo con 1 clic.
            </p>
          </div>
        </div>

        {/* Acciones de Cabecera: Minimizar, Código, Respaldo, Reset, Guardar y Cerrar */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Input oculto para restaurar respaldo JSON */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImportBackup}
            accept=".json,application/json"
            className="hidden"
          />

          {/* Botón Descargar Respaldo JSON */}
          <button
            type="button"
            onClick={handleExportBackup}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-emerald-300 text-xs font-semibold border border-slate-700 transition cursor-pointer"
            title="Descargar una copia de seguridad en formato JSON de las 5 calibraciones a su computador"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Descargar Respaldo</span>
          </button>

          {/* Botón Restaurar Respaldo JSON */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 text-xs font-semibold border border-slate-700 transition cursor-pointer"
            title="Restaurar o cargar una copia previa de calibraciones (.json)"
          >
            <Upload className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Restaurar</span>
          </button>

          {/* Botón Ver/Copiar Código TS */}
          <button
            type="button"
            onClick={() => setShowCodeModal(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition cursor-pointer"
            title="Ver y copiar el código fuente TypeScript generado para el repositorio"
          >
            <Code2 className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Código TS</span>
          </button>

          {/* Botón PDF Prueba Calibración V2 */}
          <button
            type="button"
            onClick={handleGenerateTestCalibrationPdf}
            disabled={isGeneratingTestPdf}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-amber-200 text-xs font-semibold border border-amber-600/50 transition cursor-pointer"
            title="Generar PDF de prueba de calibración V2 con recuadros de depuración y texto de estrés físico"
          >
            <Download className={`w-3.5 h-3.5 ${isGeneratingTestPdf ? 'animate-bounce text-amber-400' : 'text-amber-400'}`} />
            <span className="hidden sm:inline">{isGeneratingTestPdf ? 'Generando Test...' : 'Test PDF V2'}</span>
          </button>

          {/* Botón Auditoría Arquitectura V2 */}
          <button
            type="button"
            onClick={handleRunV2Audit}
            disabled={isRunningV2Audit}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 text-xs font-semibold border border-cyan-700/50 transition cursor-pointer"
            title="Ejecutar suite de auditoría técnica V2 (MasterTemplateV2, overlays vectoriales y esquemas canónicos)"
          >
            <ShieldCheck className={`w-3.5 h-3.5 ${isRunningV2Audit ? 'text-amber-400 animate-spin' : 'text-cyan-400'}`} />
            <span className="hidden sm:inline">{isRunningV2Audit ? 'Auditando V2...' : 'Auditoría V2'}</span>
          </button>

          {/* Botón Auditoría de Fidelidad Vectorial */}
          <button
            type="button"
            onClick={handleRunFidelityAudit}
            disabled={isRunningFidelity}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-emerald-300 text-xs font-semibold border border-slate-700 transition cursor-pointer"
            title="Ejecutar suite de auditoría técnica 1:1 de inmutabilidad y fidelidad vectorial en los 5 documentos"
          >
            <ShieldCheck className={`w-3.5 h-3.5 ${isRunningFidelity ? 'text-amber-400 animate-spin' : 'text-emerald-400'}`} />
            <span className="hidden sm:inline">{isRunningFidelity ? 'Auditando...' : 'Auditoría Vectorial'}</span>
          </button>

          {/* Botón Restablecer */}
          <button
            type="button"
            onClick={onResetDefaults}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-amber-300 text-xs font-semibold border border-slate-800 transition cursor-pointer"
            title="Restablecer coordenadas por defecto"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset</span>
          </button>

          {/* Botón Guardar Definitivo de Fábrica */}
          <button
            type="button"
            onClick={onSaveAsFactoryDefault}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black transition shadow-lg cursor-pointer ${
              hasUnsavedChanges
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 shadow-emerald-500/30 animate-pulse'
                : 'bg-emerald-600/90 text-white hover:bg-emerald-500'
            }`}
            title="Guardar estas coordenadas como definitivas para el Dr. Samir (Almacenamiento Local + Servidor)"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Guardar Definitivo</span>
          </button>

          {/* Minimizar */}
          <button
            type="button"
            onClick={() => setIsMinimized(true)}
            className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition cursor-pointer"
            title="Minimizar panel a una burbuja flotante"
          >
            <Minimize2 className="w-4 h-4" />
          </button>

          {/* Cerrar Modo Programador */}
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-900 hover:bg-red-950 text-slate-400 hover:text-red-400 border border-slate-800 hover:border-red-800 transition cursor-pointer"
            title="Salir del Modo Programador y volver a la vista médica del Dr. Samir"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. Pestañas de Selector de Documento dentro del Estudio */}
      <div className="pt-2.5 flex items-center justify-between gap-2 overflow-x-auto pb-1">
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400 text-[11px] font-bold shrink-0">Documento:</span>
          {docTypes.map((doc) => {
            const isDocActive = activeDoc === doc;
            return (
              <button
                key={doc}
                type="button"
                onClick={() => onChangeDoc(doc)}
                className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  isDocActive
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
                }`}
              >
                {DOCUMENT_DEFINITIONS[doc]?.shortName || doc}
              </button>
            );
          })}
        </div>

        {/* Dimensiones oficiales A4 & Switch de Unidades (mm vs px) */}
        <div className="flex items-center gap-2 shrink-0 text-xs">
          <span className="font-mono text-[11px] text-slate-400 bg-slate-900 px-2 py-0.5 rounded-lg border border-slate-800">
            A4: 210×297 mm • 794×1123 px
          </span>
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-0.5">
            <button
              type="button"
              onClick={() => setUnit('mm')}
              className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                unit === 'mm' ? 'bg-cyan-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
              }`}
            >
              Milímetros (mm)
            </button>
            <button
              type="button"
              onClick={() => setUnit('px')}
              className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                unit === 'px' ? 'bg-cyan-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
              }`}
            >
              Píxeles (px)
            </button>
          </div>
        </div>
      </div>

      {/* 3. MÓDULO DE INTELIGENCIA ARTIFICIAL: Auto-Calibración en 1 Clic */}
      <div className="mt-3 p-3 bg-gradient-to-r from-blue-950/80 via-slate-900 to-indigo-950/80 border border-cyan-500/40 rounded-2xl flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
            <Sparkles className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black text-white">
                Auto-Calibración Inteligente (IA)
              </span>
              <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-bold">
                <CheckCircle2 className="w-3 h-3" /> Algoritmo Óptico Listo
              </span>
            </div>
            <p className="text-[11px] text-slate-300">
              La IA calcula matemáticamente los márgenes, columnas gemelas y alturas de texto sin que usted tenga que medir a mano.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Selector de Perfil de IA */}
          <select
            value={aiProfile}
            onChange={(e) => setAiProfile(e.target.value as AIPresetProfile)}
            className="bg-slate-900 border border-slate-700 text-cyan-200 text-xs font-bold rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            <option value="printed_lines">📄 Papelería con Renglones (Nombre, C.I., Fecha separados)</option>
            <option value="magic_graphic">📐 Oficial Magic Graphic (Cabecera Estándar)</option>
            <option value="high_capacity">📝 Alta Capacidad (Texto Extenso)</option>
            <option value="compact">⚡ Modo Compacto Simétrico</option>
          </select>

          {/* Botón Cargar Papelería Original */}
          {onOpenUploader && (
            <button
              type="button"
              onClick={onOpenUploader}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-cyan-300 border border-blue-600/50 font-bold text-xs shadow-md transition cursor-pointer"
              title="Cargar o cambiar el escaneo original de la papelería física (A4 300 DPI)"
            >
              <UploadCloud className="w-3.5 h-3.5 text-cyan-400" />
              <span>Cargar Papelería</span>
            </button>
          )}

          {/* Botón Escaneo Visual Multimodal Gemini */}
          <button
            type="button"
            onClick={handleVisionScan}
            disabled={isVisionScanning}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-indigo-500/25 transition cursor-pointer disabled:opacity-50"
            title="Analiza la imagen de la hoja con IA para detectar dónde están escritas las palabras 'Nombre', 'Cédula', 'Fecha' y alinea los campos a su lado"
          >
            <Eye className={`w-3.5 h-3.5 text-cyan-300 ${isVisionScanning ? 'animate-spin' : ''}`} />
            <span>{isVisionScanning ? 'Escaneando Renglones...' : '👁️ Visión IA (Leer Fondo)'}</span>
          </button>

          {/* Botón Maestro de Auto-Calibración Óptica */}
          <button
            type="button"
            onClick={() => handleAutoCalibrate()}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs shadow-lg shadow-cyan-500/30 transition cursor-pointer hover:-translate-y-0.5 active:translate-y-0"
          >
            <Sparkles className="w-4 h-4 text-slate-950" />
            <span>✨ Auto-Calibrar con IA (1 Clic)</span>
          </button>
        </div>
      </div>

      {aiStatusMsg && (
        <div className="mt-2 p-2 bg-cyan-950/80 border border-cyan-500/50 rounded-xl text-cyan-300 text-xs font-bold text-center animate-fade-in">
          {aiStatusMsg}
        </div>
      )}

      {backupToast && (
        <div className="mt-2 p-2.5 bg-emerald-950/90 border border-emerald-500/60 rounded-xl text-emerald-300 text-xs font-black text-center shadow-lg shadow-emerald-900/30 animate-fade-in flex items-center justify-center gap-2">
          <span>{backupToast}</span>
        </div>
      )}

      {/* 4. Panel de Inspección y Micro-Ajuste del Campo Seleccionado */}
      <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Selector de Campo */}
        <div className="flex items-center gap-1.5 flex-1 min-w-[220px]">
          <span className="text-slate-400 text-[11px] font-bold shrink-0">Campo:</span>
          <select
            value={selectedFieldId || ''}
            onChange={(e) => onSelectField(e.target.value || null)}
            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-cyan-300 font-bold focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            <option value="">-- Toque un campo en la hoja o elija aquí --</option>
            {fields.map((f) => {
              const topVal = unit === 'mm' ? `${pxToMm(f.top)}mm` : `${f.top}px`;
              const leftVal = unit === 'mm' ? `${pxToMm(f.left)}mm` : `${f.left}px`;
              const wVal = unit === 'mm' ? `${pxToMm(f.width)}mm` : `${f.width}px`;
              const hVal = unit === 'mm' ? `${pxToMm(f.height)}mm` : `${f.height}px`;

              return (
                <option key={f.id} value={f.id}>
                  {f.label} → (Y: {topVal}, X: {leftVal}) [{wVal} × {hVal}]
                </option>
              );
            })}
          </select>
        </div>

        {/* Controles de Precisión para el Campo Activo */}
        {selectedField ? (
          <div className="flex flex-wrap items-center gap-2">
            {/* D-Pad de Movimiento */}
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-0.5 gap-0.5">
              <span className="text-[10px] text-slate-500 font-mono px-1 font-bold">POS</span>
              <button
                type="button"
                onClick={() => nudge(0, -1)}
                className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white"
                title="Mover 1px izquierda"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => nudge(-1, 0)}
                className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white"
                title="Mover 1px arriba"
              >
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => nudge(1, 0)}
                className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white"
                title="Mover 1px abajo"
              >
                <ArrowDown className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => nudge(0, 1)}
                className="p-1 rounded hover:bg-slate-800 text-slate-300 hover:text-white"
                title="Mover 1px derecha"
              >
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <div className="h-3 w-px bg-slate-800 mx-0.5"></div>

              {/* Salto rápido de 10px / 2.6mm */}
              <button
                type="button"
                onClick={() => nudge(-10, 0)}
                className="text-[10px] font-bold px-1 py-0.5 rounded hover:bg-cyan-950 text-cyan-300"
                title="Subir 10px"
              >
                ↑10
              </button>
              <button
                type="button"
                onClick={() => nudge(10, 0)}
                className="text-[10px] font-bold px-1 py-0.5 rounded hover:bg-cyan-950 text-cyan-300"
                title="Bajar 10px"
              >
                ↓10
              </button>
              <button
                type="button"
                onClick={() => nudge(0, -10)}
                className="text-[10px] font-bold px-1 py-0.5 rounded hover:bg-cyan-950 text-cyan-300"
                title="Izquierda 10px"
              >
                ←10
              </button>
              <button
                type="button"
                onClick={() => nudge(0, 10)}
                className="text-[10px] font-bold px-1 py-0.5 rounded hover:bg-cyan-950 text-cyan-300"
                title="Derecha 10px"
              >
                →10
              </button>
            </div>

            {/* Coordenadas Numéricas Directas (mm o px) */}
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl px-2 py-0.5 gap-1.5 text-[11px]">
              <label className="flex items-center gap-1 font-mono text-slate-400">
                <span>Y:</span>
                <input
                  type="number"
                  value={unit === 'mm' ? pxToMm(selectedField.top) : selectedField.top}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value) || 0;
                    onUpdateField({
                      ...selectedField,
                      top: unit === 'mm' ? mmToPx(val) : val,
                    });
                  }}
                  className="w-13 bg-slate-950 border border-slate-700 text-cyan-300 font-bold px-1 py-0.5 rounded text-center focus:outline-none focus:border-cyan-500"
                />
                <span className="text-[9px] text-slate-500">{unit}</span>
              </label>

              <label className="flex items-center gap-1 font-mono text-slate-400">
                <span>X:</span>
                <input
                  type="number"
                  value={unit === 'mm' ? pxToMm(selectedField.left) : selectedField.left}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value) || 0;
                    onUpdateField({
                      ...selectedField,
                      left: unit === 'mm' ? mmToPx(val) : val,
                    });
                  }}
                  className="w-13 bg-slate-950 border border-slate-700 text-cyan-300 font-bold px-1 py-0.5 rounded text-center focus:outline-none focus:border-cyan-500"
                />
                <span className="text-[9px] text-slate-500">{unit}</span>
              </label>
            </div>

            {/* Controles de Tamaño (Ancho / Alto) */}
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-0.5 gap-1">
              <span className="text-[10px] text-slate-500 font-mono px-1 font-bold">DIM</span>
              <button
                type="button"
                onClick={() => resize(-10, 0)}
                className="text-[10px] font-bold px-1.5 py-0.5 rounded hover:bg-slate-800 text-slate-300"
                title="Reducir Ancho -10px"
              >
                W-
              </button>
              <span className="font-mono text-cyan-300 text-[10px]">
                {unit === 'mm' ? `${pxToMm(selectedField.width)}mm` : `${selectedField.width}px`}
              </span>
              <button
                type="button"
                onClick={() => resize(10, 0)}
                className="text-[10px] font-bold px-1.5 py-0.5 rounded hover:bg-slate-800 text-slate-300"
                title="Aumentar Ancho +10px"
              >
                W+
              </button>

              <div className="h-3 w-px bg-slate-800 mx-0.5"></div>

              <button
                type="button"
                onClick={() => resize(0, -10)}
                className="text-[10px] font-bold px-1.5 py-0.5 rounded hover:bg-slate-800 text-slate-300"
                title="Reducir Alto -10px"
              >
                H-
              </button>
              <span className="font-mono text-cyan-300 text-[10px]">
                {unit === 'mm' ? `${pxToMm(selectedField.height)}mm` : `${selectedField.height}px`}
              </span>
              <button
                type="button"
                onClick={() => resize(0, 10)}
                className="text-[10px] font-bold px-1.5 py-0.5 rounded hover:bg-slate-800 text-slate-300"
                title="Aumentar Alto +10px"
              >
                H+
              </button>
            </div>

            {/* Tipografía y Alineación */}
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-0.5 gap-1">
              <span className="text-[10px] text-slate-500 font-mono px-1 font-bold">TEXTO</span>
              <button
                type="button"
                onClick={() => adjustFontSize(-1)}
                className="text-[10px] font-bold px-1.5 py-0.5 rounded hover:bg-slate-800 text-slate-300"
                title="Reducir tamaño de letra"
              >
                A-
              </button>
              <span className="text-[10px] font-mono text-cyan-300 px-0.5 font-bold">
                {selectedField.fontSize || 12}px
              </span>
              <button
                type="button"
                onClick={() => adjustFontSize(1)}
                className="text-[10px] font-bold px-1.5 py-0.5 rounded hover:bg-slate-800 text-slate-300"
                title="Aumentar tamaño de letra"
              >
                A+
              </button>

              {/* Interlineado si es multilínea */}
              {selectedField.height > 40 && (
                <>
                  <div className="h-3 w-px bg-slate-800 mx-0.5"></div>
                  <button
                    type="button"
                    onClick={() => adjustLineHeight(-2)}
                    className="text-[10px] font-bold px-1 py-0.5 rounded hover:bg-slate-800 text-slate-300"
                    title="Reducir interlineado"
                  >
                    ↕-
                  </button>
                  <span className="text-[10px] font-mono text-amber-300 px-0.5 font-bold">
                    {selectedField.lineHeight || 20}
                  </span>
                  <button
                    type="button"
                    onClick={() => adjustLineHeight(2)}
                    className="text-[10px] font-bold px-1 py-0.5 rounded hover:bg-slate-800 text-slate-300"
                    title="Aumentar interlineado"
                  >
                    ↕+
                  </button>
                </>
              )}

              <div className="h-3 w-px bg-slate-800 mx-0.5"></div>

              {/* Negrita */}
              <button
                type="button"
                onClick={toggleBold}
                className={`p-1 rounded ${
                  selectedField.fontWeight === 'bold' || selectedField.fontWeight === '900'
                    ? 'bg-cyan-500 text-slate-950 font-black'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Negrita"
              >
                <Bold className="w-3 h-3" />
              </button>

              {/* Alineaciones */}
              <button
                type="button"
                onClick={() => setAlign('left')}
                className={`p-1 rounded ${
                  selectedField.textAlign === 'left' || !selectedField.textAlign
                    ? 'bg-cyan-500 text-slate-950'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Alinear Izquierda"
              >
                <AlignLeft className="w-3 h-3" />
              </button>
              <button
                type="button"
                onClick={() => setAlign('center')}
                className={`p-1 rounded ${
                  selectedField.textAlign === 'center'
                    ? 'bg-cyan-500 text-slate-950'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Alinear Centro"
              >
                <AlignCenter className="w-3 h-3" />
              </button>
              <button
                type="button"
                onClick={() => setAlign('justify')}
                className={`p-1 rounded ${
                  selectedField.textAlign === 'justify'
                    ? 'bg-cyan-500 text-slate-950'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Justificado"
              >
                <AlignJustify className="w-3 h-3" />
              </button>
            </div>
          </div>
        ) : (
          <div className="text-cyan-300 text-xs italic flex items-center gap-1.5 py-1 bg-cyan-950/40 px-3 rounded-xl border border-cyan-800/50">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>Toque directamente cualquier casilla con el ratón sobre la hoja A4 para moverla o redimensionarla libremente.</span>
          </div>
        )}
      </div>

      {/* 5. Sub-barra de Opciones de Prueba y Diagnóstico */}
      <div className="mt-3 pt-2.5 border-t border-slate-900 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-slate-400 text-[11px] font-bold">Simulación de Texto:</span>
          <button
            type="button"
            onClick={() => onToggleTestMode('real')}
            className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition cursor-pointer ${
              testMode === 'real'
                ? 'bg-blue-600 text-white font-black'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            Caso Clínico Normal
          </button>
          <button
            type="button"
            onClick={() => onToggleTestMode('stress')}
            className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition cursor-pointer ${
              testMode === 'stress'
                ? 'bg-amber-600 text-white font-black'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            Texto Extenso de Estrés (Ver Desbordes)
          </button>
        </div>

        {/* Diagnóstico de solapamientos / desbordes */}
        <div>
          {hasErrors ? (
            <span className="text-amber-400 flex items-center gap-1 text-[11px] font-bold">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              {diagnostics[0]?.message}
            </span>
          ) : (
            <span className="text-emerald-400 flex items-center gap-1 text-[11px] font-semibold">
              <Check className="w-3.5 h-3.5" /> Márgenes de Impresión A4 Válidos (Sin Desborde)
            </span>
          )}
        </div>
      </div>

      {/* Modal de Código Fuente TypeScript para el Programador */}
      {showCodeModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-2xl w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white">
                <Code2 className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-sm">Código TypeScript para {DOCUMENT_DEFINITIONS[activeDoc]?.label}</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowCodeModal(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Copie este bloque de código si desea fijarlo de forma inmutable en el archivo <code className="text-cyan-300 font-mono">src/utils/calibrationStorage.ts</code> del proyecto:
            </p>

            <pre className="p-4 bg-black/80 border border-slate-800 rounded-2xl text-[11px] font-mono text-cyan-200 overflow-x-auto max-h-72">
              {generateTypeScriptCode(calibration, activeDoc)}
            </pre>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition cursor-pointer"
              >
                {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCode ? '¡Copiado al Portapapeles!' : 'Copiar Código'}</span>
              </button>
              <button
                type="button"
                onClick={() => setShowCodeModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Auditoría de Fidelidad Vectorial e Inmutabilidad */}
      {showFidelityModal && fidelityReport && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="bg-slate-900 border-2 border-emerald-500/80 rounded-3xl p-6 max-w-3xl w-full shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5 text-white">
                <div className="p-2 rounded-2xl bg-emerald-950 border border-emerald-700 text-emerald-400">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-base flex items-center gap-2">
                    Auditoría de Fidelidad PDF 1:1 e Inmutabilidad
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-900/80 text-emerald-300 border border-emerald-600">
                      {fidelityReport.overallStatus === 'PASS' ? '100% PASS' : 'REVISIÓN'}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Verificación de plantillas base oficiales, preservación de MediaBox/CropBox y overlay vectorial.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowFidelityModal(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Resumen General */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">Documentos</span>
                <span className="text-lg font-black text-emerald-400">{fidelityReport.summary.totalPassed} / {fidelityReport.summary.totalDocumentsTested} PASS</span>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">Inmutabilidad</span>
                <span className="text-sm font-bold text-cyan-300">100% Bit-a-Bit</span>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">Motor Gráfico</span>
                <span className="text-sm font-bold text-emerald-300">Overlay Vectorial</span>
              </div>
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">Rasterización</span>
                <span className="text-sm font-bold text-indigo-300">0% (Eliminada)</span>
              </div>
            </div>

            {/* Detalle por Documento */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Documentos Clínicos Auditados:</h4>
              <div className="space-y-1.5">
                {fidelityReport.documentFidelity.map((doc) => (
                  <div key={doc.docType} className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl flex items-center justify-between text-xs">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white uppercase">{doc.docType}</span>
                        <span className="text-slate-400 font-mono text-[11px]">({doc.templateFile})</span>
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-3">
                        <span>Páginas: <strong className="text-slate-200">{doc.testPageCount}</strong></span>
                        <span>MediaBox: <strong className="text-emerald-400">595.28 × 841.89 pt (A4)</strong></span>
                        <span>Vector: <strong className="text-emerald-400">100%</strong></span>
                      </div>
                    </div>
                    <span className="px-2.5 py-1 rounded-xl text-[11px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                      PASS
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Pruebas Shrink to fit */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Pruebas de Reducción Automática (Shrink-to-Fit):</h4>
              <div className="space-y-1.5">
                {fidelityReport.shrinkToFitTests.map((st, i) => (
                  <div key={i} className="p-2.5 bg-slate-950/60 border border-slate-800 rounded-2xl flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-slate-200">{st.caseName}</span>
                      <p className="text-[11px] text-slate-400">
                        Fuente final calculada: <span className="font-mono text-cyan-300">{st.calculatedFontSize} pt</span> | Revisión requerida: <span className={st.requiresReview ? 'text-amber-400' : 'text-emerald-400'}>{st.requiresReview ? 'SÍ (Protección contra truncado)' : 'NO (Ajuste automático perfecto)'}</span>
                      </p>
                    </div>
                    <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                      PASS
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowFidelityModal(false)}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-xs transition cursor-pointer shadow-lg shadow-emerald-600/30"
              >
                Entendido y Verificado
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Auditoría Arquitectura V2 */}
      {showV2Modal && v2Report && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-cyan-800/60 rounded-3xl p-6 max-w-2xl w-full max-h-[85vh] overflow-y-auto space-y-4 shadow-2xl shadow-cyan-950/50">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-6 h-6 text-cyan-400" />
                <h3 className="text-lg font-black text-white">Auditoría Arquitectura V2</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowV2Modal(false)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-cyan-950/40 border border-cyan-800/40 rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-cyan-200">Veredicto Arquitectura V2:</span>
                <p className="text-sm font-black text-emerald-400">
                  {v2Report.errors.length === 0 ? '✓ 100% CUMPLIMIENTO CONTRATO V2' : '⚠ OBSERVACIONES'}
                </p>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                Total Masters: {v2Report.totalMastersChecked}
              </span>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Verificaciones de Sistema V2:</h4>
              <div className="space-y-1.5 text-xs">
                <div className="p-2.5 bg-slate-950/60 border border-slate-800 rounded-2xl flex items-center justify-between">
                  <span className="text-slate-300">Todos los Masters bloqueados (LOCKED):</span>
                  <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                    {v2Report.allMastersLocked ? 'LOCKED (INMUTABLE)' : 'FAIL'}
                  </span>
                </div>
                <div className="p-2.5 bg-slate-950/60 border border-slate-800 rounded-2xl flex items-center justify-between">
                  <span className="text-slate-300">Mapeo Semántico Desacoplado:</span>
                  <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                    {v2Report.semanticMappingValid ? 'VALIDADO' : 'FAIL'}
                  </span>
                </div>
                <div className="p-2.5 bg-slate-950/60 border border-slate-800 rounded-2xl flex items-center justify-between">
                  <span className="text-slate-300">Inyección Vectorial Nativa (pdf-lib):</span>
                  <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                    {v2Report.vectorInjectionTestPassed ? 'VECTORIAL DIRECTO' : 'FAIL'}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Tipos de Elementos Validados:</h4>
              <div className="flex flex-wrap gap-1.5">
                {v2Report.elementTypesValidated.map((t) => (
                  <span key={t} className="px-2.5 py-1 bg-slate-800 text-cyan-300 text-[11px] font-mono rounded-lg border border-slate-700">
                    {t}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowV2Modal(false)}
                className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black text-xs transition cursor-pointer shadow-lg shadow-cyan-600/30"
              >
                Cerrar Auditoría V2
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
