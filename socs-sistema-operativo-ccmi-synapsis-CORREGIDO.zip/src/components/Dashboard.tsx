import React, { useState } from 'react';
import { 
  FileText, 
  History, 
  Printer, 
  UserCheck, 
  ChevronRight, 
  CreditCard, 
  Pill, 
  FlaskConical, 
  CalendarCheck, 
  ClipboardList,
  Boxes,
  Menu,
  X,
  Stethoscope,
  Sliders,
  Layers,
  Sparkles,
  Code2,
  Lock,
  Wrench
} from 'lucide-react';
import { ActiveNavTab, ProcessedDocumentResult, DocType } from '../types';
import { BrandLogo } from './BrandLogo';
import { DocumentSelectorWorkspace } from './DocumentSelectorWorkspace';
import { LogisticsQuoter } from './LogisticsQuoter';
import { HistoryList } from './HistoryList';
import { DoctorBusinessCard } from './DoctorBusinessCard';
import { DocumentZoneEditorStudio } from './DocumentZoneEditorStudio';

// Initial Mock History Records
const INITIAL_HISTORY: ProcessedDocumentResult[] = [
  {
    id: 'doc_init_1',
    docNumber: 'SOCS-2026-10492',
    documentType: 'recipe',
    patient: {
      fullName: 'Mariana González Rivas',
      idType: 'V',
      nationalId: '14.230.198',
      age: '42',
      gender: 'F',
      allergies: 'Negadas',
      phone: '0412-9841029',
    },
    structuredData: {
      diagnosisPrincipal: 'Cervicalgia tensional aguda + Espasmo paravertebral',
      secondaryDiagnoses: [],
      cie10Suggestions: ['M54.2'],
      medications: [
        {
          id: 'm1',
          drug: 'Tiocolchicósido 4mg',
          dose: '1 cápsula',
          frequency: 'Cada 12 horas',
          duration: 'Por 5 días',
          instructions: 'Tomar después del desayuno y la cena.',
        },
        {
          id: 'm2',
          drug: 'Ketoprofeno 100mg',
          dose: '1 tableta',
          frequency: 'Cada 8 horas',
          duration: 'Por 4 días',
          instructions: 'Junto con protector gástrico.',
        },
      ],
      generalIndications: ['Calor local seco 15 min 2 veces al día', 'Evitar posturas forzadas'],
      summaryNote: 'Paciente con dolor en región cervical de 3 días de evolución posterior a sobrecarga laboral.',
    },
    templateName: 'Plantilla Oficial CcMi - Récipe Médico (Doble Talón)',
    googleDriveFileId: '1drive_ccmi_rec_091',
    googleDocUrl: 'https://docs.google.com',
    pdfExportUrl: '#pdf-preview',
    generatedAt: '05/09/2026',
    doctorName: 'Dr. Samir Moucharrafie',
    doctorRegistration: 'M.P.P.S. 61231 / C.M.E.B. 5331',
  },
  {
    id: 'doc_init_2',
    docNumber: 'SOCS-2026-10488',
    documentType: 'certificate',
    patient: {
      fullName: 'Héctor José Valera',
      idType: 'V',
      nationalId: '19.502.833',
      age: '31',
      gender: 'M',
      allergies: 'Dipirona',
      phone: '0416-5541299',
    },
    structuredData: {
      diagnosisPrincipal: 'Lumbociatalgia izquierda por hernia discal L5-S1',
      secondaryDiagnoses: [],
      medications: [],
      generalIndications: ['Reposo físico relativo', 'Crioterapia lumbar'],
      restDays: 7,
      summaryNote: 'Evaluación de columna lumbar. Requiere reposo e inicio de terapia física.',
    },
    templateName: 'Plantilla Oficial CcMi - Constancia de Reposo / Asistencia',
    googleDriveFileId: '1drive_ccmi_cert_084',
    googleDocUrl: 'https://docs.google.com',
    pdfExportUrl: '#pdf-preview',
    generatedAt: '03/09/2026',
    doctorName: 'Dr. Samir Moucharrafie',
    doctorRegistration: 'M.P.P.S. 61231 / C.M.E.B. 5331',
  },
];

export const Dashboard: React.FC = () => {
  // Direct default to the clean A4 workstation for Dr. Samir
  const [activeTab, setActiveTab] = useState<'workspace' | 'history' | 'quoter' | 'developer_studio'>('workspace');
  const [selectedDoc, setSelectedDoc] = useState<DocType>('RECIPES');
  const [documentsHistory, setDocumentsHistory] = useState<ProcessedDocumentResult[]>(INITIAL_HISTORY);
  const [isCardModalOpen, setIsCardModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const docTabs: { id: DocType; name: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'RECIPES', name: 'Récipe (Doble Talón)', icon: Pill },
    { id: 'INFORME', name: 'Informe Médico', icon: FileText },
    { id: 'ORDEN_LAB', name: 'Orden de Exámenes', icon: FlaskConical },
    { id: 'CONSTANCIA', name: 'Constancia de Reposo', icon: CalendarCheck },
    { id: 'HISTORIA', name: 'Historia Clínica', icon: ClipboardList },
  ];

  return (
    <div id="socs-dashboard-root" className="min-h-screen bg-slate-100/80 text-slate-900 flex flex-col font-sans">
      {/* 1. TOP EXECUTIVE CLINICAL BAR */}
      <header className="bg-[#092347] text-white border-b border-blue-950/80 sticky top-0 z-40 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          
          {/* Logo e Identidad del Doctor */}
          <div className="flex items-center gap-3 shrink-0">
            <div 
              onClick={() => setIsCardModalOpen(true)}
              className="w-10 h-10 rounded-xl bg-white p-1 flex items-center justify-center shadow-md cursor-pointer hover:ring-2 hover:ring-cyan-400 transition"
              title="Click para ver la Tarjeta Médica Oficial"
            >
              <BrandLogo size={32} />
            </div>
            
            <div className="hidden sm:block">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-sm sm:text-base tracking-tight text-white">
                  Dr. Samir Moucharrafie Naime
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-500/30 text-cyan-300 font-semibold border border-blue-400/20">
                  MPPS: 61231 • CMEB: 5331
                </span>
              </div>
              <p className="text-[11px] text-blue-200/90 font-medium">
                Neurocirujano • Cirugía de Columna Mínimamente Invasiva (UCBL Lyon 1)
              </p>
            </div>
          </div>

          {/* Selector de los 5 Documentos A4 en Desktop para uso clínico del Doctor */}
          <div className="hidden md:flex items-center bg-[#061833] p-1 rounded-xl border border-blue-900/60">
            {docTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === 'workspace' && selectedDoc === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setSelectedDoc(tab.id);
                    setActiveTab('workspace');
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-blue-900/40'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-300' : 'text-slate-400'}`} />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </div>

          {/* Acciones Rápidas */}
          <div className="flex items-center gap-2">
            {/* BOTÓN EXCLUSIVO: DEVELOPER STUDIO (Calibración & Formas PDF) */}
            <button
              type="button"
              onClick={() => setActiveTab(activeTab === 'developer_studio' ? 'workspace' : 'developer_studio')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black border transition cursor-pointer shadow-md ${
                activeTab === 'developer_studio'
                  ? 'bg-amber-400 text-slate-950 border-amber-300 ring-2 ring-amber-400/50'
                  : 'bg-slate-900/90 hover:bg-slate-800 text-amber-300 border-amber-400/30 hover:border-amber-400'
              }`}
              title="Área exclusiva de Desarrollador: Calibración milimétrica sobre fondos originales fijos, editor de formas PDF (X, ✓, cuadros con punta) y exportador para Gemini AI"
            >
              <Code2 className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">🛠️ Dev Studio</span>
              <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-700/60 hidden lg:inline">
                Dev Only
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab(activeTab === 'history' ? 'workspace' : 'history')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border transition cursor-pointer ${
                activeTab === 'history'
                  ? 'bg-white text-[#092347] border-white shadow-sm'
                  : 'bg-blue-900/50 hover:bg-blue-800/60 text-blue-100 border-blue-700/50'
              }`}
              title="Historial de Documentos Emitidos"
            >
              <History className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Historial</span>
              <span className="px-1.5 py-0.2 bg-blue-950 text-cyan-300 rounded text-[10px] font-mono">
                {documentsHistory.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setIsCardModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600/90 hover:bg-cyan-500 text-white font-bold text-xs shadow-sm transition cursor-pointer"
              title="Tarjeta de Presentación con QR y Sedes"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Tarjeta Dr. Samir</span>
            </button>

            {/* Mobile Toggle */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-blue-200 hover:text-white rounded-lg hover:bg-blue-900/50 cursor-pointer"
              aria-label="Abrir menú"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Submenu for Document Types */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-[#061833] border-t border-blue-900 p-3 space-y-1 animate-fade-in">
            <div className="text-[10px] font-bold text-cyan-300 uppercase px-2 py-1">
              Seleccionar Formato A4
            </div>
            {docTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === 'workspace' && selectedDoc === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setSelectedDoc(tab.id);
                    setActiveTab('workspace');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-bold transition ${
                    isActive
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-300 hover:bg-blue-900/40'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4" />
                    <span>{tab.name}</span>
                  </div>
                  {isActive && <ChevronRight className="w-3.5 h-3.5 text-cyan-300" />}
                </button>
              );
            })}
            
            <div className="pt-2 border-t border-blue-900/60 mt-2 space-y-1">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('developer_studio');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold ${
                  activeTab === 'developer_studio' ? 'bg-amber-400 text-slate-950 font-black' : 'text-amber-300 hover:bg-blue-900/40'
                }`}
              >
                <Code2 className="w-4 h-4 text-amber-400" />
                <span>🛠️ Developer Studio (Calibración & Formas PDF)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('quoter');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold ${
                  activeTab === 'quoter' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-blue-900/40'
                }`}
              >
                <Boxes className="w-4 h-4 text-emerald-400" />
                <span>Cotizador Quirúrgico Synapsis</span>
              </button>
            </div>
          </div>
        )}
      </header>

      {/* 2. MAIN CENTERPIECE: A4 WORKSTATION FOR CLINICAL USE & DEV STUDIO */}
      <main className="flex-1 py-4 sm:py-6 px-2 sm:px-6 max-w-7xl mx-auto w-full">
        {/* Vista Clínica Oficial de Trabajo para el Dr. Samir Moucharrafie */}
        {activeTab === 'workspace' && (
          <div className="w-full">
            <DocumentSelectorWorkspace 
              initialDocType={selectedDoc} 
              key={selectedDoc} 
              onOpenZoneEditor={() => setActiveTab('developer_studio')}
            />
          </div>
        )}

        {/* Zona Exclusiva para Desarrollador: Calibración sobre Fondo Fijo + Formas PDF + Gemini Copier */}
        {activeTab === 'developer_studio' && (
          <div className="w-full">
            <DocumentZoneEditorStudio
              initialDoc={selectedDoc}
              onClose={() => setActiveTab('workspace')}
              onNavigateToWorkspace={(doc) => {
                setSelectedDoc(doc);
                setActiveTab('workspace');
              }}
            />
          </div>
        )}

        {activeTab === 'history' && (
          <div className="space-y-4 max-w-5xl mx-auto">
            <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Historial de Documentos Emitidos
                </h2>
                <p className="text-xs text-slate-500">
                  Registro de récipes, informes y constancias generadas en esta sesión.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('workspace')}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Volver a la Hoja de Trabajo
              </button>
            </div>
            <HistoryList documents={documentsHistory} />
          </div>
        )}

        {activeTab === 'quoter' && (
          <div className="space-y-4 max-w-5xl mx-auto">
            <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Cotizador Logístico Quirúrgico Synapsis
                </h2>
                <p className="text-xs text-slate-500">
                  Presupuestos de implantes, prótesis y tornillos de columna / cráneo.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('workspace')}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Volver a la Hoja de Trabajo
              </button>
            </div>
            <LogisticsQuoter />
          </div>
        )}
      </main>

      {/* Modal de Tarjeta de Presentación Digital */}
      <DoctorBusinessCard
        isModal
        isOpen={isCardModalOpen}
        onClose={() => setIsCardModalOpen(false)}
      />
    </div>
  );
};
