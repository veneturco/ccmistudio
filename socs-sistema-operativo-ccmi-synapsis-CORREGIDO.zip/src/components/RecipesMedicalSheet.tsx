import React from 'react';
import { OfficialMedicalStamp } from './OfficialMedicalStamp';
import { PatientData } from '../types';

export interface RecipesMedicalSheetProps {
  patient: PatientData;
  onUpdatePatient: (field: string, val: string) => void;
  recipeData: {
    rxLeft: string;
    indicationsRight: string;
  };
  onUpdateRecipeData: (field: 'rxLeft' | 'indicationsRight', val: string) => void;
  showStamp?: boolean;
  customBgUrl?: string | null;
  id?: string;
}

/**
 * RecipesMedicalSheet
 * Implementación oficial de récipe médico institucional de dos talones (Farmacia + Indicaciones)
 * AISLAMIENTO ARQUITECTÓNICO ESTRICTO:
 * - Talón Izquierdo (Farmacia): left: 45px, width: 335px (coordenada máxima 380px).
 * - Talón Derecho (Indicaciones): left: 415px, width: 335px.
 * Ningún elemento hijo puede sobrepasar sus límites ni cruzarse entre columnas.
 */
export const RecipesMedicalSheet: React.FC<RecipesMedicalSheetProps> = ({
  patient,
  onUpdatePatient,
  recipeData,
  onUpdateRecipeData,
  showStamp = true,
  customBgUrl = null,
  id = 'recipe-official-sheet',
}) => {
  const bgImage = customBgUrl || '/templates/recipes_bg.jpg';

  return (
    <div
      id={id}
      data-doc-page="1"
      className="relative bg-white shadow-2xl overflow-hidden print:shadow-none print:m-0 select-text"
      style={{
        width: '794px',
        height: '1123px',
        minWidth: '794px',
        minHeight: '1123px',
        maxWidth: '794px',
        maxHeight: '1123px',
        backgroundImage: `url("${bgImage}")`,
        backgroundSize: '100% 100%',
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'center',
        boxSizing: 'border-box',
        fontFamily: "'Liberation Sans', 'Arial', sans-serif",
      }}
    >
      {/* ==================================================================== */}
      {/* 1. TALÓN IZQUIERDO (FARMACIA / RP.): LEFT: 45px, WIDTH: 335px       */}
      {/* Límite horizontal absoluto: 45px + 335px = 380px.                   */}
      {/* ==================================================================== */}
      <div
        id="talon-izquierdo-farmacia"
        className="absolute top-0 left-[45px] w-[335px] max-w-[335px] h-[1123px] overflow-hidden box-border pointer-events-auto"
        style={{
          clipPath: 'inset(0 0 0 0)',
        }}
      >
        {/* Cabecera Paciente - Nombre y Apellido */}
        <input
          type="text"
          value={patient.fullName || ''}
          onChange={(e) => onUpdatePatient('fullName', e.target.value)}
          placeholder="NOMBRE DEL PACIENTE"
          className="absolute top-[102px] left-[55px] w-[275px] max-w-[275px] h-[24px] bg-transparent text-[#143e72] font-bold text-[12px] px-1 outline-none uppercase border-none truncate"
        />

        {/* Cabecera Paciente - Cédula de Identidad */}
        <input
          type="text"
          value={patient.idNumber || ''}
          onChange={(e) => onUpdatePatient('idNumber', e.target.value)}
          placeholder="V-00.000.000"
          className="absolute top-[132px] left-[32px] w-[95px] max-w-[95px] h-[22px] bg-transparent text-[#143e72] font-bold text-[11px] px-1 outline-none border-none truncate"
        />

        {/* Cabecera Paciente - Edad */}
        <input
          type="text"
          value={patient.age || ''}
          onChange={(e) => onUpdatePatient('age', e.target.value)}
          placeholder="Edad"
          className="absolute top-[132px] left-[155px] w-[45px] max-w-[45px] h-[22px] bg-transparent text-[#143e72] font-bold text-[11px] px-0.5 outline-none text-center border-none truncate"
        />

        {/* Cabecera Paciente - Fecha */}
        <input
          type="text"
          value={patient.date || ''}
          onChange={(e) => onUpdatePatient('date', e.target.value)}
          placeholder="DD/MM/AAAA"
          className="absolute top-[132px] left-[232px] w-[95px] max-w-[95px] h-[22px] bg-transparent text-[#143e72] font-bold text-[11px] px-0.5 outline-none text-center border-none truncate"
        />

        {/* Cuerpo Rp. / Farmacia */}
        <textarea
          value={recipeData.rxLeft || ''}
          onChange={(e) => onUpdateRecipeData('rxLeft', e.target.value)}
          placeholder="Rp. Prescripción farmacológica (Fármaco, concentración, presentación y cantidad)..."
          className="absolute top-[230px] left-[10px] w-[315px] max-w-[315px] h-[645px] bg-transparent text-[#143e72] font-semibold text-[11.5px] leading-relaxed p-1 outline-none resize-none border-none select-text"
          style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}
        />

        {/* Sello Oficial Izquierdo */}
        {showStamp && (
          <div className="absolute top-[898px] left-[135px] w-[170px] h-[85px] pointer-events-none flex items-center justify-center">
            <OfficialMedicalStamp inkColor="navy" size="md" />
          </div>
        )}
      </div>

      {/* ==================================================================== */}
      {/* 2. TALÓN DERECHO (INDICACIONES): LEFT: 415px, WIDTH: 335px          */}
      {/* Comienza estrictamente en 415px con 35px de separación de seguridad. */}
      {/* ==================================================================== */}
      <div
        id="talon-derecho-indicaciones"
        className="absolute top-0 left-[415px] w-[335px] max-w-[335px] h-[1123px] overflow-hidden box-border pointer-events-auto"
        style={{
          clipPath: 'inset(0 0 0 0)',
        }}
      >
        {/* Cabecera Paciente - Nombre y Apellido */}
        <input
          type="text"
          value={patient.fullName || ''}
          onChange={(e) => onUpdatePatient('fullName', e.target.value)}
          placeholder="NOMBRE DEL PACIENTE"
          className="absolute top-[102px] left-[55px] w-[275px] max-w-[275px] h-[24px] bg-transparent text-[#143e72] font-bold text-[12px] px-1 outline-none uppercase border-none truncate"
        />

        {/* Cabecera Paciente - Cédula de Identidad */}
        <input
          type="text"
          value={patient.idNumber || ''}
          onChange={(e) => onUpdatePatient('idNumber', e.target.value)}
          placeholder="V-00.000.000"
          className="absolute top-[132px] left-[32px] w-[95px] max-w-[95px] h-[22px] bg-transparent text-[#143e72] font-bold text-[11px] px-1 outline-none border-none truncate"
        />

        {/* Cabecera Paciente - Edad */}
        <input
          type="text"
          value={patient.age || ''}
          onChange={(e) => onUpdatePatient('age', e.target.value)}
          placeholder="Edad"
          className="absolute top-[132px] left-[155px] w-[45px] max-w-[45px] h-[22px] bg-transparent text-[#143e72] font-bold text-[11px] px-0.5 outline-none text-center border-none truncate"
        />

        {/* Cabecera Paciente - Fecha */}
        <input
          type="text"
          value={patient.date || ''}
          onChange={(e) => onUpdatePatient('date', e.target.value)}
          placeholder="DD/MM/AAAA"
          className="absolute top-[132px] left-[232px] w-[95px] max-w-[95px] h-[22px] bg-transparent text-[#143e72] font-bold text-[11px] px-0.5 outline-none text-center border-none truncate"
        />

        {/* Cuerpo Indicaciones al Paciente */}
        <textarea
          value={recipeData.indicationsRight || ''}
          onChange={(e) => onUpdateRecipeData('indicationsRight', e.target.value)}
          placeholder="Indicaciones terapéuticas detalladas (Dosis, vía de administración, frecuencia, duración y recomendaciones)..."
          className="absolute top-[230px] left-[10px] w-[315px] max-w-[315px] h-[645px] bg-transparent text-slate-900 font-medium text-[11.5px] leading-relaxed p-1 outline-none resize-none border-none select-text"
          style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}
        />

        {/* Sello Oficial Derecho */}
        {showStamp && (
          <div className="absolute top-[898px] left-[135px] w-[170px] h-[85px] pointer-events-none flex items-center justify-center">
            <OfficialMedicalStamp inkColor="navy" size="md" />
          </div>
        )}
      </div>
    </div>
  );
};
