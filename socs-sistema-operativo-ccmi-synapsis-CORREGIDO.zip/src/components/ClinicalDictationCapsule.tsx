import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Mic, 
  Square, 
  Sparkles, 
  Loader2, 
  Volume2, 
  AlertCircle, 
  Check, 
  ChevronUp, 
  ChevronDown,
  X,
  RotateCcw,
  RefreshCw,
  Search,
  FileText
} from 'lucide-react';
import { 
  normalizeClinicalPhonetics, 
  cleanStutterAndEchoes, 
  formatClinicalSpeech, 
  mergeSpeechTranscripts 
} from '../utils/phoneticDictionary';
import { extractClinicalDataFromText, extractClinicalDataFromAudio } from '../api/workspaceEngine';
import { getPatientByCedula, savePatientRecord, getAllPatients, PatientRecord } from '../utils/patientStorage';

export type DictationCapsuleState = 
  | 'idle' 
  | 'recording' 
  | 'processing' 
  | 'success' 
  | 'partial' 
  | 'error' 
  | 'requiresReview';

interface Props {
  onSyncAllDocuments: (extractedData: any) => void;
  onProgressiveSync?: (partialData: any) => void;
  currentPatientCedula?: string;
  onSelectPatientFromHistory?: (patient: PatientRecord) => void;
  onResetConsultationState?: () => void;
}

export const ClinicalDictationCapsule: React.FC<Props> = ({
  onSyncAllDocuments,
  onProgressiveSync,
  currentPatientCedula,
  onSelectPatientFromHistory,
  onResetConsultationState,
}) => {
  const [capsuleState, setCapsuleState] = useState<DictationCapsuleState>('idle');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [transcript, setTranscript] = useState('');
  const [interimText, setInterimText] = useState('');
  const [isProcessingAI, setIsProcessingAI] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [savedPatients, setSavedPatients] = useState<PatientRecord[]>([]);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const recognitionRef = useRef<any>(null);
  const isRecordingRef = useRef<boolean>(false);
  const timerRef = useRef<any>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const isCancelledRef = useRef<boolean>(false);
  const lastRecordedBlobRef = useRef<Blob | null>(null);
  const lastRecordedTextRef = useRef<string>('');

  useEffect(() => {
    setSavedPatients(getAllPatients());
  }, []);

  // Progresivo sync de texto transcrito
  const debounceSyncRef = useRef<any>(null);
  useEffect(() => {
    if (!transcript || !onProgressiveSync || !isRecording) return;
    if (debounceSyncRef.current) clearTimeout(debounceSyncRef.current);
    debounceSyncRef.current = setTimeout(() => {
      // Notificar transcripción parcial segura sin inventar datos clínicos
      onProgressiveSync({ transcriptPreview: transcript });
    }, 600);
    return () => {
      if (debounceSyncRef.current) clearTimeout(debounceSyncRef.current);
    };
  }, [transcript, isRecording, onProgressiveSync]);

  const autoSyncAndSave = useCallback((data: any) => {
    if (!data || isCancelledRef.current) return;
    onSyncAllDocuments(data);

    const patientIdNum = data.patient?.idNumber || data.patient?.nationalId;
    if (patientIdNum) {
      try {
        const finalRxLeft = data.recipeDual?.pharmacy || data.recipe?.rxLeft || data.treatment || '';
        const finalRxRight = data.recipeDual?.patientIndications || data.recipe?.indicationsRight || data.indications || '';
        const patientFullName = data.patient?.fullName || data.patient?.patientName || '';
        const newRecord: PatientRecord = {
          id: `pt-${patientIdNum.replace(/[^\d]/g, '') || Date.now()}`,
          nationalId: patientIdNum,
          fullName: patientFullName,
          age: data.patient.age || '',
          phone: data.patient.phone || '',
          address: data.patient.address || '',
          lastConsultationDate: data.patient.date || new Date().toLocaleDateString('es-VE'),
          lastDiagnosis: data.constancia?.idx || data.informe?.diagnostico || data.diagnosisPrincipal || '',
          documentStates: {
            recipe: { rxLeft: finalRxLeft, indicationsRight: finalRxRight },
            informe: data.informe || { bodyText: data.clinicalReport || '' },
            ordenLab: data.ordenLab,
            constancia: data.constancia,
            historia: data.historia,
          },
          auditLog: [
            {
              timestamp: new Date().toLocaleString('es-VE'),
              action: 'Estructuración clínica asistida',
            },
          ],
        };
        savePatientRecord(newRecord);
        setSavedPatients(getAllPatients());
      } catch (saveErr) {
        console.warn('Error guardando paciente:', saveErr);
      }
    }
  }, [onSyncAllDocuments]);

  const processAudioOrTranscript = async (audioBlob: Blob | null, text: string) => {
    if (isCancelledRef.current) return;
    
    // Almacenar en refs para permitir reintento sin tener que volver a dictar
    if (audioBlob && audioBlob.size > 1000) {
      lastRecordedBlobRef.current = audioBlob;
    }
    if (text && text.trim().length > 0) {
      lastRecordedTextRef.current = text.trim();
    }

    setIsProcessingAI(true);
    setCapsuleState('processing');
    setStatusMessage('Estructurando consulta con IA...');
    try {
      const result = audioBlob && audioBlob.size > 1000
        ? await extractClinicalDataFromAudio(audioBlob)
        : await extractClinicalDataFromText(text);

      if (isCancelledRef.current) return;

      if (result.success && result.data) {
        autoSyncAndSave(result.data);
        if (result.requiresReview) {
          setCapsuleState('requiresReview');
          setStatusMessage('⚠️ Extracción completada. Por favor verifique los campos señalados.');
        } else {
          setCapsuleState('success');
          setStatusMessage('✓ Consulta estructurada y aplicada a los 5 documentos');
        }
      } else {
        setCapsuleState('error');
        setStatusMessage(`⚠️ ${result.error || 'Error al procesar consulta. Puede reintentar sin volver a dictar.'}`);
      }
    } catch (err: any) {
      if (isCancelledRef.current) return;
      console.error('Error en extracción de dictado:', err);
      setCapsuleState('error');
      setStatusMessage(`⚠️ Error de conexión: ${err.message || 'Intente nuevamente con el botón Reintentar'}`);
    } finally {
      setIsProcessingAI(false);
      setTimeout(() => {
        setStatusMessage(null);
        setCapsuleState((curr) => (curr === 'success' ? 'idle' : curr));
      }, 7000);
    }
  };

  const retryLastDictationProcessing = async () => {
    if (isProcessingAI || isRecording) return;
    const blobToRetry = lastRecordedBlobRef.current;
    const textToRetry = lastRecordedTextRef.current || transcript.trim();

    if (!blobToRetry && !textToRetry) {
      setStatusMessage('No hay dictado previo para reintentar');
      setTimeout(() => setStatusMessage(null), 3000);
      return;
    }

    isCancelledRef.current = false;
    setStatusMessage('Reintentando procesado con servidores de respaldo...');
    await processAudioOrTranscript(blobToRetry, textToRetry);
  };

  const cancelRecordingOrProcessing = () => {
    isCancelledRef.current = true;
    setIsRecording(false);
    isRecordingRef.current = false;
    setIsProcessingAI(false);
    setCapsuleState('idle');
    setAudioLevel(0);
    setTranscript('');
    setInterimText('');
    setStatusMessage('Dictado cancelado y descartado');
    setTimeout(() => setStatusMessage(null), 2500);

    if (timerRef.current) clearInterval(timerRef.current);
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);

    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch {}
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try { audioContextRef.current.close(); } catch {}
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try { mediaRecorderRef.current.stop(); } catch {}
    }
    audioChunksRef.current = [];
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
  };

  const startRecording = async () => {
    isCancelledRef.current = false;
    audioChunksRef.current = [];
    setTranscript('');
    setInterimText('');
    setStatusMessage(null);
    setCapsuleState('recording');

    let stream: MediaStream | null = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const audioCtx = new AudioCtx();
          audioContextRef.current = audioCtx;
          const source = audioCtx.createMediaStreamSource(stream);
          const analyser = audioCtx.createAnalyser();
          analyser.fftSize = 32;
          source.connect(analyser);
          analyserRef.current = analyser;

          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          const updateLevel = () => {
            if (!isRecordingRef.current) return;
            analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
            const avg = sum / dataArray.length;
            setAudioLevel(Math.min(100, Math.round((avg / 128) * 100)));
            animFrameRef.current = requestAnimationFrame(updateLevel);
          };
          animFrameRef.current = requestAnimationFrame(updateLevel);
        }
      } catch {}

      try {
        let mimeType = 'audio/webm';
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          mimeType = 'audio/mp4';
        }
        const recorder = new MediaRecorder(stream, { mimeType });
        mediaRecorderRef.current = recorder;
        recorder.ondataavailable = (event) => {
          if (event.data && event.data.size > 0) {
            audioChunksRef.current.push(event.data);
          }
        };
        recorder.start(250);
      } catch {}
    } catch (err) {
      console.error('Error micrófono:', err);
      setStatusMessage('Micrófono inactivo. Usa "Cargar Caso Demo" o permite el acceso.');
      setIsExpanded(true);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      try {
        const rec = new SpeechRecognition();
        rec.continuous = true;
        rec.interimResults = true;
        rec.lang = 'es-419';

        rec.onresult = (event: any) => {
          let interim = '';
          let finalChunk = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcriptPart = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalChunk += ' ' + transcriptPart;
            } else {
              interim += ' ' + transcriptPart;
            }
          }
          if (interim) {
            setInterimText(formatClinicalSpeech(cleanStutterAndEchoes(interim)));
          }
          if (finalChunk.trim()) {
            const formatted = formatClinicalSpeech(cleanStutterAndEchoes(finalChunk));
            setTranscript((prev) => {
              const merged = mergeSpeechTranscripts(prev, formatted);
              const result = normalizeClinicalPhonetics(merged);
              return result.normalizedText;
            });
            setInterimText('');
          }
        };

        rec.onerror = () => {};
        rec.onend = () => {
          if (isRecordingRef.current) {
            try { rec.start(); } catch {}
          }
        };
        recognitionRef.current = rec;
        rec.start();
      } catch {}
    }

    setIsRecording(true);
    isRecordingRef.current = true;
    setRecordingSeconds(0);
    setIsExpanded(true); // Automatically expand so doctor sees live transcription feedback
    setStatusMessage('🎙️ Escuchando dictado médico...');

    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setRecordingSeconds((sec) => sec + 1);
    }, 1000);
  };

  const stopRecording = async () => {
    setIsRecording(false);
    isRecordingRef.current = false;
    if (timerRef.current) clearInterval(timerRef.current);
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    setAudioLevel(0);

    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch {}
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try { audioContextRef.current.close(); } catch {}
    }

    let recordedBlob: Blob | null = null;
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        const mimeType = mediaRecorderRef.current.mimeType || 'audio/webm';
        await new Promise<void>((resolve) => {
          if (!mediaRecorderRef.current) return resolve();
          mediaRecorderRef.current.onstop = () => {
            recordedBlob = new Blob(audioChunksRef.current, { type: mimeType });
            resolve();
          };
          mediaRecorderRef.current.stop();
        });
      } catch {}
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }

    const currentText = transcript.trim();
    if (currentText.length > 5 || (recordedBlob && (recordedBlob as Blob).size > 1000)) {
      await processAudioOrTranscript(recordedBlob, currentText);
    } else {
      setStatusMessage('No se detectó audio');
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  const toggleRecording = () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  const loadDemoCase = () => {
    const demo = `Paciente masculino Luis Eduardo Morales, cédula 14.892.304, de 54 años, acude por lumbociatalgia izquierda severa irradiada a dermatoma L5-S1 de 3 semanas de evolución. Examen físico: Maniobra de Lasègue positiva a 35 grados en miembro inferior izquierdo con paresia 4 sobre 5 en extensor propio del hallux. Diagnóstico: Hernia discal lumbar extruida L5-S1 izquierda con radiculopatía aguda. Tratamiento: Pregabalina 75mg vía oral cada 12 horas por 14 días, Ketoprofeno 100mg cada 8 horas por 5 días con protector gástrico, y Tramadol con Paracetamol 37.5/325mg cada 8 horas si hay dolor intenso. Indicaciones: Reposo en cama semi-fowler, evitar flexión de tronco y cargas de peso. Solicito Resonancia Magnética de columna lumbosacra con contraste y Perfil preoperatorio completo. Se otorga constancia de reposo médico por 10 días a partir de hoy.`;
    setTranscript(demo);
    processAudioOrTranscript(null, demo);
  };

  const handleSelectPatient = (p: PatientRecord) => {
    if (onSelectPatientFromHistory) {
      onSelectPatientFromHistory(p);
      setShowSearchModal(false);
      setStatusMessage(`Ficha de ${p.fullName} cargada`);
      setTimeout(() => setStatusMessage(null), 3500);
    }
  };

  const filteredPatients = savedPatients.filter((p) =>
    p.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.nationalId.includes(searchQuery)
  );

  return (
    <>
      {/* Floating Dynamic Clinical Capsule */}
      <aside 
        aria-label="Cápsula de Dictado Clínico"
        className="fixed bottom-6 right-8 z-50 flex flex-col items-end gap-2 print:hidden font-sans select-none"
      >
        {/* Real-time transcript popover if expanded during/after recording */}
        {isExpanded && (
          <div className="w-80 sm:w-96 bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200/80 p-4 shadow-xl text-slate-800 text-xs space-y-3 animate-fade-in">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                Transcripción Clínica en Vivo
              </span>
              <button
                type="button"
                onClick={() => setIsExpanded(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            
            <div className="max-h-40 overflow-y-auto font-sans leading-relaxed text-slate-700 space-y-1">
              <p>{transcript || interimText || <span className="text-slate-400 italic">Hable al micrófono con naturalidad para dictar la consulta...</span>}</p>
              {interimText && <span className="text-blue-500 italic"> {interimText}</span>}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px]">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={loadDemoCase}
                  className="text-blue-600 hover:text-blue-800 font-medium cursor-pointer"
                >
                  Cargar Caso Demo
                </button>
                {/* Botón de reintento directo desde panel expandido */}
                {!isRecording && !isProcessingAI && (lastRecordedBlobRef.current || lastRecordedTextRef.current || transcript) && (
                  <button
                    type="button"
                    onClick={retryLastDictationProcessing}
                    className="text-emerald-700 hover:text-emerald-900 font-bold cursor-pointer flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200"
                    title="Reintentar estructuración con IA sin volver a dictar"
                  >
                    <RefreshCw className="w-3 h-3" />
                    Reintentar Procesado
                  </button>
                )}
                {(transcript || isRecording || isProcessingAI) && (
                  <button
                    type="button"
                    onClick={cancelRecordingOrProcessing}
                    className="text-rose-600 hover:text-rose-800 font-medium cursor-pointer flex items-center gap-0.5"
                    title="Descartar audio y transcripción actual"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Limpiar
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => setShowSearchModal(true)}
                className="text-slate-500 hover:text-slate-800 font-medium cursor-pointer flex items-center gap-1"
              >
                <Search className="w-3 h-3" />
                Historial ({savedPatients.length})
              </button>
            </div>
          </div>
        )}

        {/* Status Notification Toast above capsule with quick Retry button if in error */}
        {statusMessage && (
          <div className={`text-white text-[11px] font-medium px-3.5 py-1.5 rounded-full shadow-lg border flex items-center gap-2 animate-fade-in ${
            capsuleState === 'error' 
              ? 'bg-rose-900/95 border-rose-700/80 shadow-rose-950/40' 
              : capsuleState === 'requiresReview' 
              ? 'bg-amber-900/90 border-amber-700/60 text-amber-200' 
              : 'bg-slate-900/90 border-slate-700/60'
          }`}>
            {capsuleState === 'error' ? (
              <AlertCircle className="w-3.5 h-3.5 text-rose-300 shrink-0" />
            ) : capsuleState === 'requiresReview' ? (
              <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            ) : (
              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            )}
            <span className="truncate max-w-[280px] sm:max-w-xs">{statusMessage}</span>
            {capsuleState === 'error' && !isProcessingAI && !isRecording && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  retryLastDictationProcessing();
                }}
                className="ml-1 bg-white text-rose-900 hover:bg-rose-100 font-bold px-2 py-0.5 rounded-full text-[10px] flex items-center gap-1 cursor-pointer transition shadow-xs"
                title="Reintentar procesamiento con servidores de respaldo"
              >
                <RefreshCw className="w-2.5 h-2.5" />
                Reintentar
              </button>
            )}
          </div>
        )}

        {/* Primary Interactive Capsule Pill */}
        <div 
          onClick={(e) => {
            // Prevent duplicate clicks if clicked directly on buttons
            if ((e.target as HTMLElement).closest('button')) return;
            toggleRecording();
          }}
          className={`flex items-center bg-white/95 backdrop-blur-xl border rounded-full shadow-lg hover:shadow-2xl transition-all duration-200 p-1.5 pl-4 gap-3 text-xs cursor-pointer group ring-1 ring-slate-900/5 ${
            isRecording 
              ? 'border-rose-400 ring-rose-400/30 bg-rose-50/90' 
              : capsuleState === 'requiresReview'
              ? 'border-amber-400 ring-amber-400/30 bg-amber-50/90'
              : capsuleState === 'error'
              ? 'border-rose-400 ring-rose-400/20 bg-rose-50/60'
              : 'border-slate-200/90 hover:border-blue-400'
          }`}
        >
          {/* Status Indicator & Timer */}
          {isRecording ? (
            <div className="flex items-center gap-2">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
              </span>
              <span className="font-mono font-bold text-rose-600 text-xs">
                GRABANDO {String(Math.floor(recordingSeconds / 60)).padStart(2, '0')}:
                {String(recordingSeconds % 60).padStart(2, '0')}
              </span>
              {/* VU indicator bars */}
              <div className="flex items-center gap-0.5 h-3.5">
                {[20, 45, 75, 50, 30].map((h, i) => (
                  <div
                    key={i}
                    className="w-0.5 bg-rose-500 rounded-full transition-all duration-75"
                    style={{ height: `${Math.max(3, Math.min(14, (audioLevel / 100) * h))}px` }}
                  />
                ))}
              </div>
            </div>
          ) : isProcessingAI ? (
            <div className="flex items-center gap-2 text-slate-700 font-medium">
              <Loader2 className="w-3.5 h-3.5 text-blue-600 animate-spin" />
              <span className="font-semibold text-blue-700">Estructurando con IA...</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-slate-700 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="font-bold text-slate-900 group-hover:text-blue-700 transition-colors">Dictar Consulta</span>
              <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">(Voz IA)</span>
            </div>
          )}

          {/* Quick Retry Button directly in pill if there is an error or a previous recorded audio */}
          {capsuleState === 'error' && !isRecording && !isProcessingAI && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                retryLastDictationProcessing();
              }}
              className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold rounded-full transition cursor-pointer flex items-center gap-1 shadow-xs animate-bounce"
              title="Reintentar procesado de la consulta dictada sin volver a hablar"
            >
              <RefreshCw className="w-3 h-3" />
              Reintentar
            </button>
          )}

          {/* Cancel button during recording / processing */}
          {(isRecording || isProcessingAI) && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                cancelRecordingOrProcessing();
              }}
              className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-100 rounded-full transition cursor-pointer"
              title="Cancelar y descartar grabación"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Quick Demo Case Button right in capsule for instant testing */}
          {!isRecording && !isProcessingAI && capsuleState !== 'error' && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                loadDemoCase();
              }}
              className="px-2 py-0.5 bg-blue-50 hover:bg-blue-100 text-blue-700 text-[10px] font-bold rounded-full border border-blue-200 transition cursor-pointer hidden sm:block"
              title="Probar autollenado con caso clínico de prueba (Hernia Discal)"
            >
              Probar Demo
            </button>
          )}

          {/* Quick Expand Toggle */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsExpanded(!isExpanded);
            }}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition cursor-pointer"
            title={isExpanded ? 'Ocultar transcripción' : 'Ver transcripción en vivo'}
          >
            {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
          </button>

          {/* Main Action Record/Stop Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              toggleRecording();
            }}
            disabled={isProcessingAI}
            className={`flex items-center justify-center w-8 h-8 rounded-full transition-all duration-200 shadow-sm cursor-pointer disabled:opacity-50 ${
              isRecording
                ? 'bg-rose-500 hover:bg-rose-600 text-white animate-pulse'
                : 'bg-[#0a376d] hover:bg-[#082b54] text-white hover:scale-105'
            }`}
            title={isRecording ? 'Detener y estructurar consulta' : 'Iniciar dictado de voz médico'}
          >
            {isRecording ? <Square className="w-3.5 h-3.5 fill-current" /> : <Mic className="w-4 h-4" />}
          </button>
        </div>
      </aside>

      {/* Modal: Patient History Search */}
      {showSearchModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in font-sans">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-md p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-blue-600" />
                <h3 className="text-sm font-bold text-slate-900">Buscar Ficha de Paciente</h3>
              </div>
              <button
                onClick={() => setShowSearchModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <input
              type="text"
              placeholder="Buscar por nombre o cédula..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
              autoFocus
            />

            <div className="max-h-60 overflow-y-auto space-y-1 divide-y divide-slate-100">
              {filteredPatients.length === 0 ? (
                <p className="text-xs text-slate-400 py-4 text-center">No se encontraron pacientes registrados.</p>
              ) : (
                filteredPatients.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handleSelectPatient(p)}
                    className="w-full text-left py-2.5 px-2 rounded-lg hover:bg-slate-50 flex items-center justify-between group transition cursor-pointer"
                  >
                    <div>
                      <p className="text-xs font-semibold text-slate-800 group-hover:text-blue-700">{p.fullName}</p>
                      <p className="text-[11px] text-slate-400 font-mono">C.I: {p.nationalId} • {p.lastConsultationDate}</p>
                    </div>
                    <FileText className="w-3.5 h-3.5 text-slate-300 group-hover:text-blue-600" />
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
