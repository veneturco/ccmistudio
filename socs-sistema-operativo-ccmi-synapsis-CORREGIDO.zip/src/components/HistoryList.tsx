import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Printer, 
  ExternalLink, 
  Calendar, 
  User, 
  Clock, 
  CheckCircle2,
  FileCheck2,
  Filter
} from 'lucide-react';
import { ProcessedDocumentResult, DocumentType } from '../types';
import { DocumentPreviewModal } from './DocumentPreviewModal';
import { BrandLogo } from './BrandLogo';

interface Props {
  documents: ProcessedDocumentResult[];
}

export const HistoryList: React.FC<Props> = ({ documents }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [selectedDoc, setSelectedDoc] = useState<ProcessedDocumentResult | null>(null);

  const getDocTypeBadge = (type: DocumentType) => {
    switch (type) {
      case 'recipe':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">Récipe Médico</span>;
      case 'report':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">Informe Médico</span>;
      case 'lab_order':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">Orden Lab / Rx</span>;
      case 'certificate':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">Constancia</span>;
    }
  };

  const filteredDocs = documents.filter((doc) => {
    const matchesSearch =
      doc.patient.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.patient.nationalId.includes(searchTerm) ||
      doc.docNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.structuredData.diagnosisPrincipal.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType = filterType === 'all' || doc.documentType === filterType;

    return matchesSearch && matchesType;
  });

  return (
    <div id="history-list-module" className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-200 p-1 flex items-center justify-center shrink-0 shadow-xs">
            <BrandLogo size={40} />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              Historial de Emisiones Clínicas CcMi
              <span className="px-2 py-0.5 text-[11px] font-semibold bg-slate-100 text-slate-700 rounded-full border border-slate-200 font-mono">
                {documents.length} registros
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              Registro cronológico de papelería médica generada e inyectada en Google Docs para el Dr. Samir Moucharrafie.
            </p>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar paciente, cédula o diagnóstico..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            />
          </div>

          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            aria-label="Filtrar por tipo de documento"
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20"
          >
            <option value="all">Todos los Tipos</option>
            <option value="recipe">Récipes</option>
            <option value="report">Informes</option>
            <option value="lab_order">Órdenes Lab</option>
            <option value="certificate">Constancias</option>
          </select>
        </div>
      </div>

      {/* Document Records */}
      {filteredDocs.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center">
          <FileText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-700">No se encontraron documentos</h3>
          <p className="text-xs text-slate-400 mt-1">
            Los documentos generados desde la pestaña "Nueva Emisión" aparecerán archivados aquí.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredDocs.map((doc) => (
            <div
              key={doc.id}
              className="bg-white border border-slate-200 hover:border-blue-300 rounded-2xl p-4 sm:p-5 shadow-sm hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center gap-2.5 flex-wrap">
                  {getDocTypeBadge(doc.documentType)}
                  <span className="font-mono text-xs font-bold text-slate-700">{doc.docNumber}</span>
                  <span className="text-slate-300">•</span>
                  <span className="text-xs text-slate-500 flex items-center gap-1 font-mono">
                    <Calendar className="w-3 h-3" />
                    {doc.generatedAt}
                  </span>
                </div>

                <div className="flex items-baseline gap-2">
                  <h3 className="text-sm font-bold text-slate-900">{doc.patient.fullName}</h3>
                  <span className="text-xs text-slate-500 font-mono">
                    ({doc.patient.idType}-{doc.patient.nationalId})
                  </span>
                </div>

                <p className="text-xs text-slate-600 line-clamp-1">
                  <strong className="text-slate-700">Dx:</strong> {doc.structuredData.diagnosisPrincipal}
                  {doc.structuredData.medications.length > 0 && (
                    <span className="text-slate-400 font-mono text-[11px] ml-2">
                      ({doc.structuredData.medications.length} fármacos indicados)
                    </span>
                  )}
                </p>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                <button
                  type="button"
                  onClick={() => setSelectedDoc(doc)}
                  className="px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                >
                  <FileCheck2 className="w-3.5 h-3.5" />
                  <span>Ver Papelería</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSelectedDoc(doc);
                    setTimeout(() => window.print(), 200);
                  }}
                  className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition cursor-pointer"
                  title="Reimprimir directo"
                >
                  <Printer className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Document Paper Preview Modal */}
      <DocumentPreviewModal
        document={selectedDoc}
        isOpen={!!selectedDoc}
        onClose={() => setSelectedDoc(null)}
      />
    </div>
  );
};
