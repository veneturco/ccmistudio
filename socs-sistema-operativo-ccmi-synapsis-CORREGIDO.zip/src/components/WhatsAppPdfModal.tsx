import React, { useState } from 'react';
import {
  X,
  Share2,
  Download,
  FileCheck,
  CheckCircle2,
  AlertCircle,
  Phone,
  Layers,
  Sparkles,
  Loader2,
  ExternalLink,
} from 'lucide-react';
import { DocType, PatientData } from '../types';
import {
  DOCUMENT_DEFINITIONS,
  generateCanonicalDocumentPDF,
  ClinicalDataBundle,
  sharePdfToWhatsApp,
  buildWhatsAppMessage,
  formatWhatsAppPhone,
  sanitizeFileName,
} from '../utils/pdfExport';

interface WhatsAppPdfModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeDoc: DocType;
  patient: PatientData;
  setActiveDoc?: (doc: DocType) => void;
  clinicalDataBundle?: ClinicalDataBundle;
}

export const WhatsAppPdfModal: React.FC<WhatsAppPdfModalProps> = ({
  isOpen,
  onClose,
  activeDoc,
  patient,
  setActiveDoc,
  clinicalDataBundle,
}) => {
  const [phoneNumber, setPhoneNumber] = useState(patient.phone || '0424-912.44.81');
  const [selectedDocs, setSelectedDocs] = useState<Record<DocType, boolean>>({
    RECIPES: activeDoc === 'RECIPES',
    INFORME: activeDoc === 'INFORME',
    ORDEN_LAB: activeDoc === 'ORDEN_LAB',
    CONSTANCIA: activeDoc === 'CONSTANCIA',
    HISTORIA: activeDoc === 'HISTORIA',
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [processStatus, setProcessStatus] = useState<string>('');
  const [completedNotification, setCompletedNotification] = useState<{
    method: 'native-share' | 'download-and-whatsapp';
    count: number;
    hasReviewNotice?: boolean;
  } | null>(null);

  if (!isOpen) return null;

  const docKeys = Object.keys(DOCUMENT_DEFINITIONS) as DocType[];
  const selectedCount = Object.values(selectedDocs).filter(Boolean).length;

  const handleToggleDoc = (key: DocType) => {
    setSelectedDocs((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleSelectAll = (select: boolean) => {
    const updated: Record<DocType, boolean> = {
      RECIPES: select,
      INFORME: select,
      ORDEN_LAB: select,
      CONSTANCIA: select,
      HISTORIA: select,
    };
    setSelectedDocs(updated);
  };

  const handleGenerateAndSend = async (actionType: 'whatsapp' | 'download-only') => {
    if (selectedCount === 0) {
      alert('Por favor seleccione al menos un documento para generar el PDF.');
      return;
    }

    setIsProcessing(true);
    setCompletedNotification(null);
    const generatedFiles: { file: File; name: string }[] = [];
    const patientSafeName = sanitizeFileName(patient.fullName || 'Paciente');
    let anyRequiresReview = false;

    try {
      // Iterar por cada documento seleccionado usando el generador canónico oficial (PDF original + overlay vectorial)
      for (let i = 0; i < docKeys.length; i++) {
        const docKey = docKeys[i];
        if (!selectedDocs[docKey]) continue;

        const def = DOCUMENT_DEFINITIONS[docKey];
        setProcessStatus(`Generando PDF oficial de ${def.shortName} sobre plantilla base...`);

        const fileName = `${def.filenamePrefix}_${patientSafeName}.pdf`;

        // GENERACIÓN CANÓNICA ÚNICA: PDF ORIGINAL + OVERLAY VECTORIAL (Cero rasterización / Cero html2canvas)
        const result = await generateCanonicalDocumentPDF(
          docKey,
          patient,
          clinicalDataBundle || {},
          fileName
        );

        if (result.requiresReview) {
          anyRequiresReview = true;
        }

        generatedFiles.push({ file: result.file, name: def.shortName });

        if (actionType === 'download-only') {
          // Descarga directa del archivo PDF oficial generado vectorialmente
          const url = URL.createObjectURL(result.file);
          const a = document.createElement('a');
          a.href = url;
          a.download = fileName;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          setTimeout(() => URL.revokeObjectURL(url), 10000);
          await new Promise((r) => setTimeout(r, 200));
        }
      }

      if (actionType === 'download-only') {
        setIsProcessing(false);
        setProcessStatus('');
        setCompletedNotification({
          method: 'download-and-whatsapp',
          count: generatedFiles.length,
          hasReviewNotice: anyRequiresReview,
        });
        return;
      }

      // Enviar por WhatsApp
      setProcessStatus('Preparando envío por WhatsApp...');

      const docNames = generatedFiles.map((f) => f.name);
      const whatsappMsg = buildWhatsAppMessage(
        docNames,
        patient.fullName,
        patient.idNumber,
        patient.date
      );

      // Si hay un solo archivo, enviamos el archivo directamente con Web Share API
      // Si hay varios, descargamos los PDFs y abrimos WhatsApp con el mensaje estructurado
      if (generatedFiles.length === 1) {
        const result = await sharePdfToWhatsApp({
          file: generatedFiles[0].file,
          fileName: generatedFiles[0].file.name,
          phoneNumber: phoneNumber,
          messageText: whatsappMsg,
        });

        setCompletedNotification({
          method: result.method,
          count: 1,
          hasReviewNotice: anyRequiresReview,
        });
      } else {
        // Multi-documento: Descargar cada uno y abrir WhatsApp
        for (const item of generatedFiles) {
          const url = URL.createObjectURL(item.file);
          const a = document.createElement('a');
          a.href = url;
          a.download = item.file.name;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          setTimeout(() => URL.revokeObjectURL(url), 10000);
          await new Promise((r) => setTimeout(r, 200));
        }

        const cleanPhone = formatWhatsAppPhone(phoneNumber);
        const encodedMsg = encodeURIComponent(whatsappMsg);
        const waUrl = cleanPhone
          ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedMsg}`
          : `https://api.whatsapp.com/send?text=${encodedMsg}`;

        window.open(waUrl, '_blank');

        setCompletedNotification({
          method: 'download-and-whatsapp',
          count: generatedFiles.length,
          hasReviewNotice: anyRequiresReview,
        });
      }
    } catch (err: any) {
      console.error('Error generando/enviando PDF oficial:', err);
      alert(`Error al generar el PDF oficial: ${err.message || 'Error inesperado'}`);
    } finally {
      setIsProcessing(false);
      setProcessStatus('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header Modal */}
        <div className="p-5 border-b border-slate-800 bg-gradient-to-r from-emerald-950/40 via-slate-900 to-blue-950/40 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                Enviar Documentos en PDF por WhatsApp
              </h2>
              <p className="text-xs text-slate-400">
                Instituto CcMi • Dr. Samir Moucharrafie Naime
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={isProcessing}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* Ficha Paciente y Teléfono */}
          <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-300 text-[11px] uppercase tracking-wider">
                Datos del Destinatario
              </span>
              <span className="text-[10px] text-emerald-400 font-mono bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-800/40">
                WhatsApp Directo
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Paciente:</label>
                <div className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 font-bold text-slate-200">
                  {patient.fullName || 'Paciente sin nombre'}
                </div>
              </div>
              <div>
                <label className="text-[10px] text-slate-400 block mb-1 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-emerald-400" />
                  <span>Número de WhatsApp:</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="0424-9124481 o +584249124481"
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-emerald-500/40 text-emerald-300 font-bold outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Selector de los 5 Documentos Oficiales */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-300 text-[11px] uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-blue-400" />
                <span>Documentos Oficiales a Exportar (PDF)</span>
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSelectAll(true)}
                  className="text-[10px] text-blue-400 hover:text-blue-300 underline cursor-pointer"
                >
                  Seleccionar los 5
                </button>
                <span className="text-slate-600">•</span>
                <button
                  type="button"
                  onClick={() => handleSelectAll(false)}
                  className="text-[10px] text-slate-400 hover:text-slate-300 underline cursor-pointer"
                >
                  Desmarcar
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-2">
              {docKeys.map((key) => {
                const def = DOCUMENT_DEFINITIONS[key];
                const isSelected = selectedDocs[key];
                const isCurrentlyActive = activeDoc === key;

                return (
                  <label
                    key={key}
                    className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-blue-950/30 border-blue-500/50 text-white shadow-sm'
                        : 'bg-slate-800/40 border-slate-700/60 text-slate-400 hover:bg-slate-800/70'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleToggleDoc(key)}
                        className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-600 bg-slate-700"
                      />
                      <div>
                        <div className="font-bold text-slate-200 text-xs flex items-center gap-1.5">
                          <span>{def.label}</span>
                          {isCurrentlyActive && (
                            <span className="text-[9px] px-1.5 py-0.2 bg-blue-500/20 text-blue-300 border border-blue-400/30 rounded-md font-mono">
                              En pantalla
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400">
                          Formato A4 oficial • Sello y Firma • Código QR
                        </span>
                      </div>
                    </div>
                    <FileCheck
                      className={`w-4 h-4 ${isSelected ? 'text-blue-400' : 'text-slate-600'}`}
                    />
                  </label>
                );
              })}
            </div>
          </div>

          {/* Notificación de Éxito / Instrucción de Envío */}
          {completedNotification && (
            <div className="p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/60 text-emerald-200 space-y-1 animate-fade-in">
              <div className="flex items-center gap-2 font-bold text-emerald-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  ¡{completedNotification.count}{' '}
                  {completedNotification.count === 1 ? 'documento PDF generado' : 'documentos PDF generados'} con éxito!
                </span>
              </div>
              <p className="text-[11px] text-emerald-200/90 pl-6">
                {completedNotification.method === 'native-share'
                  ? 'Se activó el menú oficial de WhatsApp para enviar el archivo adjunto directamente al paciente.'
                  : 'El archivo PDF se ha descargado en su dispositivo y se ha abierto el chat de WhatsApp con el paciente para adjuntarlo con un solo clic.'}
              </p>
              {completedNotification.hasReviewNotice && (
                <div className="mt-2 p-2 rounded-xl bg-amber-950/70 border border-amber-500/50 text-amber-200 text-[11px] flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Aviso médico: Uno o más textos clínicos extensos requirieron ajuste shrink-to-fit y se sugiere revisión médica antes de su entrega.</span>
                </div>
              )}
            </div>
          )}

          {/* Mensaje de progreso */}
          {isProcessing && (
            <div className="p-3 rounded-2xl bg-blue-950/60 border border-blue-500/50 text-blue-200 flex items-center gap-3">
              <Loader2 className="w-5 h-5 text-blue-400 animate-spin shrink-0" />
              <div>
                <p className="font-bold text-xs">{processStatus || 'Procesando PDFs...'}</p>
                <p className="text-[10px] text-blue-300/80">
                  Renderizando vectorialmente con resolución de imprenta (300 DPI)...
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/80 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => handleGenerateAndSend('download-only')}
            disabled={isProcessing || selectedCount === 0}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer disabled:opacity-50"
            title="Solo descargar los archivos PDF en el dispositivo sin abrir WhatsApp"
          >
            <Download className="w-4 h-4" />
            <span>Descargar PDF ({selectedCount})</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isProcessing}
              className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white text-xs font-bold transition cursor-pointer"
            >
              Cerrar
            </button>
            <button
              type="button"
              onClick={() => handleGenerateAndSend('whatsapp')}
              disabled={isProcessing || selectedCount === 0}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs shadow-lg shadow-emerald-950/60 transition cursor-pointer disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Procesando...</span>
                </>
              ) : (
                <>
                  <Share2 className="w-4 h-4" />
                  <span>Enviar por WhatsApp en PDF ({selectedCount})</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
