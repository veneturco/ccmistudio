import React, { useState, useRef, useEffect } from 'react';
import { FieldCalibration } from '../types/calibration';
import { 
  Save, 
  RotateCcw, 
  X, 
  Move, 
  Type, 
  Maximize2, 
  ZoomIn, 
  ZoomOut, 
  Check, 
  CheckCircle2, 
  Image as ImageIcon,
  Sliders,
  Upload,
  Layers,
  Eye,
  EyeOff,
  Sparkles,
  Pill,
  FileText,
  FlaskConical,
  CalendarCheck,
  ClipboardList
} from 'lucide-react';
import { saveStoredCalibration, getStoredCalibration, resetStoredCalibration } from '../utils/calibrationStorage';
import { getOfficialTemplateUrl, EMBEDDED_TEMPLATES, LAB_P1_TEMPLATE, LAB_P2_TEMPLATE } from '../assets/embeddedTemplates';
import { DocType } from '../types';
import { DOCUMENT_DEFINITIONS } from '../utils/pdfExport';
import { getCustomTemplate, saveCustomTemplate, deleteCustomTemplate } from '../utils/templateStorage';

export interface VisualTemplateEditorProps {
  docType: string;
  bgImageUrl?: string;
  initialFields: Record<string, FieldCalibration>;
  onClose: () => void;
  onSaved: () => void;
}

const DOC_PRESETS: { id: DocType; label: string; sub: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'RECIPES', label: 'Récipe Médico', sub: 'Doble Talón', icon: Pill },
  { id: 'INFORME', label: 'Informe Médico', sub: 'Neurocirugía', icon: FileText },
  { id: 'ORDEN_LAB', label: 'Orden de Laboratorio', sub: 'Página 1', icon: FlaskConical },
  { id: 'CONSTANCIA', label: 'Constancia Médica', sub: 'Reposo', icon: CalendarCheck },
  { id: 'HISTORIA', label: 'Historia Clínica', sub: 'Especializada', icon: ClipboardList },
];

export const VisualTemplateEditor: React.FC<VisualTemplateEditorProps> = ({
  docType: initialDocType,
  bgImageUrl: initialBgUrl,
  initialFields,
  onClose,
  onSaved,
}) => {
  const [currentDocType, setCurrentDocType] = useState<DocType>((initialDocType as DocType) || 'RECIPES');
  const [labPage, setLabPage] = useState<'p1' | 'p2'>('p1');
  const [fields, setFields] = useState<Record<string, FieldCalibration>>(() => {
    if (initialFields && Object.keys(initialFields).length > 0) {
      return initialFields;
    }
    return getStoredCalibration((initialDocType as DocType) || 'RECIPES') || {};
  });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [zoom, setZoom] = useState<number>(0.82);
  const [bgOpacity, setBgOpacity] = useState<number>(100);
  const [bgContrast, setBgContrast] = useState<'normal' | 'high'>('normal');
  const [customBg, setCustomBg] = useState<string | null>(initialBgUrl || null);

  const containerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const draggingRef = useRef<{ id: string; startX: number; startY: number; initialTop: number; initialLeft: number } | null>(null);

  // Compute effective background image URL
  const getEffectiveBgUrl = (): string => {
    if (customBg) return customBg;
    if (currentDocType === 'ORDEN_LAB') {
      return labPage === 'p2' ? LAB_P2_TEMPLATE : LAB_P1_TEMPLATE;
    }
    return getOfficialTemplateUrl(currentDocType);
  };

  const effectiveBgUrl = getEffectiveBgUrl();

  // Load custom template and fields when switching document tab
  useEffect(() => {
    let isMounted = true;
    getCustomTemplate(currentDocType).then((stored) => {
      if (isMounted && stored) {
        setCustomBg(stored);
      }
    });
    return () => { isMounted = false; };
  }, [currentDocType]);

  const handleSwitchDoc = async (newDoc: DocType) => {
    if (newDoc === currentDocType) return;
    setCurrentDocType(newDoc);
    const custom = await getCustomTemplate(newDoc);
    setCustomBg(custom || null);
    setSelectedId(null);
    const loaded = getStoredCalibration(newDoc) || {};
    setFields(loaded);
  };

  const selectedField = (selectedId && fields && fields[selectedId]) ? fields[selectedId] : null;

  // Manejo de inicio de arrastre con mouse o toque
  const handleMouseDown = (e: React.MouseEvent | React.TouchEvent, id: string) => {
    e.stopPropagation();
    if (!id || !fields || !fields[id]) return;
    setSelectedId(id);

    let clientX = 0;
    let clientY = 0;
    if ('touches' in e) {
      if (!e.touches || e.touches.length === 0) return;
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    draggingRef.current = {
      id,
      startX: clientX,
      startY: clientY,
      initialTop: fields[id]?.top || 0,
      initialLeft: fields[id]?.left || 0,
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('touchmove', handleTouchMove);
    window.addEventListener('touchend', handleTouchEnd);
  };

  const handleMouseMove = (e: MouseEvent) => {
    const drag = draggingRef.current;
    if (!drag) return;
    const targetId = drag.id;
    if (!targetId) return;

    const dx = (e.clientX - drag.startX) / zoom;
    const dy = (e.clientY - drag.startY) / zoom;

    const newTop = Math.max(0, Math.min(1123, drag.initialTop + dy));
    const newLeft = Math.max(0, Math.min(794, drag.initialLeft + dx));

    setFields(prev => {
      if (!prev || !prev[targetId]) return prev;
      return {
        ...prev,
        [targetId]: {
          ...prev[targetId],
          top: Math.round(newTop),
          left: Math.round(newLeft),
        },
      };
    });
  };

  const handleTouchMove = (e: TouchEvent) => {
    const drag = draggingRef.current;
    if (!drag || !e.touches || !e.touches[0]) return;
    const targetId = drag.id;
    if (!targetId) return;

    const dx = (e.touches[0].clientX - drag.startX) / zoom;
    const dy = (e.touches[0].clientY - drag.startY) / zoom;

    const newTop = Math.max(0, Math.min(1123, drag.initialTop + dy));
    const newLeft = Math.max(0, Math.min(794, drag.initialLeft + dx));

    setFields(prev => {
      if (!prev || !prev[targetId]) return prev;
      return {
        ...prev,
        [targetId]: {
          ...prev[targetId],
          top: Math.round(newTop),
          left: Math.round(newLeft),
        },
      };
    });
  };

  const handleMouseUp = () => {
    draggingRef.current = null;
    window.removeEventListener('mousemove', handleMouseMove);
    window.removeEventListener('mouseup', handleMouseUp);
  };

  const handleTouchEnd = () => {
    draggingRef.current = null;
    window.removeEventListener('touchmove', handleTouchMove);
    window.removeEventListener('touchend', handleTouchEnd);
  };

  // Cleanup listeners on unmount
  useEffect(() => {
    return () => {
      draggingRef.current = null;
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, []);

  // Subir imagen personalizada escaneada
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setCustomBg(dataUrl);
        await saveCustomTemplate(currentDocType, dataUrl);
        window.dispatchEvent(new CustomEvent('cmi-template-updated'));
        setStatusMsg('Papelería escaneada cargada y guardada como fondo de referencia.');
        setTimeout(() => setStatusMsg(null), 3000);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Actualizar propiedades del campo seleccionado desde el panel lateral
  const updateSelectedFieldProperty = (prop: keyof FieldCalibration, value: any) => {
    if (!selectedId) return;
    setFields(prev => ({
      ...prev,
      [selectedId]: {
        ...prev[selectedId],
        [prop]: value,
      },
    }));
  };

  // Restablecer a fábrica
  const handleResetFactory = () => {
    if (window.confirm(`¿Restablecer las posiciones de ${DOCUMENT_DEFINITIONS[currentDocType]?.shortName || currentDocType} a los valores de fábrica?`)) {
      const reset = resetStoredCalibration(currentDocType);
      setFields(reset);
      setSelectedId(null);
      setStatusMsg('Plantilla restablecida a coordenadas originales de fábrica.');
      setTimeout(() => setStatusMsg(null), 2500);
    }
  };

  // Guardar en el servidor (persistencia real en calibrations.json) y en localStorage
  const handleSaveToBackend = async () => {
    setIsSaving(true);
    try {
      // 1. Guardar localmente
      saveStoredCalibration(currentDocType, fields);

      // 2. Disparar evento global para actualización instantánea en la interfaz
      window.dispatchEvent(new CustomEvent('cmi-calibration-updated', {
        detail: { docType: currentDocType, calibration: fields }
      }));

      // 3. Guardar en el backend /api/calibrations
      const response = await fetch('/api/calibrations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ docType: currentDocType, calibration: fields }),
      });
      const json = await response.json();
      if (json.success) {
        setStatusMsg('¡Calibración guardada con éxito en el servidor!');
        setTimeout(() => {
          setStatusMsg(null);
          onSaved();
        }, 1200);
      } else {
        setStatusMsg('Guardado localmente. (Aviso: ' + (json.error || 'Servidor sincronizado') + ')');
        setTimeout(() => {
          setStatusMsg(null);
          onSaved();
        }, 1200);
      }
    } catch (err: any) {
      setStatusMsg('¡Guardado localmente con éxito!');
      setTimeout(() => {
        setStatusMsg(null);
        onSaved();
      }, 1200);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div id="visual-template-editor-modal" className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-start overflow-y-auto p-2 sm:p-4 font-sans animate-fade-in">
      
      {/* 1. BARRA SUPERIOR DE HERRAMIENTAS Y PESTAÑAS DE PLANTILLAS */}
      <div className="w-full max-w-6xl bg-slate-900 border border-slate-700 rounded-2xl p-3 mb-3 text-white flex flex-col gap-3 shadow-2xl shrink-0">
        
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
              <Move className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">Editor Visual de Plantillas Médicas</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-700">
                  {DOCUMENT_DEFINITIONS[currentDocType]?.shortName || currentDocType}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Visualizando el fondo escaneado original a 300 DPI. Arrastre las cajas para alineación exacta.
              </p>
            </div>
          </div>

          {statusMsg && (
            <div className="text-xs font-bold text-emerald-300 bg-emerald-950/90 px-3 py-1.5 rounded-lg border border-emerald-600 flex items-center gap-1.5 shadow-md animate-pulse">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{statusMsg}</span>
            </div>
          )}

          {/* Acciones principales: Guardar, Restablecer, Cerrar */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleResetFactory}
              className="p-2 bg-slate-800 hover:bg-amber-950 hover:text-amber-300 text-slate-300 rounded-xl transition cursor-pointer border border-slate-700"
              title="Restablecer coordenadas originales de fábrica"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleSaveToBackend}
              disabled={isSaving}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition cursor-pointer shadow-lg shadow-emerald-600/30 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Guardando...' : 'Guardar Cambios'}</span>
            </button>
            
            <button
              type="button"
              onClick={onClose}
              className="p-2 bg-slate-800 hover:bg-red-900 text-slate-300 hover:text-white rounded-xl transition cursor-pointer border border-slate-700"
              title="Cerrar Editor"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Selector de Plantilla Activa (5 Documentos Oficiales) */}
        <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-slate-800">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
            {DOC_PRESETS.map((doc) => {
              const Icon = doc.icon;
              const isActive = currentDocType === doc.id;
              return (
                <button
                  key={doc.id}
                  type="button"
                  onClick={() => handleSwitchDoc(doc.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 border ${
                    isActive
                      ? 'bg-blue-600 text-white border-blue-400 shadow-md shadow-blue-500/30'
                      : 'bg-slate-950/70 text-slate-400 hover:text-slate-200 border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-blue-400'}`} />
                  <span>{doc.label}</span>
                </button>
              );
            })}
          </div>

          {/* Sub-selector para Orden de Lab (Pág 1 vs Pág 2) */}
          {currentDocType === 'ORDEN_LAB' && (
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setLabPage('p1')}
                className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                  labPage === 'p1' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                Página 1 (Perfil)
              </button>
              <button
                type="button"
                onClick={() => setLabPage('p2')}
                className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                  labPage === 'p2' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                Página 2 (Especiales)
              </button>
            </div>
          )}

          {/* Controles de Vista de Fondo: Opacidad, Contraste, Zoom y Carga de Escaneo */}
          <div className="flex items-center gap-2">
            {/* Input Oculto para Cargar Escaneo Propio */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/png,image/jpeg,image/webp"
              onChange={handleFileUpload}
              className="hidden"
            />
            
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl border border-slate-700 transition cursor-pointer"
              title="Cargar un escaneo JPG/PNG propio de la papelería física"
            >
              <Upload className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Cargar Escaneo</span>
            </button>

            {/* Ajuste de Opacidad del Fondo Original */}
            <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1 rounded-xl border border-slate-800 text-xs">
              <ImageIcon className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[10px] text-slate-400 hidden sm:inline">Fondo:</span>
              <input
                type="range"
                min="20"
                max="100"
                value={bgOpacity}
                onChange={(e) => setBgOpacity(parseInt(e.target.value, 10))}
                className="w-16 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                title={`Opacidad del fondo: ${bgOpacity}%`}
              />
              <span className="text-[10px] font-mono text-cyan-300 w-7 text-right">{bgOpacity}%</span>
            </div>

            {/* Controles de Zoom */}
            <div className="flex items-center bg-slate-950 rounded-xl border border-slate-800 p-0.5 text-xs">
              <button
                type="button"
                onClick={() => setZoom((z) => Math.max(0.4, Number((z - 0.1).toFixed(2))))}
                className="p-1.5 text-slate-400 hover:text-white transition cursor-pointer"
                title="Reducir Zoom"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="px-2 font-mono font-bold text-cyan-300 text-[11px]">
                {Math.round(zoom * 100)}%
              </span>
              <button
                type="button"
                onClick={() => setZoom((z) => Math.min(1.4, Number((z + 0.1).toFixed(2))))}
                className="p-1.5 text-slate-400 hover:text-white transition cursor-pointer"
                title="Aumentar Zoom"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 2. CONTENEDOR PRINCIPAL: LIENZO A4 (FONDO AUTÉNTICO 300 DPI) + INSPECTOR LATERAL */}
      <div className="flex flex-col lg:flex-row gap-6 items-start justify-center w-full max-w-6xl pb-12">
        
        {/* Lienzo de Edición 1:1 A4 con Zoom y Fondo de Papelería Original */}
        <div className="flex-1 overflow-auto bg-slate-950/80 p-4 rounded-2xl border border-slate-800 flex justify-center max-w-full shadow-2xl">
          <div 
            style={{ 
              transform: `scale(${zoom})`, 
              transformOrigin: 'top center',
              transition: 'transform 0.1s ease-out'
            }}
            className="shrink-0"
          >
            {/* Hoja A4 exacta (794 x 1123 px) */}
            <div
              ref={containerRef}
              id="visual-template-editor-a4"
              className="relative bg-white shadow-2xl shrink-0 overflow-hidden select-none border border-slate-400 rounded-sm"
              style={{
                width: '794px',
                height: '1123px',
                boxSizing: 'border-box',
              }}
            >
              {/* IMAGEN DE FONDO ORIGINAL GARANTIZADA MEDIANTE TAG <IMG> */}
              <img
                src={effectiveBgUrl}
                alt={`Fondo Oficial Original - ${currentDocType}`}
                className="absolute inset-0 w-full h-full object-fill pointer-events-none select-none z-0"
                style={{
                  opacity: bgOpacity / 100,
                  filter: bgContrast === 'high' ? 'contrast(1.3) brightness(0.95)' : 'none',
                }}
                loading="eager"
              />

              {/* Indicador de Papelería Original en Esquina */}
              <div className="absolute top-2 right-2 px-2 py-0.5 rounded bg-blue-950/80 text-cyan-300 text-[9px] font-mono font-bold z-20 pointer-events-none border border-cyan-600/40">
                FONDO OFICIAL: {DOCUMENT_DEFINITIONS[currentDocType]?.shortName || currentDocType}
              </div>

              {/* Cajas flotantes de campos calibrables */}
              {(Object.values(fields || {}) as FieldCalibration[])
                .filter((f): f is FieldCalibration => Boolean(f && typeof f === 'object' && f.id))
                .map((field: FieldCalibration) => {
                  const isSelected = selectedId === field.id;
                  return (
                    <div
                      key={field.id}
                      onMouseDown={(e) => handleMouseDown(e, field.id)}
                      onTouchStart={(e) => handleMouseDown(e, field.id)}
                      className={`absolute cursor-move select-none flex items-center px-1 rounded transition-colors ${
                        isSelected
                          ? 'border-2 border-blue-600 bg-blue-500/25 ring-4 ring-blue-400/40 z-30 shadow-lg'
                          : 'border border-dashed border-blue-600/70 bg-blue-500/10 hover:border-blue-600 hover:bg-blue-500/20 z-10'
                      }`}
                      style={{
                        top: `${field.top}px`,
                        left: `${field.left}px`,
                        width: `${field.width}px`,
                        height: `${field.height}px`,
                      }}
                    >
                      {/* Etiqueta flotante superior */}
                      <span className="text-[9px] font-bold font-mono bg-blue-900/90 text-cyan-200 px-1 py-0.5 rounded absolute -top-4 left-0 pointer-events-none shadow-xs truncate max-w-full">
                        {field.label} ({field.top}, {field.left})
                      </span>
                      
                      {/* Texto interno de previsualización */}
                      <div className="w-full h-full flex items-center text-[11px] text-[#143e72] font-bold opacity-60 pointer-events-none truncate">
                        [{field.label}]
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>

        {/* Panel Lateral de Propiedades del Campo Seleccionado */}
        <div className="w-full lg:w-80 bg-slate-900 border border-slate-800 rounded-2xl p-4 text-white space-y-4 shadow-xl shrink-0">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Type className="w-3.5 h-3.5" />
              <span>Inspector de Campo</span>
            </h4>
            {selectedField && (
              <span className="text-[10px] font-mono text-slate-400 font-bold">
                {selectedField.id}
              </span>
            )}
          </div>

          {selectedField ? (
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 text-[10px] block mb-1">Nombre / Etiqueta:</label>
                <input
                  type="text"
                  value={selectedField.label}
                  onChange={(e) => updateSelectedFieldProperty('label', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-cyan-300 font-bold focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 text-[10px] block mb-1">Posición Top (Y px):</label>
                  <input
                    type="number"
                    value={selectedField.top}
                    onChange={(e) => updateSelectedFieldProperty('top', parseInt(e.target.value, 10) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1 text-xs text-center text-cyan-300 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-[10px] block mb-1">Posición Left (X px):</label>
                  <input
                    type="number"
                    value={selectedField.left}
                    onChange={(e) => updateSelectedFieldProperty('left', parseInt(e.target.value, 10) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1 text-xs text-center text-cyan-300 font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 text-[10px] block mb-1">Ancho (Width px):</label>
                  <input
                    type="number"
                    value={selectedField.width}
                    onChange={(e) => updateSelectedFieldProperty('width', parseInt(e.target.value, 10) || 20)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1 text-xs text-center text-cyan-300 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-[10px] block mb-1">Alto (Height px):</label>
                  <input
                    type="number"
                    value={selectedField.height}
                    onChange={(e) => updateSelectedFieldProperty('height', parseInt(e.target.value, 10) || 20)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1 text-xs text-center text-cyan-300 font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                <div>
                  <label className="text-slate-400 text-[10px] block mb-1">Tamaño Letra (px):</label>
                  <input
                    type="number"
                    value={selectedField.fontSize || 12}
                    onChange={(e) => updateSelectedFieldProperty('fontSize', parseInt(e.target.value, 10) || 12)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1 text-xs text-center text-cyan-300 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-[10px] block mb-1">Interlineado (px):</label>
                  <input
                    type="number"
                    value={selectedField.lineHeight || 20}
                    onChange={(e) => updateSelectedFieldProperty('lineHeight', parseInt(e.target.value, 10) || 20)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1 text-xs text-center text-cyan-300 font-mono"
                  />
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800">
                <label className="text-slate-400 text-[10px] block mb-1">Lista de Campos Rápidos:</label>
                <div className="max-h-36 overflow-y-auto space-y-1 pr-1">
                  {(Object.values(fields || {}) as FieldCalibration[])
                    .filter((f): f is FieldCalibration => Boolean(f && typeof f === 'object' && f.id))
                    .map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setSelectedId(f.id)}
                        className={`w-full text-left px-2 py-1 rounded text-[11px] truncate transition ${
                          selectedId === f.id ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:bg-slate-800'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                </div>
              </div>

              <p className="text-[10px] text-slate-400 italic pt-2">
                * Haga clic sobre cualquier campo en la hoja y arrástrelo para alinearlo exactamente con el membrete y las líneas preimpresas del fondo original.
              </p>
            </div>
          ) : (
            <div className="text-center py-10 text-slate-500 text-xs italic space-y-3">
              <Move className="w-8 h-8 text-slate-600 mx-auto" />
              <p>Haga clic en cualquier caja flotante sobre el fondo de la hoja A4 para editar sus coordenadas y tipografía.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

