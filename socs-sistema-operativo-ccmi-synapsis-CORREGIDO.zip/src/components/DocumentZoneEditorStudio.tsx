import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Sparkles, 
  Save, 
  RotateCcw, 
  X, 
  Plus, 
  Trash2, 
  Copy, 
  Eye, 
  Edit3, 
  Sliders, 
  Type, 
  AlignLeft, 
  AlignCenter, 
  AlignRight, 
  AlignJustify, 
  Bold, 
  Maximize2, 
  Minimize2, 
  ZoomIn, 
  ZoomOut, 
  Download, 
  Upload, 
  Check, 
  CheckCircle2, 
  AlertTriangle, 
  Printer, 
  Layers, 
  Grid, 
  Move, 
  CornerDownRight, 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight,
  Pill,
  FileText,
  FlaskConical,
  CalendarCheck,
  ClipboardList,
  Search,
  ChevronRight,
  MousePointer,
  HelpCircle,
  Square,
  Circle,
  CheckSquare,
  XSquare,
  PenTool,
  Bookmark,
  Share2,
  Code2,
  Lock,
  Unlock,
  ShieldCheck,
  FileSpreadsheet,
  Image as ImageIcon
} from 'lucide-react';
import { DocType } from '../types';
import { DocumentCalibration, FieldCalibration, AllCalibrations, ShapeType, MarkStyle } from '../types/calibration';
import { DOCUMENT_DEFINITIONS, exportElementToExactA4PDF } from '../utils/pdfExport';
import { 
  getStoredCalibration, 
  saveStoredCalibration, 
  resetStoredCalibration, 
  getAllStoredCalibrations, 
  saveAllStoredCalibrations,
  exportCalibrationsToJsonFile, 
  importCalibrationsFromJson,
  DEFAULT_CALIBRATIONS 
} from '../utils/calibrationStorage';
import { 
  autoCalibrateWithAI, 
  AIPresetProfile, 
  diagnoseLayout, 
  LayoutDiagnostic,
  pxToMm,
  mmToPx
} from '../utils/aiLayoutEngine';
import { getOfficialTemplateUrl, getOfficialPdfUrl, EMBEDDED_TEMPLATES, EMBEDDED_PDF_TEMPLATES, TEMPLATE_NAMES, TEMPLATE_FILE_INFO } from '../assets/embeddedTemplates';
import { OfficialMedicalStamp } from './OfficialMedicalStamp';
import { copyGeminiAuditToClipboard, generateGeminiAuditPackage } from '../utils/geminiAuditExporter';
import { OriginalPdfViewerModal } from './OriginalPdfViewerModal';
import { getAllCustomTemplates, saveCustomTemplate, deleteCustomTemplate } from '../utils/templateStorage';

interface Props {
  initialDoc?: DocType | 'ORDEN_LAB_P2';
  onClose?: () => void;
  onNavigateToWorkspace?: (doc: DocType) => void;
  customBgs?: Record<string, string>;
}

// Sample realistic medical data for live test preview
const SAMPLE_TEST_DATA: Record<string, string> = {
  'patient.fullName': 'MARÍA EUGENIA DELGADO RIVAS',
  'patient.idNumber': 'V-16.482.903',
  'patient.age': '45',
  'patient.date': new Date().toLocaleDateString('es-VE'),
  'patient.phone': '0424-912.44.81',
  'patient.address': 'Urb. Chilemex, Calle Chile, Puerto Ordaz, Edo. Bolívar',
  'patient.fullNameRight': 'MARÍA EUGENIA DELGADO RIVAS',
  'patient.idNumberRight': 'V-16.482.903',
  'patient.ageRight': '45',
  'patient.dateRight': new Date().toLocaleDateString('es-VE'),
  'recipe.rxLeft': '1. Pregabalina 75 mg - Cápsulas.\n   Tomar 1 cápsula vía oral cada 12 horas por 14 días. (Disp: 28 cápsulas).\n\n2. Meloxicam 15 mg - Tabletas.\n   Tomar 1 tableta vía oral cada 24 horas con el desayuno por 7 días. (Disp: 7 tabletas).\n\n3. Tiocolchicósido 4 mg - Cápsulas.\n   Tomar 1 cápsula vía oral cada 12 horas por 5 días. (Disp: 10 cápsulas).',
  'recipe.indicationsRight': '• Tomar los medicamentos puntualmente según el horario indicado.\n• Aplicar calor local seco en la zona lumbar durante 15 minutos, 2 veces al día.\n• Mantener reposo físico relativo y evitar levantar objetos pesados (>5 kg).\n• Control en consulta en 14 días con resultado de resonancia magnética.',
  'informe.bodyText': 'Se evalúa paciente femenina de 45 años de edad con cuadro clínico de 3 semanas de evolución caracterizado por lumbociatalgia derecha de intensidad progresiva (EVA 8/10), irradiada a cara posterior de muslo y pierna derecha.\n\nAl examen neurológico: Reflejo aquiliano derecho disminuido (+/++++), Maniobra de Lasègue positiva a 35° en miembro inferior derecho. Hipoestesia en dermatoma S1 derecho. Fuerza muscular conservada 4+/5 para flexión plantar.\n\nCONCLUSIÓN DIAGNÓSTICA:\n1. Hernia discal lumbar posterolateral derecha L5-S1 en fase aguda.\n2. Radiculopatía S1 derecha compresiva.',
  'constancia.restDays': 'Siete (07) días continuos',
  'constancia.restFrom': new Date().toLocaleDateString('es-VE'),
  'constancia.restTo': new Date(Date.now() + 7 * 86400000).toLocaleDateString('es-VE'),
  'constancia.idx': 'Hernia discal lumbar L5-S1 con radiculopatía aguda en tratamiento.',
  'historia.motivo': 'Dolor lumbar severo irradiado a pierna derecha y dificultad para la marcha.',
  'historia.enfermedadActual': 'Paciente refiere inicio hace 21 días con dolor punzante en región lumbar tras sobreesfuerzo físico, el cual se intensificó progresivamente y se irradió a miembro inferior derecho con parestesias.',
  'historia.antecedentes': '• Médicos: Hipertensión arterial controlada con Losartán 50mg/día.\n• Quirúrgicos: Cesárea segmentaria (2012).\n• Alergias: Negadas.',
  'historia.neuroExam': 'Funciones cerebrales superiores conservadas. Pares craneales intactos. Fuerza: MSD 5/5, MSI 5/5, MID 4+/5, MII 5/5. Sensibilidad disminuida en S1 derecho. Marcha antiálgica sobre talones.',
  'historia.diagnostico': '1. Discopatía degenerativa L5-S1 con hernia extruida foraminal derecha.\n2. Lumbociatalgia derecha compresiva.',
};

export const DocumentZoneEditorStudio: React.FC<Props> = ({
  initialDoc = 'RECIPES',
  onClose,
  onNavigateToWorkspace,
  customBgs = {},
}) => {
  // Document selector state
  const [activeDoc, setActiveDoc] = useState<DocType | 'ORDEN_LAB_P2'>(initialDoc);
  const [calibrations, setCalibrations] = useState<DocumentCalibration>({});
  const [selectedFieldId, setSelectedFieldId] = useState<string | null>(null);
  const [mode, setMode] = useState<'edit' | 'test'>('edit');
  const [toolMode, setToolMode] = useState<'select' | 'draw'>('select');
  const [activeShapeTool, setActiveShapeTool] = useState<ShapeType>('rectangle');
  const [zoom, setZoom] = useState<number>(0.9);
  const [bgOpacity, setBgOpacity] = useState<number>(100);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [snapToGrid, setSnapToGrid] = useState<boolean>(false);
  const [unit, setUnit] = useState<'px' | 'mm'>('px');
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [hasChanges, setHasChanges] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [isGeminiModalOpen, setIsGeminiModalOpen] = useState<boolean>(false);
  const [geminiReportCopied, setGeminiReportCopied] = useState<boolean>(false);
  const [isOriginalPdfModalOpen, setIsOriginalPdfModalOpen] = useState<boolean>(false);
  const [customBgMap, setCustomBgMap] = useState<Record<string, string>>(customBgs);

  // Drawing new zone states
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [drawStart, setDrawStart] = useState<{ x: number; y: number } | null>(null);
  const [drawCurrent, setDrawCurrent] = useState<{ x: number; y: number } | null>(null);

  // Test data values for live preview
  const [testValues, setTestValues] = useState<Record<string, string>>(SAMPLE_TEST_DATA);

  // Refs
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const canvasPaperRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bgUploadInputRef = useRef<HTMLInputElement>(null);

  const loadAllCustomBgs = useCallback(async () => {
    try {
      const stored = await getAllCustomTemplates();
      setCustomBgMap((prev) => ({ ...prev, ...stored, ...customBgs }));
    } catch (e) {
      console.warn('Error loading custom templates:', e);
    }
  }, [customBgs]);

  useEffect(() => {
    loadAllCustomBgs();
    const handleTemplateUpdated = () => {
      loadAllCustomBgs();
    };
    window.addEventListener('cmi-template-updated', handleTemplateUpdated);
    return () => window.removeEventListener('cmi-template-updated', handleTemplateUpdated);
  }, [loadAllCustomBgs]);

  const docTabs: { id: DocType | 'ORDEN_LAB_P2'; name: string; shortName: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'RECIPES', name: 'Récipe (Doble Talón)', shortName: 'Récipe', icon: Pill },
    { id: 'INFORME', name: 'Informe Médico', shortName: 'Informe', icon: FileText },
    { id: 'ORDEN_LAB', name: 'Orden Lab (Pág. 1)', shortName: 'Lab Pág. 1', icon: FlaskConical },
    { id: 'ORDEN_LAB_P2', name: 'Neuroimagen (Pág. 2)', shortName: 'Lab Pág. 2', icon: FlaskConical },
    { id: 'CONSTANCIA', name: 'Constancia de Reposo', shortName: 'Constancia', icon: CalendarCheck },
    { id: 'HISTORIA', name: 'Historia Clínica', shortName: 'Historia', icon: ClipboardList },
  ];

  // Load calibration for active document
  useEffect(() => {
    const loaded = getStoredCalibration(activeDoc as any) || {};
    setCalibrations(loaded);
    setSelectedFieldId(null);
    setHasChanges(false);
  }, [activeDoc]);

  // Current selected field
  const selectedField: FieldCalibration | null = (selectedFieldId && calibrations && calibrations[selectedFieldId]) ? calibrations[selectedFieldId] : null;
  const fieldsList: FieldCalibration[] = (Object.values(calibrations || {}) as FieldCalibration[]).filter(
    (f): f is FieldCalibration => Boolean(f && typeof f === 'object' && f.id)
  );

  // Filtered fields list by search
  const filteredFields = fieldsList.filter((f) => 
    (f.label || '').toLowerCase().includes(searchQuery.toLowerCase()) || 
    (f.id || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Diagnostics check
  const diagnostics: LayoutDiagnostic[] = diagnoseLayout(calibrations);

  // Active Background URL (Custom Scan or Official 300 DPI Background)
  const bgImage = customBgMap[activeDoc] || getOfficialTemplateUrl(activeDoc);
  const isCustomBgActive = Boolean(customBgMap[activeDoc]);

  const handleUploadBgFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
      const dataUrl = evt.target?.result as string;
      if (dataUrl) {
        setCustomBgMap((prev) => ({ ...prev, [activeDoc]: dataUrl }));
        await saveCustomTemplate(activeDoc, dataUrl);
        window.dispatchEvent(new CustomEvent('cmi-template-updated'));
        setSaveStatus(`✅ Fondo escaneado para "${docTabs.find(t => t.id === activeDoc)?.name || activeDoc}" cargado con éxito.`);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleResetBgToFactory = async () => {
    await deleteCustomTemplate(activeDoc);
    setCustomBgMap((prev) => {
      const next = { ...prev };
      delete next[activeDoc];
      return next;
    });
    window.dispatchEvent(new CustomEvent('cmi-template-updated'));
    setSaveStatus(`🔄 Fondo de fábrica restablecido a 300 DPI para ${activeDoc}.`);
  };

  // Update a single field
  const handleUpdateField = useCallback((updated: FieldCalibration) => {
    if (!updated || !updated.id) return;
    setCalibrations((prev) => ({
      ...prev,
      [updated.id]: updated,
    }));
    setHasChanges(true);
  }, []);

  // Keyboard navigation for precision pixel nudging
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) {
        if (!e.altKey && !e.ctrlKey && !e.metaKey) return;
      }

      if (!selectedField) return;

      const step = e.shiftKey ? 10 : (e.altKey ? 5 : 1);

      if (e.key === 'ArrowUp') {
        e.preventDefault();
        handleUpdateField({ ...selectedField, top: Math.max(0, selectedField.top - step) });
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        handleUpdateField({ ...selectedField, top: Math.min(1123 - selectedField.height, selectedField.top + step) });
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handleUpdateField({ ...selectedField, left: Math.max(0, selectedField.left - step) });
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        handleUpdateField({ ...selectedField, left: Math.min(794 - selectedField.width, selectedField.left + step) });
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        if (e.altKey || e.ctrlKey || e.metaKey) {
          e.preventDefault();
          handleDeleteField(selectedField.id);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedField, handleUpdateField]);

  // Save calibrations permanently to storage & notify app
  const handleSaveDefinitive = () => {
    saveStoredCalibration(activeDoc, calibrations);
    setHasChanges(false);
    
    // Broadcast custom event so active workspaces update immediately
    window.dispatchEvent(new CustomEvent('cmi-calibration-updated', {
      detail: { docType: activeDoc, calibration: calibrations }
    }));

    setSaveStatus(`💾 ¡Zonas de ${DOCUMENT_DEFINITIONS[activeDoc]?.shortName || activeDoc} guardadas definitivamente!`);
    setTimeout(() => setSaveStatus(null), 4000);
  };

  // Reset to factory defaults
  const handleResetFactory = () => {
    if (window.confirm(`¿Restablecer todas las zonas de ${DOCUMENT_DEFINITIONS[activeDoc]?.shortName || activeDoc} a los valores de fábrica?`)) {
      const reset = resetStoredCalibration(activeDoc);
      setCalibrations(reset);
      setSelectedFieldId(null);
      setHasChanges(false);

      window.dispatchEvent(new CustomEvent('cmi-calibration-updated', {
        detail: { docType: activeDoc, calibration: reset }
      }));

      setSaveStatus('🔄 Zonas restablecidas a valores originales de fábrica.');
      setTimeout(() => setSaveStatus(null), 3000);
    }
  };

  // Add new zone or shape
  const handleAddNewZone = (coords?: { top: number; left: number; width: number; height: number }, shapeType: ShapeType = activeShapeTool) => {
    const nextId = `zone.${shapeType}_${Date.now().toString().slice(-4)}`;
    
    // Configurar valores por defecto según el tipo de forma
    let defaultW = 200;
    let defaultH = 32;
    let defaultMark: MarkStyle = 'NONE';
    let defaultFieldType: FieldCalibration['fieldType'] = 'text';

    if (shapeType === 'square' || shapeType === 'checkbox_x' || shapeType === 'checkbox_check' || shapeType === 'checkbox_bullet' || shapeType === 'checkbox_box') {
      defaultW = 24;
      defaultH = 24;
      defaultFieldType = 'checkbox';
      if (shapeType === 'checkbox_x') defaultMark = 'X';
      if (shapeType === 'checkbox_check') defaultMark = 'CHECK';
      if (shapeType === 'checkbox_bullet') defaultMark = 'BULLET';
      if (shapeType === 'checkbox_box') defaultMark = 'SQUARE_FILL';
    } else if (shapeType === 'circle') {
      defaultW = 32;
      defaultH = 32;
    } else if (shapeType === 'callout_corner') {
      defaultW = 160;
      defaultH = 40;
    }

    const newField: FieldCalibration = {
      id: nextId,
      label: `Zona ${shapeType} ${fieldsList.length + 1}`,
      top: coords ? coords.top : 250,
      left: coords ? coords.left : 100,
      width: coords ? Math.max(16, coords.width) : defaultW,
      height: coords ? Math.max(16, coords.height) : defaultH,
      fontSize: shapeType.startsWith('checkbox') ? 14 : 11,
      fontWeight: 'bold',
      textAlign: shapeType.startsWith('checkbox') ? 'center' : 'left',
      fieldType: defaultFieldType,
      textColor: '#143e72',
      shapeType: shapeType,
      markStyle: defaultMark,
      borderColor: '#0284c7',
      borderWidth: 1,
      borderStyle: 'solid',
      borderRadius: shapeType === 'circle' ? 999 : (shapeType === 'badge' ? 12 : 2),
      cornerPointer: shapeType === 'callout_corner' ? 'top-left' : 'none',
      fillColor: 'transparent',
      fillOpacity: 0,
      isCustom: true,
    };

    setCalibrations((prev) => ({
      ...prev,
      [newField.id]: newField,
    }));
    setSelectedFieldId(newField.id);
    setHasChanges(true);
    setSaveStatus(`➕ Nueva forma añadida: "${newField.label}".`);
    setTimeout(() => setSaveStatus(null), 2500);
  };

  // Delete field
  const handleDeleteField = (fieldId: string) => {
    const field = calibrations[fieldId];
    if (!field) return;
    if (window.confirm(`¿Eliminar la zona "${field.label}" (${field.id})?`)) {
      setCalibrations((prev) => {
        const copy = { ...prev };
        delete copy[fieldId];
        return copy;
      });
      if (selectedFieldId === fieldId) {
        setSelectedFieldId(null);
      }
      setHasChanges(true);
      setSaveStatus(`🗑️ Zona eliminada.`);
      setTimeout(() => setSaveStatus(null), 2500);
    }
  };

  // Duplicate field
  const handleDuplicateField = (field: FieldCalibration) => {
    const duplicateId = `${field.id}_copia_${Date.now().toString().slice(-3)}`;
    const duplicate: FieldCalibration = {
      ...field,
      id: duplicateId,
      label: `${field.label} (Copia)`,
      top: Math.min(1080, field.top + 20),
      left: Math.min(750, field.left + 20),
      isCustom: true,
    };
    setCalibrations((prev) => ({
      ...prev,
      [duplicate.id]: duplicate,
    }));
    setSelectedFieldId(duplicate.id);
    setHasChanges(true);
  };

  // Smart AI Auto-calibrate
  const handleAutoCalibrate = (preset: AIPresetProfile = 'printed_lines') => {
    const aiCalib = autoCalibrateWithAI(activeDoc, preset);
    setCalibrations(aiCalib);
    setSelectedFieldId(null);
    setHasChanges(true);
    setSaveStatus(`✨ Auto-calibrado con IA aplicado a ${DOCUMENT_DEFINITIONS[activeDoc]?.shortName || activeDoc}.`);
    setTimeout(() => setSaveStatus(null), 4000);
  };

  // Export JSON Backup
  const handleExportBackup = () => {
    exportCalibrationsToJsonFile();
    setSaveStatus('💾 ¡Copia de seguridad (.json) descargada a su equipo con éxito!');
    setTimeout(() => setSaveStatus(null), 4000);
  };

  // Import JSON Backup
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const all = importCalibrationsFromJson(text);
        if (all[activeDoc]) {
          setCalibrations(all[activeDoc]);
        }
        setSaveStatus('✨ ¡Calibraciones importadas y aplicadas a todas las plantillas!');
        setTimeout(() => setSaveStatus(null), 4000);
      } catch (err) {
        alert('Error al leer el archivo JSON de calibraciones. Verifique el formato.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Copy to Gemini AI handler
  const handleCopyToGemini = async () => {
    const ok = await copyGeminiAuditToClipboard(activeDoc, getAllStoredCalibrations());
    if (ok) {
      setGeminiReportCopied(true);
      setSaveStatus('📋 ¡Configuración completa y prompt de auditoría copiados al portapapeles para Gemini AI!');
      setTimeout(() => {
        setGeminiReportCopied(false);
        setSaveStatus(null);
      }, 4000);
    } else {
      setIsGeminiModalOpen(true);
    }
  };

  // Test PDF Export
  const handleTestPdfExport = async () => {
    setIsExportingPdf(true);
    try {
      saveStoredCalibration(activeDoc, calibrations);
      const filename = `Prueba_Calibracion_${DOCUMENT_DEFINITIONS[activeDoc]?.shortName?.replace(/\s+/g, '_') || activeDoc}.pdf`;
      const result = await exportElementToExactA4PDF('zone-editor-paper-canvas', filename);

      if (result && result.success) {
        setSaveStatus('🖨️ ¡PDF de prueba generado y descargado exitosamente con 300 DPI!');
      }
    } catch (err) {
      console.error('Error exportando PDF de prueba:', err);
      alert('Error generando el PDF de prueba. Verifique que el lienzo sea visible.');
    } finally {
      setIsExportingPdf(false);
      setTimeout(() => setSaveStatus(null), 4000);
    }
  };

  // Canvas Mouse Down for Drawing new zones
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (toolMode !== 'draw' || !canvasPaperRef.current) return;

    const rect = canvasPaperRef.current.getBoundingClientRect();
    const rawX = (e.clientX - rect.left) / zoom;
    const rawY = (e.clientY - rect.top) / zoom;

    const startX = Math.round(Math.max(0, Math.min(794, rawX)));
    const startY = Math.round(Math.max(0, Math.min(1123, rawY)));

    setIsDrawing(true);
    setDrawStart({ x: startX, y: startY });
    setDrawCurrent({ x: startX, y: startY });
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDrawing || !drawStart || !canvasPaperRef.current) return;

    const rect = canvasPaperRef.current.getBoundingClientRect();
    const rawX = (e.clientX - rect.left) / zoom;
    const rawY = (e.clientY - rect.top) / zoom;

    const currentX = Math.round(Math.max(0, Math.min(794, rawX)));
    const currentY = Math.round(Math.max(0, Math.min(1123, rawY)));

    setDrawCurrent({ x: currentX, y: currentY });
  };

  const handleCanvasMouseUp = () => {
    if (!isDrawing || !drawStart || !drawCurrent) {
      setIsDrawing(false);
      return;
    }

    const left = Math.min(drawStart.x, drawCurrent.x);
    const top = Math.min(drawStart.y, drawCurrent.y);
    const width = Math.abs(drawCurrent.x - drawStart.x);
    const height = Math.abs(drawCurrent.y - drawStart.y);

    setIsDrawing(false);
    setDrawStart(null);
    setDrawCurrent(null);

    // Only create if minimum size is met
    if (width > 12 && height > 12) {
      handleAddNewZone({ top, left, width, height }, activeShapeTool);
      setToolMode('select');
    }
  };

  return (
    <div id="document-zone-editor-studio" className="min-h-[88vh] flex flex-col bg-slate-950 text-slate-100 rounded-2xl overflow-hidden border border-slate-700 shadow-2xl">
      {/* 1. TOP HEADER: DEVELOPER EXCLUSIVE STUDIO */}
      <header className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
        
        {/* Left: Developer Badge & Title */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-indigo-600 to-cyan-500 flex items-center justify-center text-slate-950 shadow-md">
            <Code2 className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm sm:text-base font-black text-white tracking-tight">
                Developer Studio: Calibración & Formas PDF
              </h1>
              <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-amber-400 text-slate-950 border border-amber-300">
                🔒 Área Exclusiva Desarrollador
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Fondos oficiales fijos precargados a 300 DPI • Edición vectorial de marcas (X, ✓, ●), recuadros y figuras con punta.
            </p>
          </div>
        </div>

        {/* Center: Mode Toggles (Edit Zones vs Test Input) */}
        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => setMode('edit')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              mode === 'edit'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Editar Formas & Coordenadas</span>
          </button>

          <button
            type="button"
            onClick={() => setMode('test')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              mode === 'test'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Probar Impresión en Vivo</span>
          </button>
        </div>

        {/* Right: Key Actions (Copiar a Gemini, Guardar, Cargar Escaneo, Backup, PDF, Close) */}
        <div className="flex items-center gap-2 flex-wrap">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImportBackup}
            accept=".json,application/json"
            className="hidden"
          />

          <input
            type="file"
            ref={bgUploadInputRef}
            onChange={handleUploadBgFile}
            accept="image/png,image/jpeg,image/webp,image/jpg"
            className="hidden"
          />

          {/* BOTÓN: CARGAR ESCANEO / IMAGEN PERSONALIZADA */}
          <button
            type="button"
            onClick={() => bgUploadInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-teal-300 hover:text-teal-200 text-xs font-bold border border-teal-500/40 transition cursor-pointer shadow-sm"
            title="Cargar una foto o escaneo propio de la plantilla médica física"
          >
            <ImageIcon className="w-3.5 h-3.5 text-teal-400" />
            <span>🖼️ Cargar Escaneo</span>
          </button>

          {isCustomBgActive && (
            <button
              type="button"
              onClick={handleResetBgToFactory}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-950/60 hover:bg-amber-900 text-amber-300 text-xs font-bold border border-amber-500/50 transition cursor-pointer shadow-sm"
              title="Restablecer al fondo oficial de alta resolución a 300 DPI"
            >
              <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden md:inline">Restaurar Fábrica</span>
            </button>
          )}

          {/* BOTÓN: VER PDF / ARCHIVO ORIGINAL */}
          <button
            type="button"
            onClick={() => setIsOriginalPdfModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-900/60 hover:bg-blue-800 text-cyan-300 hover:text-white text-xs font-bold border border-blue-600/50 transition cursor-pointer shadow-sm"
            title="Ver los archivos PDF e imágenes originales precargados de fábrica"
          >
            <FileText className="w-3.5 h-3.5 text-cyan-400" />
            <span>📄 Ver PDF Original</span>
          </button>

          {/* BOTÓN PROMINENTE: COPIAR PARA GEMINI AI */}
          <button
            type="button"
            onClick={handleCopyToGemini}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black transition cursor-pointer border shadow-md ${
              geminiReportCopied
                ? 'bg-emerald-500 text-slate-950 border-emerald-300 ring-2 ring-emerald-400/50'
                : 'bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white border-purple-400/40'
            }`}
            title="Copiar toda la programación, coordenadas y prompt para que Gemini AI audite el sistema"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>{geminiReportCopied ? '¡Copiado a Gemini!' : '📋 Copiar Todo para Gemini AI'}</span>
          </button>

          <button
            type="button"
            onClick={handleExportBackup}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 text-xs font-semibold border border-slate-800 transition cursor-pointer"
            title="Descargar copia de seguridad en JSON de todas las calibraciones"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">JSON</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 text-xs font-semibold border border-slate-800 transition cursor-pointer"
            title="Cargar archivo JSON de calibraciones previas"
          >
            <Upload className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Importar</span>
          </button>

          <button
            type="button"
            onClick={handleTestPdfExport}
            disabled={isExportingPdf}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer"
            title="Generar PDF con las coordenadas actuales para verificar alineación"
          >
            <Printer className={`w-3.5 h-3.5 ${isExportingPdf ? 'animate-spin' : 'text-amber-400'}`} />
            <span className="hidden md:inline">PDF Test</span>
          </button>

          {/* Botón Principal: GUARDAR ZONAS DEFINITIVAS */}
          <button
            type="button"
            onClick={handleSaveDefinitive}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-black transition shadow-lg cursor-pointer ${
              hasChanges
                ? 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 ring-2 ring-emerald-400/50 animate-pulse'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
          >
            <Save className="w-4 h-4" />
            <span>Guardar Calibración</span>
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
              title="Volver a la vista del Dr. Samir"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      {/* 2. SUB-BAR: DOCUMENT SWITCHER & ADVANCED PDF SHAPE PALETTE */}
      <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-2 flex flex-wrap items-center justify-between gap-3">
        
        {/* Document Tabs (Fixed 5 templates) */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {docTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeDoc === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveDoc(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-xs font-black'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-transparent'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                <span>{tab.name}</span>
              </button>
            );
          })}
        </div>

        {/* Shape / PDF Annotation Insertion Palette */}
        {mode === 'edit' && (
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <span className="text-[10px] font-bold text-slate-400 px-1 uppercase hidden xl:inline">Insertar Forma:</span>
            
            {/* Rectángulo */}
            <button
              type="button"
              onClick={() => handleAddNewZone(undefined, 'rectangle')}
              className="p-1.5 rounded-lg bg-slate-900 hover:bg-blue-600 text-slate-300 hover:text-white transition"
              title="Insertar Rectángulo de Texto estándar"
            >
              <Square className="w-3.5 h-3.5" />
            </button>

            {/* Cuadrado con X */}
            <button
              type="button"
              onClick={() => handleAddNewZone(undefined, 'checkbox_x')}
              className="p-1.5 rounded-lg bg-slate-900 hover:bg-blue-600 text-slate-300 hover:text-white transition"
              title="Insertar Casilla de Selección con marca [X]"
            >
              <XSquare className="w-3.5 h-3.5 text-rose-400" />
            </button>

            {/* Cuadrado con Check */}
            <button
              type="button"
              onClick={() => handleAddNewZone(undefined, 'checkbox_check')}
              className="p-1.5 rounded-lg bg-slate-900 hover:bg-blue-600 text-slate-300 hover:text-white transition"
              title="Insertar Casilla de Selección con marca [✓]"
            >
              <CheckSquare className="w-3.5 h-3.5 text-emerald-400" />
            </button>

            {/* Cuadrado con Punta (Callout Corner) */}
            <button
              type="button"
              onClick={() => handleAddNewZone(undefined, 'callout_corner')}
              className="p-1.5 rounded-lg bg-slate-900 hover:bg-blue-600 text-slate-300 hover:text-white transition"
              title="Insertar Recuadro con Esquina en Punta (Callout / Etiqueta médica)"
            >
              <Bookmark className="w-3.5 h-3.5 text-amber-400" />
            </button>

            {/* Círculo / Óvalo */}
            <button
              type="button"
              onClick={() => handleAddNewZone(undefined, 'circle')}
              className="p-1.5 rounded-lg bg-slate-900 hover:bg-blue-600 text-slate-300 hover:text-white transition"
              title="Insertar Círculo / Óvalo de realce"
            >
              <Circle className="w-3.5 h-3.5 text-cyan-400" />
            </button>

            {/* Línea / Subrayado */}
            <button
              type="button"
              onClick={() => handleAddNewZone(undefined, 'underline')}
              className="p-1.5 rounded-lg bg-slate-900 hover:bg-blue-600 text-slate-300 hover:text-white transition"
              title="Insertar Línea guía o Subrayado"
            >
              <PenTool className="w-3.5 h-3.5 text-indigo-400" />
            </button>
          </div>
        )}

        {/* Canvas Tools (Opacidad de Fondo, Zoom, Cuadrícula) */}
        <div className="flex items-center gap-2 flex-wrap">
          
          {/* Opacidad del Fondo Original */}
          <div className="flex items-center gap-1.5 bg-slate-950 px-2 py-1 rounded-lg border border-slate-800 text-xs">
            <span className="text-[10px] text-slate-400">Fondo:</span>
            <input
              type="range"
              min="20"
              max="100"
              value={bgOpacity}
              onChange={(e) => setBgOpacity(Number(e.target.value))}
              className="w-16 accent-cyan-500 cursor-pointer"
              title={`Opacidad del fondo original: ${bgOpacity}%`}
            />
            <span className="text-[10px] font-mono text-cyan-300 w-7">{bgOpacity}%</span>
          </div>

          {/* Grid Toggle */}
          <button
            type="button"
            onClick={() => setShowGrid(!showGrid)}
            className={`p-1.5 rounded-lg border text-xs transition cursor-pointer ${
              showGrid 
                ? 'bg-cyan-950 text-cyan-300 border-cyan-700' 
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
            title="Mostrar u ocultar cuadrícula milimétrica"
          >
            <Grid className="w-3.5 h-3.5" />
          </button>

          {/* Unit Toggle: px / mm */}
          <button
            type="button"
            onClick={() => setUnit(unit === 'px' ? 'mm' : 'px')}
            className="px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:text-white text-xs font-mono font-bold"
            title="Alternar entre píxeles (px) y milímetros (mm)"
          >
            {unit.toUpperCase()}
          </button>

          {/* Zoom Controls */}
          <div className="flex items-center bg-slate-950 rounded-lg border border-slate-800 p-0.5">
            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.4, Number((z - 0.1).toFixed(1))))}
              className="p-1 text-slate-400 hover:text-white cursor-pointer"
              title="Reducir Zoom"
            >
              <ZoomOut className="w-3 h-3" />
            </button>
            <span className="px-1.5 text-[11px] font-mono font-bold text-cyan-300">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(1.4, Number((z + 0.1).toFixed(1))))}
              className="p-1 text-slate-400 hover:text-white cursor-pointer"
              title="Aumentar Zoom"
            >
              <ZoomIn className="w-3 h-3" />
            </button>
          </div>

          {/* Reset Factory */}
          <button
            type="button"
            onClick={handleResetFactory}
            className="p-1.5 rounded-lg bg-slate-950 hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-800 transition cursor-pointer"
            title="Restablecer todas las zonas de este documento a valores de fábrica"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Notification status toast */}
      {saveStatus && (
        <div className="bg-emerald-950/90 border-b border-emerald-500/60 text-emerald-200 px-4 py-2 text-xs font-bold flex items-center justify-between animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{saveStatus}</span>
          </div>
          <button
            type="button"
            onClick={() => setSaveStatus(null)}
            className="text-emerald-400 hover:text-white text-xs underline cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      )}

      {/* 3. MAIN WORKSPACE BODY: CANVAS + INSPECTOR PANEL */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        
        {/* === CANVAS VIEWPORT === */}
        <div 
          ref={canvasContainerRef}
          className="flex-1 overflow-auto bg-slate-950 p-4 sm:p-8 flex items-start justify-center relative select-none"
          style={{ cursor: toolMode === 'draw' ? 'crosshair' : 'default' }}
        >
          {/* Zoom Wrapper */}
          <div 
            style={{ 
              transform: `scale(${zoom})`, 
              transformOrigin: 'top center',
              transition: 'transform 0.1s ease-out'
            }}
            className="relative shadow-2xl rounded-sm shrink-0"
          >
            {/* The Actual A4 Sheet Canvas (794 x 1123 px) */}
            <div
              ref={canvasPaperRef}
              id="zone-editor-paper-canvas"
              onMouseDown={handleCanvasMouseDown}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
              className="relative bg-white text-slate-900 overflow-hidden shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)]"
              style={{
                width: '794px',
                height: '1123px',
                minWidth: '794px',
                minHeight: '1123px',
                boxSizing: 'border-box',
                fontFamily: "'Liberation Sans', 'Arial', sans-serif",
              }}
            >
              {/* Authentic Background Template 300 DPI with adjustable opacity & fallback */}
              <img
                src={bgImage}
                alt={`Fondo ${activeDoc}`}
                className="absolute inset-0 w-full h-full object-fill pointer-events-none select-none z-0"
                style={{ opacity: bgOpacity / 100 }}
                loading="eager"
                onError={(e) => {
                  const fallback = (EMBEDDED_TEMPLATES as any)[activeDoc] || EMBEDDED_TEMPLATES.RECIPES;
                  if ((e.target as HTMLImageElement).src !== fallback) {
                    (e.target as HTMLImageElement).src = fallback;
                  }
                }}
              />

              {/* Status Badge of Background Type */}
              <div className="absolute top-2 left-2 z-20 flex items-center gap-1.5 bg-slate-950/85 backdrop-blur-xs px-2.5 py-1 rounded-md border border-slate-700 text-[10px] text-slate-300 pointer-events-auto shadow-md">
                <div className={`w-2 h-2 rounded-full ${isCustomBgActive ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400'}`} />
                <span className="font-bold">
                  {isCustomBgActive ? 'Escaneo Propio Cargado' : 'Plantilla Oficial Original (300 DPI)'}
                </span>
                {isCustomBgActive && (
                  <button
                    type="button"
                    onClick={handleResetBgToFactory}
                    className="text-cyan-400 hover:text-cyan-200 underline font-bold ml-1 cursor-pointer"
                  >
                    Restablecer
                  </button>
                )}
              </div>

              {/* Optional Grid Lines Overlay */}
              {showGrid && (
                <div 
                  className="absolute inset-0 pointer-events-none opacity-20"
                  style={{
                    backgroundImage: `
                      linear-gradient(to right, #0284c7 1px, transparent 1px),
                      linear-gradient(to bottom, #0284c7 1px, transparent 1px)
                    `,
                    backgroundSize: '20px 20px',
                  }}
                />
              )}

              {/* Drawing Rectangle Preview */}
              {isDrawing && drawStart && drawCurrent && (
                <div
                  className="absolute border-2 border-dashed border-cyan-400 bg-cyan-400/20 pointer-events-none z-30"
                  style={{
                    top: Math.min(drawStart.y, drawCurrent.y),
                    left: Math.min(drawStart.x, drawCurrent.x),
                    width: Math.abs(drawCurrent.x - drawStart.x),
                    height: Math.abs(drawCurrent.y - drawStart.y),
                  }}
                >
                  <div className="absolute top-1 left-1 bg-cyan-900 text-cyan-200 text-[9px] font-mono px-1 rounded">
                    {Math.abs(drawCurrent.x - drawStart.x)} × {Math.abs(drawCurrent.y - drawStart.y)} px
                  </div>
                </div>
              )}

              {/* RENDER ALL CALIBRATED ZONES */}
              {fieldsList.map((field) => {
                const isSelected = selectedFieldId === field.id;
                const isStamp = field.id.includes('stamp') || field.fieldType === 'stamp';
                const isMultiline = field.fieldType === 'textarea' || field.id.includes('rx') || field.id.includes('indicat') || field.id.includes('body') || field.id.includes('anteced');

                if (mode === 'test') {
                  // === TEST MODE: REAL EDITABLE FORM INPUTS WITH APPLIED MARKS ===
                  const val = testValues[field.id] || (field.markStyle === 'X' ? 'X' : (field.markStyle === 'CHECK' ? '✓' : ''));
                  return (
                    <div
                      key={field.id}
                      onClick={() => setSelectedFieldId(field.id)}
                      className={`absolute transition-all ${
                        isSelected ? 'ring-2 ring-blue-500 bg-blue-500/10' : 'hover:bg-blue-500/5'
                      }`}
                      style={{
                        top: `${field.top}px`,
                        left: `${field.left}px`,
                        width: `${field.width}px`,
                        height: `${field.height}px`,
                        boxSizing: 'border-box',
                        borderRadius: field.borderRadius ? `${field.borderRadius}px` : undefined,
                        border: field.borderWidth && field.borderWidth > 0 ? `${field.borderWidth}px ${field.borderStyle || 'solid'} ${field.borderColor || '#0284c7'}` : undefined,
                        backgroundColor: field.fillColor && field.fillColor !== 'transparent' ? field.fillColor : undefined,
                      }}
                    >
                      {isStamp ? (
                        <div className="w-full h-full flex items-center justify-center pointer-events-none scale-75 origin-top-left">
                          <OfficialMedicalStamp size="sm" inkColor="navy" />
                        </div>
                      ) : isMultiline ? (
                        <textarea
                          value={val}
                          onChange={(e) => setTestValues({ ...testValues, [field.id]: e.target.value })}
                          placeholder={field.placeholder || field.label}
                          style={{
                            fontSize: `${field.fontSize || 12}px`,
                            lineHeight: `${field.lineHeight || 20}px`,
                            fontWeight: field.fontWeight === 'bold' || field.fontWeight === '900' ? 700 : (field.fontWeight === 'semibold' ? 600 : 400),
                            textAlign: field.textAlign || 'left',
                            color: field.textColor || '#0f172a',
                          }}
                          className="w-full h-full bg-transparent resize-none outline-none border-none p-1 font-sans"
                        />
                      ) : (
                        <input
                          type="text"
                          value={val}
                          onChange={(e) => setTestValues({ ...testValues, [field.id]: e.target.value })}
                          placeholder={field.placeholder || field.label}
                          style={{
                            fontSize: `${field.fontSize || 12}px`,
                            fontWeight: field.fontWeight === 'bold' || field.fontWeight === '900' ? 700 : (field.fontWeight === 'semibold' ? 600 : 400),
                            textAlign: field.textAlign || 'left',
                            color: field.textColor || '#143e72',
                          }}
                          className="w-full h-full bg-transparent outline-none border-none px-1 font-sans"
                        />
                      )}
                    </div>
                  );
                }

                // === EDIT MODE: INTERACTIVE BOUNDING BOXES WITH PDF SHAPE STYLES ===
                return (
                  <ZoneBoundingBox
                    key={field.id}
                    field={field}
                    isSelected={isSelected}
                    onSelect={() => setSelectedFieldId(field.id)}
                    onChange={handleUpdateField}
                    onDelete={() => handleDeleteField(field.id)}
                    onDuplicate={() => handleDuplicateField(field)}
                    unit={unit}
                    snapToGrid={snapToGrid}
                  />
                );
              })}
            </div>
          </div>
        </div>

        {/* === RIGHT SIDEBAR: ZONE INSPECTOR & PDF SHAPE CONTROLS === */}
        <aside className="w-full lg:w-96 bg-slate-900 border-t lg:border-t-0 lg:border-l border-slate-800 flex flex-col shrink-0 max-h-[88vh] overflow-y-auto">
          
          {/* Header of Inspector */}
          <div className="p-3 border-b border-slate-800 flex items-center justify-between gap-2 bg-slate-950 sticky top-0 z-20">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-black uppercase tracking-wider text-slate-200">
                {selectedField ? 'Inspector de Forma' : 'Zonas Calibradas'}
              </span>
              <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 text-[10px] font-mono">
                {fieldsList.length}
              </span>
            </div>

            {selectedField && (
              <button
                type="button"
                onClick={() => setSelectedFieldId(null)}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 font-bold cursor-pointer"
              >
                Ver Lista Completa
              </button>
            )}
          </div>

          {/* INSPECTOR BODY */}
          <div className="p-4 space-y-4">
            {selectedField ? (
              // --- SELECTED ZONE PROPERTIES ---
              <div className="space-y-4 animate-fade-in">
                
                {/* Zone Identity & Label */}
                <div className="space-y-2 bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-black text-cyan-300 uppercase tracking-wide">
                      Identificación
                    </span>
                    <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded">
                      ID: {selectedField.id}
                    </span>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 font-medium mb-1">
                      Nombre / Etiqueta:
                    </label>
                    <input
                      type="text"
                      value={selectedField.label}
                      onChange={(e) => handleUpdateField({ ...selectedField, label: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-bold outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] text-slate-400 font-medium mb-1">
                        Forma PDF:
                      </label>
                      <select
                        value={selectedField.shapeType || 'rectangle'}
                        onChange={(e) => handleUpdateField({ ...selectedField, shapeType: e.target.value as any })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white outline-none focus:border-cyan-400"
                      >
                        <option value="rectangle">Rectángulo</option>
                        <option value="square">Cuadrado</option>
                        <option value="circle">Círculo / Óvalo</option>
                        <option value="callout_corner">Caja con Punta</option>
                        <option value="badge">Píldora / Tag</option>
                        <option value="underline">Subrayado</option>
                        <option value="checkbox_x">Casilla con X</option>
                        <option value="checkbox_check">Casilla con Check</option>
                        <option value="checkbox_bullet">Casilla con Bullet</option>
                        <option value="checkbox_box">Casilla Cuadrado</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] text-slate-400 font-medium mb-1">
                        Marca de Casilla:
                      </label>
                      <select
                        value={selectedField.markStyle || 'NONE'}
                        onChange={(e) => handleUpdateField({ ...selectedField, markStyle: e.target.value as any })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white outline-none focus:border-cyan-400 font-bold"
                      >
                        <option value="NONE">Sin Marca (Texto normal)</option>
                        <option value="X">Marca [X]</option>
                        <option value="CHECK">Marca [✓] Checkmark</option>
                        <option value="BULLET">Marca [●] Punto Relleno</option>
                        <option value="SQUARE_FILL">Marca [■] Cuadro Relleno</option>
                        <option value="CIRCLE_FILL">Marca [⭕] Círculo</option>
                      </select>
                    </div>
                  </div>

                  {/* Corner Pointer selector if callout shape */}
                  {selectedField.shapeType === 'callout_corner' && (
                    <div className="pt-2 border-t border-slate-800">
                      <label className="block text-[10px] text-amber-300 font-bold mb-1">
                        Posición de la Punta / Bisel:
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        {[
                          { id: 'top-left', name: 'Superior Izquierda' },
                          { id: 'top-right', name: 'Superior Derecha' },
                          { id: 'bottom-left', name: 'Inferior Izquierda' },
                          { id: 'bottom-right', name: 'Inferior Derecha' },
                        ].map((pos) => (
                          <button
                            key={pos.id}
                            type="button"
                            onClick={() => handleUpdateField({ ...selectedField, cornerPointer: pos.id as any })}
                            className={`px-2 py-1 text-[10px] font-bold rounded-md border ${
                              selectedField.cornerPointer === pos.id
                                ? 'bg-amber-400 text-slate-950 border-amber-300 font-black'
                                : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800'
                            }`}
                          >
                            {pos.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Exact Dimensions & Coordinates */}
                <div className="space-y-2 bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-black text-cyan-300 uppercase tracking-wide">
                      Posición y Dimensiones
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {unit === 'mm' ? `${pxToMm(selectedField.left)} × ${pxToMm(selectedField.top)} mm` : `${selectedField.left} × ${selectedField.top} px`}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5">X (Izquierda):</label>
                      <input
                        type="number"
                        value={unit === 'mm' ? pxToMm(selectedField.left) : selectedField.left}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          handleUpdateField({ ...selectedField, left: unit === 'mm' ? mmToPx(val) : val });
                        }}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5">Y (Arriba):</label>
                      <input
                        type="number"
                        value={unit === 'mm' ? pxToMm(selectedField.top) : selectedField.top}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          handleUpdateField({ ...selectedField, top: unit === 'mm' ? mmToPx(val) : val });
                        }}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5">Ancho (W):</label>
                      <input
                        type="number"
                        value={unit === 'mm' ? pxToMm(selectedField.width) : selectedField.width}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          handleUpdateField({ ...selectedField, width: Math.max(16, unit === 'mm' ? mmToPx(val) : val) });
                        }}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5">Alto (H):</label>
                      <input
                        type="number"
                        value={unit === 'mm' ? pxToMm(selectedField.height) : selectedField.height}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          handleUpdateField({ ...selectedField, height: Math.max(16, unit === 'mm' ? mmToPx(val) : val) });
                        }}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono font-bold"
                      />
                    </div>
                  </div>

                  {/* Nudge Buttons Pad */}
                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                    <span className="text-[10px] text-slate-400">Micro-Ajuste (1px):</span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleUpdateField({ ...selectedField, left: Math.max(0, selectedField.left - 1) })}
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                        title="1px Izquierda"
                      >
                        <ArrowLeft className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateField({ ...selectedField, top: Math.max(0, selectedField.top - 1) })}
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                        title="1px Arriba"
                      >
                        <ArrowUp className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateField({ ...selectedField, top: Math.min(1123 - selectedField.height, selectedField.top + 1) })}
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                        title="1px Abajo"
                      >
                        <ArrowDown className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateField({ ...selectedField, left: Math.min(794 - selectedField.width, selectedField.left + 1) })}
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                        title="1px Derecha"
                      >
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Typography & Formatting */}
                <div className="space-y-2 bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-black text-cyan-300 uppercase tracking-wide">
                      Tipografía y Texto
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5">Tamaño de Fuente:</label>
                      <input
                        type="number"
                        value={selectedField.fontSize || 12}
                        onChange={(e) => handleUpdateField({ ...selectedField, fontSize: Number(e.target.value) })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono font-bold"
                        min="8"
                        max="36"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5">Interlineado:</label>
                      <input
                        type="number"
                        value={selectedField.lineHeight || 20}
                        onChange={(e) => handleUpdateField({ ...selectedField, lineHeight: Number(e.target.value) })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono font-bold"
                        min="10"
                        max="50"
                      />
                    </div>
                  </div>

                  {/* Alignment & Weight buttons */}
                  <div className="flex items-center justify-between pt-1">
                    <button
                      type="button"
                      onClick={() => handleUpdateField({ ...selectedField, fontWeight: selectedField.fontWeight === 'bold' ? 'normal' : 'bold' })}
                      className={`p-1.5 rounded-lg border text-xs font-bold ${
                        selectedField.fontWeight === 'bold' || selectedField.fontWeight === '900'
                          ? 'bg-blue-600 text-white border-blue-500'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                      title="Negrita"
                    >
                      <Bold className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center bg-slate-900 p-0.5 rounded-lg border border-slate-800">
                      <button
                        type="button"
                        onClick={() => handleUpdateField({ ...selectedField, textAlign: 'left' })}
                        className={`p-1 rounded ${selectedField.textAlign === 'left' || !selectedField.textAlign ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                        title="Izquierda"
                      >
                        <AlignLeft className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateField({ ...selectedField, textAlign: 'center' })}
                        className={`p-1 rounded ${selectedField.textAlign === 'center' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                        title="Centro"
                      >
                        <AlignCenter className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateField({ ...selectedField, textAlign: 'right' })}
                        className={`p-1 rounded ${selectedField.textAlign === 'right' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                        title="Derecha"
                      >
                        <AlignRight className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateField({ ...selectedField, textAlign: 'justify' })}
                        className={`p-1 rounded ${selectedField.textAlign === 'justify' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                        title="Justificar"
                      >
                        <AlignJustify className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Actions: Duplicate & Delete */}
                <div className="pt-2 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleDuplicateField(selectedField)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition"
                  >
                    <Copy className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Duplicar</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDeleteField(selectedField.id)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-300 text-xs font-bold border border-rose-800/60 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Eliminar</span>
                  </button>
                </div>
              </div>
            ) : (
              // --- LIST OF ALL ZONES ---
              <div className="space-y-3">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    placeholder="Buscar zona..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="space-y-1 max-h-[60vh] overflow-y-auto pr-1">
                  {filteredFields.map((field) => (
                    <button
                      key={field.id}
                      type="button"
                      onClick={() => setSelectedFieldId(field.id)}
                      className="w-full text-left p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800/80 border border-slate-800 transition flex items-center justify-between group"
                    >
                      <div className="truncate pr-2">
                        <div className="text-xs font-bold text-slate-200 group-hover:text-cyan-300 truncate">
                          {field.label}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {field.id} • {field.width}×{field.height} px
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-cyan-400 shrink-0" />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </aside>
      </div>

      {/* MODAL DE AUDITORÍA Y COPIADO PARA GEMINI AI */}
      {isGeminiModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-300" />
                <h3 className="text-sm font-black text-white">
                  Paquete de Auditoría para Gemini AI
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsGeminiModalOpen(false)}
                className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 flex-1 overflow-y-auto font-mono text-xs text-slate-300 bg-slate-950/60 whitespace-pre-wrap">
              {generateGeminiAuditPackage(activeDoc, getAllStoredCalibrations())}
            </div>
            <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                Pegue este contenido directamente en el chat con Gemini AI.
              </span>
              <button
                type="button"
                onClick={async () => {
                  await copyGeminiAuditToClipboard(activeDoc, getAllStoredCalibrations());
                  setIsGeminiModalOpen(false);
                  setSaveStatus('📋 ¡Copiado con éxito para Gemini AI!');
                }}
                className="px-4 py-2 bg-gradient-to-r from-purple-600 to-cyan-600 text-white rounded-xl text-xs font-black"
              >
                Copiar al Portapapeles
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE VISUALIZACIÓN DE ARCHIVOS PDF / IMAGEN ORIGINALES */}
      <OriginalPdfViewerModal
        isOpen={isOriginalPdfModalOpen}
        onClose={() => setIsOriginalPdfModalOpen(false)}
        initialDoc={activeDoc}
      />
    </div>
  );
};

// ============================================================================
// SUB-COMPONENT: INTERACTIVE DRAGGABLE & RESIZABLE BOUNDING BOX (WITH SHAPES)
// ============================================================================
interface ZoneBoundingBoxProps {
  field: FieldCalibration;
  isSelected: boolean;
  onSelect: () => void;
  onChange: (updated: FieldCalibration) => void;
  onDelete: () => void;
  onDuplicate: () => void;
  unit: 'px' | 'mm';
  snapToGrid?: boolean;
}

const ZoneBoundingBox: React.FC<ZoneBoundingBoxProps> = ({
  field,
  isSelected,
  onSelect,
  onChange,
  onDelete,
  onDuplicate,
  unit,
  snapToGrid = false,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [resizeHandle, setResizeHandle] = useState<string | null>(null);

  const dragStartRef = useRef<{
    clientX: number;
    clientY: number;
    initialTop: number;
    initialLeft: number;
    initialWidth: number;
    initialHeight: number;
  }>({
    clientX: 0,
    clientY: 0,
    initialTop: 0,
    initialLeft: 0,
    initialWidth: 0,
    initialHeight: 0,
  });

  // Handle Box Drag
  const handleMouseDownBox = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelect();

    dragStartRef.current = {
      clientX: e.clientX,
      clientY: e.clientY,
      initialTop: field.top,
      initialLeft: field.left,
      initialWidth: field.width,
      initialHeight: field.height,
    };

    setIsDragging(true);
  };

  // Handle Resize Mouse Down on Specific Handle
  const handleMouseDownHandle = (e: React.MouseEvent, handle: string) => {
    e.stopPropagation();
    onSelect();

    dragStartRef.current = {
      clientX: e.clientX,
      clientY: e.clientY,
      initialTop: field.top,
      initialLeft: field.left,
      initialWidth: field.width,
      initialHeight: field.height,
    };

    setResizeHandle(handle);
  };

  useEffect(() => {
    if (!isDragging && !resizeHandle) return;

    const handleMouseMove = (e: MouseEvent) => {
      const dx = e.clientX - dragStartRef.current.clientX;
      const dy = e.clientY - dragStartRef.current.clientY;

      if (isDragging) {
        let newLeft = Math.round(dragStartRef.current.initialLeft + dx);
        let newTop = Math.round(dragStartRef.current.initialTop + dy);

        if (snapToGrid) {
          newLeft = Math.round(newLeft / 10) * 10;
          newTop = Math.round(newTop / 10) * 10;
        }

        newLeft = Math.max(0, Math.min(794 - field.width, newLeft));
        newTop = Math.max(0, Math.min(1123 - field.height, newTop));

        onChange({
          ...field,
          left: newLeft,
          top: newTop,
        });
      } else if (resizeHandle) {
        let newTop = dragStartRef.current.initialTop;
        let newLeft = dragStartRef.current.initialLeft;
        let newWidth = dragStartRef.current.initialWidth;
        let newHeight = dragStartRef.current.initialHeight;

        if (resizeHandle.includes('e')) {
          newWidth = Math.max(16, Math.min(794 - newLeft, dragStartRef.current.initialWidth + dx));
        }
        if (resizeHandle.includes('s')) {
          newHeight = Math.max(16, Math.min(1123 - newTop, dragStartRef.current.initialHeight + dy));
        }
        if (resizeHandle.includes('w')) {
          const possibleW = dragStartRef.current.initialWidth - dx;
          if (possibleW >= 16) {
            newLeft = Math.max(0, dragStartRef.current.initialLeft + dx);
            newWidth = possibleW;
          }
        }
        if (resizeHandle.includes('n')) {
          const possibleH = dragStartRef.current.initialHeight - dy;
          if (possibleH >= 16) {
            newTop = Math.max(0, dragStartRef.current.initialTop + dy);
            newHeight = possibleH;
          }
        }

        onChange({
          ...field,
          top: Math.round(newTop),
          left: Math.round(newLeft),
          width: Math.round(newWidth),
          height: Math.round(newHeight),
        });
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setResizeHandle(null);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, resizeHandle, field, onChange, snapToGrid]);

  // Forma visual dinámica
  const isCircle = field.shapeType === 'circle';
  const isCallout = field.shapeType === 'callout_corner';
  const isUnderline = field.shapeType === 'underline';

  return (
    <div
      onMouseDown={handleMouseDownBox}
      className={`absolute transition-colors cursor-move select-none group/box ${
        isSelected
          ? 'ring-2 ring-blue-600 bg-blue-500/15 z-20 shadow-md'
          : 'border border-dashed border-blue-500/60 bg-blue-500/5 hover:border-blue-600 hover:bg-blue-500/10 z-10'
      }`}
      style={{
        top: `${field.top}px`,
        left: `${field.left}px`,
        width: `${field.width}px`,
        height: `${field.height}px`,
        boxSizing: 'border-box',
        borderRadius: isCircle ? '999px' : (field.borderRadius ? `${field.borderRadius}px` : undefined),
        borderBottom: isUnderline ? '2px solid #0284c7' : undefined,
      }}
    >
      {/* Indicador de punta en esquina para callout */}
      {isCallout && (
        <div 
          className={`absolute w-3 h-3 bg-amber-400 rotate-45 pointer-events-none z-20 ${
            field.cornerPointer === 'top-right' ? '-top-1.5 -right-1.5' :
            field.cornerPointer === 'bottom-left' ? '-bottom-1.5 -left-1.5' :
            field.cornerPointer === 'bottom-right' ? '-bottom-1.5 -right-1.5' :
            '-top-1.5 -left-1.5'
          }`}
        />
      )}

      {/* Label Badge on Top */}
      <div 
        className={`absolute -top-4 left-0 z-30 px-1.5 py-0.2 rounded text-[8px] font-black uppercase tracking-wider whitespace-nowrap shadow-xs pointer-events-none transition-all flex items-center gap-1 ${
          isSelected 
            ? 'bg-blue-700 text-white opacity-100' 
            : 'bg-blue-100 text-blue-900 border border-blue-300/80 opacity-70 group-hover/box:opacity-100'
        }`}
      >
        <span>{field.label}</span>
        {field.markStyle && field.markStyle !== 'NONE' && (
          <span className="bg-amber-400 text-slate-950 px-1 rounded font-black">[{field.markStyle}]</span>
        )}
      </div>

      {/* Preview Mark inside Box */}
      {field.markStyle && field.markStyle !== 'NONE' && (
        <div className="w-full h-full flex items-center justify-center font-black text-blue-900 pointer-events-none opacity-80" style={{ fontSize: `${field.fontSize || 14}px` }}>
          {field.markStyle === 'X' ? 'X' :
           field.markStyle === 'CHECK' ? '✓' :
           field.markStyle === 'BULLET' ? '●' :
           field.markStyle === 'SQUARE_FILL' ? '■' :
           field.markStyle === 'CIRCLE_FILL' ? '⭕' : ''}
        </div>
      )}

      {/* Selected Action floating bar & coordinates badge */}
      {isSelected && (
        <>
          {/* Coordinates Pill Bottom */}
          <div className="absolute -bottom-4 right-0 z-30 px-1 py-0.2 rounded text-[8px] font-mono font-bold bg-slate-900 text-cyan-300 pointer-events-none shadow-xs whitespace-nowrap">
            {unit === 'mm' ? `${pxToMm(field.left)}, ${pxToMm(field.top)} mm` : `${field.left}, ${field.top} px`}
          </div>

          {/* Quick Floating Actions (Top Right) */}
          <div className="absolute -top-6 right-0 z-30 flex items-center gap-1 bg-slate-900/95 border border-slate-700 p-0.5 rounded-md shadow-lg">
            <button
              type="button"
              onMouseDown={(e) => {
                e.stopPropagation();
                onDuplicate();
              }}
              className="p-0.5 text-slate-300 hover:text-cyan-300 rounded hover:bg-slate-800 cursor-pointer"
              title="Duplicar"
            >
              <Copy className="w-2.5 h-2.5" />
            </button>
            <button
              type="button"
              onMouseDown={(e) => {
                e.stopPropagation();
                onDelete();
              }}
              className="p-0.5 text-slate-300 hover:text-rose-400 rounded hover:bg-slate-800 cursor-pointer"
              title="Eliminar"
            >
              <Trash2 className="w-2.5 h-2.5" />
            </button>
          </div>

          {/* 8-POINT RESIZE HANDLES */}
          <div onMouseDown={(e) => handleMouseDownHandle(e, 'nw')} className="absolute -top-1.5 -left-1.5 w-3 h-3 bg-white border-2 border-blue-700 rounded-xs cursor-nwse-resize z-30 shadow-xs" />
          <div onMouseDown={(e) => handleMouseDownHandle(e, 'n')} className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-white border-2 border-blue-700 rounded-xs cursor-ns-resize z-30 shadow-xs" />
          <div onMouseDown={(e) => handleMouseDownHandle(e, 'ne')} className="absolute -top-1.5 -right-1.5 w-3 h-3 bg-white border-2 border-blue-700 rounded-xs cursor-nesw-resize z-30 shadow-xs" />
          <div onMouseDown={(e) => handleMouseDownHandle(e, 'e')} className="absolute top-1/2 -translate-y-1/2 -right-1.5 w-3 h-3 bg-white border-2 border-blue-700 rounded-xs cursor-ew-resize z-30 shadow-xs" />
          <div onMouseDown={(e) => handleMouseDownHandle(e, 'se')} className="absolute -bottom-1.5 -right-1.5 w-3 h-3 bg-white border-2 border-blue-700 rounded-xs cursor-nwse-resize z-30 shadow-xs" />
          <div onMouseDown={(e) => handleMouseDownHandle(e, 's')} className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-white border-2 border-blue-700 rounded-xs cursor-ns-resize z-30 shadow-xs" />
          <div onMouseDown={(e) => handleMouseDownHandle(e, 'sw')} className="absolute -bottom-1.5 -left-1.5 w-3 h-3 bg-white border-2 border-blue-700 rounded-xs cursor-nesw-resize z-30 shadow-xs" />
          <div onMouseDown={(e) => handleMouseDownHandle(e, 'w')} className="absolute top-1/2 -translate-y-1/2 -left-1.5 w-3 h-3 bg-white border-2 border-blue-700 rounded-xs cursor-ew-resize z-30 shadow-xs" />
        </>
      )}
    </div>
  );
};
