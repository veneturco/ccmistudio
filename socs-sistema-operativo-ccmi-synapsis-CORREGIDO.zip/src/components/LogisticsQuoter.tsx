import React, { useState } from 'react';
import { 
  Calculator, 
  Plus, 
  Trash2, 
  Printer, 
  FileCheck, 
  Search, 
  Boxes, 
  DollarSign, 
  Percent, 
  ArrowRight,
  ShieldCheck,
  Building2,
  FileSpreadsheet
} from 'lucide-react';
import { LogisticsItem, QuoteLineItem } from '../types';
import { BrandLogo } from './BrandLogo';

// Catálogo base de insumos y equipos Synapsis
const INVENTORY_CATALOG: LogisticsItem[] = [
  { id: 'inv_1', sku: 'SYN-BIO-01', name: 'Malla Quirúrgica de Polipropileno 15x15cm', category: 'Biomateriales', stock: 24, unitPriceUsd: 85.00 },
  { id: 'inv_2', sku: 'SYN-BIO-02', name: 'Sutura Monofilamento Polidioxanona 3-0 (Caja x 12)', category: 'Biomateriales', stock: 40, unitPriceUsd: 48.50 },
  { id: 'inv_3', sku: 'SYN-EQU-01', name: 'Kit Descartable Laparoscópico Trocar 5mm/10mm', category: 'Instrumental Quirúrgico', stock: 15, unitPriceUsd: 140.00 },
  { id: 'inv_4', sku: 'SYN-EQU-02', name: 'Pinza Bipolar Electrobisturí Reusable CcMi', category: 'Instrumental Quirúrgico', stock: 8, unitPriceUsd: 290.00 },
  { id: 'inv_5', sku: 'SYN-FAR-01', name: 'Anestésico Bupivacaína 0.5% Pesada (Ampollas x 5)', category: 'Fármacos', stock: 60, unitPriceUsd: 32.00 },
  { id: 'inv_6', sku: 'SYN-FAR-02', name: 'Ceftriaxona 1g Frasco Ampolla IV', category: 'Fármacos', stock: 120, unitPriceUsd: 12.00 },
  { id: 'inv_7', sku: 'SYN-DES-01', name: 'Bata Quirúrgica Impermeable Nivel 3 (Pack x 10)', category: 'Descartables', stock: 85, unitPriceUsd: 22.00 },
  { id: 'inv_8', sku: 'SYN-DES-02', name: 'Guantes Estériles Quirúrgicos Sin Látex 7.5 (Caja)', category: 'Descartables', stock: 110, unitPriceUsd: 18.00 },
];

export const LogisticsQuoter: React.FC = () => {
  const [recipient, setRecipient] = useState({
    name: 'Clínica Santa Sofía / Depto. Compras Médicas',
    rif: 'J-30491820-1',
    attentionTo: 'Dr. Samir Moucharrafie (Referencia de Cirugía)',
    validDays: '15 días hábiles',
  });

  const [selectedItems, setSelectedItems] = useState<QuoteLineItem[]>([
    { id: 'line_1', item: INVENTORY_CATALOG[0], quantity: 2, discountPct: 0 },
    { id: 'line_2', item: INVENTORY_CATALOG[2], quantity: 1, discountPct: 5 },
    { id: 'line_3', item: INVENTORY_CATALOG[4], quantity: 3, discountPct: 0 },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [taxRate, setTaxRate] = useState<number>(16); // IVA 16%
  const [showQuotePdfPreview, setShowQuotePdfPreview] = useState(false);

  // Cálculos de Cotización
  const subtotal = selectedItems.reduce((acc, curr) => {
    const itemTotal = curr.item.unitPriceUsd * curr.quantity;
    const discount = (itemTotal * curr.discountPct) / 100;
    return acc + (itemTotal - discount);
  }, 0);

  const taxAmount = (subtotal * taxRate) / 100;
  const grandTotal = subtotal + taxAmount;

  const addItemToQuote = (item: LogisticsItem) => {
    const existingIndex = selectedItems.findIndex((l) => l.item.id === item.id);
    if (existingIndex > -1) {
      const updated = [...selectedItems];
      updated[existingIndex].quantity += 1;
      setSelectedItems(updated);
    } else {
      setSelectedItems([
        ...selectedItems,
        {
          id: `line_${Date.now()}`,
          item,
          quantity: 1,
          discountPct: 0,
        },
      ]);
    }
  };

  const removeLineItem = (id: string) => {
    setSelectedItems(selectedItems.filter((l) => l.id !== id));
  };

  const updateQuantity = (id: string, qty: number) => {
    setSelectedItems(
      selectedItems.map((l) => (l.id === id ? { ...l, quantity: Math.max(1, qty) } : l))
    );
  };

  const filteredCatalog = INVENTORY_CATALOG.filter(
    (item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div id="synapsis-quoter-module" className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 p-1 flex items-center justify-center shrink-0 shadow-sm">
            <BrandLogo size={38} />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              Cotizador Automatizado e Inventarios Synapsis
              <span className="px-2 py-0.5 text-[11px] font-semibold bg-slate-100 text-slate-700 rounded-full border border-slate-300 font-mono">
                Módulo Logístico SOCS
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              Cruza requerimientos de cirugías e insumos con la base de precios para emitir presupuestos institucionales en PDF.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowQuotePdfPreview(true)}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-sm flex items-center gap-2 transition cursor-pointer"
        >
          <Printer className="w-4 h-4" />
          <span>Ver Presupuesto PDF</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Target Client & Active Line Items */}
        <div className="lg:col-span-8 space-y-6">
          {/* Client Details Box */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-blue-600" />
              1. Datos del Cliente / Centro Quirúrgico
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-600">Razón Social o Institución</label>
                <input
                  type="text"
                  value={recipient.name}
                  onChange={(e) => setRecipient({ ...recipient, name: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-600">RIF / Identificación Fiscal</label>
                <input
                  type="text"
                  value={recipient.rif}
                  onChange={(e) => setRecipient({ ...recipient, rif: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-600">Atención a / Médico Solicitante</label>
                <input
                  type="text"
                  value={recipient.attentionTo}
                  onChange={(e) => setRecipient({ ...recipient, attentionTo: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-600">Validez de la Oferta</label>
                <input
                  type="text"
                  value={recipient.validDays}
                  onChange={(e) => setRecipient({ ...recipient, validDays: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                />
              </div>
            </div>
          </div>

          {/* Active Items Table */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <FileSpreadsheet className="w-3.5 h-3.5 text-blue-600" />
                2. Partidas del Presupuesto ({selectedItems.length})
              </h3>
              <span className="text-xs text-slate-500 font-mono">Moneda: USD (Tasa Oficial BCV)</span>
            </div>

            {selectedItems.length === 0 ? (
              <div className="p-8 text-center border-2 border-dashed border-slate-200 rounded-xl">
                <p className="text-xs text-slate-500">No hay insumos añadidos. Seleccione ítems del catálogo lateral.</p>
              </div>
            ) : (
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Descripción / SKU</th>
                      <th className="py-2.5 px-3 w-20 text-center">Cant.</th>
                      <th className="py-2.5 px-3 w-24 text-right">P. Unit.</th>
                      <th className="py-2.5 px-3 w-24 text-right">Total</th>
                      <th className="py-2.5 px-2 w-10 text-center"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {selectedItems.map((line) => {
                      const lineTotal = line.item.unitPriceUsd * line.quantity;
                      return (
                        <tr key={line.id} className="hover:bg-slate-50/50">
                          <td className="py-2.5 px-3">
                            <span className="font-semibold text-slate-900 block">{line.item.name}</span>
                            <span className="text-[11px] font-mono text-slate-400">
                              {line.item.sku} • {line.item.category}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <input
                              type="number"
                              min="1"
                              value={line.quantity}
                              onChange={(e) => updateQuantity(line.id, parseInt(e.target.value) || 1)}
                              aria-label={`Cantidad para ${line.item.name}`}
                              className="w-14 text-center px-1.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-800"
                            />
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-slate-700">
                            ${line.item.unitPriceUsd.toFixed(2)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                            ${lineTotal.toFixed(2)}
                          </td>
                          <td className="py-2.5 px-2 text-center">
                            <button
                              type="button"
                              onClick={() => removeLineItem(line.id)}
                              aria-label={`Eliminar ${line.item.name} del presupuesto`}
                              className="p-1 text-slate-400 hover:text-rose-600 transition cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Calculations Summary */}
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-2">
              <div className="flex justify-between text-xs text-slate-600">
                <span>Subtotal Partidas:</span>
                <span className="font-mono font-semibold">${subtotal.toFixed(2)} USD</span>
              </div>
              <div className="flex justify-between items-center text-xs text-slate-600">
                <span className="flex items-center gap-1">
                  Impuesto (IVA):
                  <input
                    type="number"
                    value={taxRate}
                    onChange={(e) => setTaxRate(Number(e.target.value))}
                    aria-label="Porcentaje de IVA"
                    className="w-12 text-center py-0.5 px-1 bg-white border border-slate-200 rounded text-xs font-bold"
                  />
                  %
                </span>
                <span className="font-mono font-semibold">${taxAmount.toFixed(2)} USD</span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-between text-sm font-bold text-slate-900">
                <span>Total Presupuesto Synapsis:</span>
                <span className="font-mono text-blue-700 text-base">${grandTotal.toFixed(2)} USD</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Catalog & Quick Add */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Boxes className="w-3.5 h-3.5 text-blue-600" />
              Catálogo de Inventario
            </h3>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar insumo o código SKU..."
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20"
              />
            </div>

            {/* Catalog List */}
            <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {filteredCatalog.map((item) => (
                <div
                  key={item.id}
                  className="p-3 bg-slate-50 hover:bg-blue-50/50 border border-slate-200 hover:border-blue-300 rounded-xl transition flex items-center justify-between gap-2"
                >
                  <div className="space-y-0.5">
                    <h4 className="text-xs font-bold text-slate-900 leading-snug">{item.name}</h4>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono">
                      <span>{item.sku}</span>
                      <span>•</span>
                      <span className="text-emerald-700 font-semibold">{item.stock} en stock</span>
                    </div>
                    <span className="text-xs font-bold text-blue-800 font-mono block">
                      ${item.unitPriceUsd.toFixed(2)} USD
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => addItemToQuote(item)}
                    aria-label={`Añadir ${item.name} al presupuesto`}
                    className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition shrink-0 cursor-pointer shadow-sm"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Quote PDF Modal Simulator */}
      {showQuotePdfPreview && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-400" />
                <h3 className="font-bold text-sm">Presupuesto Comercial Synapsis / CcMi</h3>
              </div>
              <button
                onClick={() => setShowQuotePdfPreview(false)}
                className="text-slate-400 hover:text-white text-xs cursor-pointer font-bold"
              >
                Cerrar
              </button>
            </div>

            <div className="p-8 space-y-6 text-xs text-slate-800">
              <div className="flex justify-between items-start border-b pb-4">
                <div className="flex items-center gap-4">
                  <div className="p-1 bg-white rounded-xl border border-slate-200 shadow-xs shrink-0">
                    <BrandLogo size={46} />
                  </div>
                  <div>
                    <h2 className="text-lg font-black text-slate-900 uppercase tracking-tight">SYNAPSIS LOGÍSTICA C.A.</h2>
                    <p className="text-slate-600 font-medium">División de Equipos y Biomateriales Quirúrgicos • CcMi</p>
                    <p className="font-mono text-[11px] text-slate-400">RIF: J-40892102-9 • Caracas, Venezuela</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono font-bold text-blue-700 block">COTIZACIÓN #SYN-2026-089</span>
                  <span className="text-slate-500">Fecha: {new Date().toLocaleDateString('es-VE')}</span>
                </div>
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border">
                <span className="block font-bold text-slate-900">Cliente: {recipient.name}</span>
                <span className="block text-slate-600">RIF: {recipient.rif}</span>
                <span className="block text-slate-600">Atención: {recipient.attentionTo}</span>
              </div>

              <table className="w-full border text-left">
                <thead className="bg-slate-100 font-bold border-b">
                  <tr>
                    <th className="p-2">Ítem</th>
                    <th className="p-2 text-center">Cant.</th>
                    <th className="p-2 text-right">Unitario</th>
                    <th className="p-2 text-right">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {selectedItems.map((l, idx) => (
                    <tr key={idx}>
                      <td className="p-2 font-medium">{l.item.name}</td>
                      <td className="p-2 text-center">{l.quantity}</td>
                      <td className="p-2 text-right font-mono">${l.item.unitPriceUsd.toFixed(2)}</td>
                      <td className="p-2 text-right font-mono font-bold">${(l.item.unitPriceUsd * l.quantity).toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="flex justify-end">
                <div className="w-64 space-y-1 text-right">
                  <div>Subtotal: <strong className="font-mono">${subtotal.toFixed(2)} USD</strong></div>
                  <div>IVA ({taxRate}%): <strong className="font-mono">${taxAmount.toFixed(2)} USD</strong></div>
                  <div className="text-base font-bold text-blue-800 border-t pt-1">
                    Total: <span className="font-mono">${grandTotal.toFixed(2)} USD</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="px-6 py-3 bg-slate-50 border-t flex justify-between items-center">
              <span className="text-[11px] text-slate-500">Documento con validez de {recipient.validDays}</span>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowQuotePdfPreview(false)}
                  className="px-3 py-1.5 text-xs font-semibold bg-white border border-slate-200 rounded-lg cursor-pointer"
                >
                  Volver
                </button>
                <button
                  onClick={() => window.print()}
                  className="px-4 py-1.5 text-xs font-bold text-white bg-blue-600 rounded-lg cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Imprimir PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
