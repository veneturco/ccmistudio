export type DocumentType = 'recipe' | 'report' | 'lab_order' | 'certificate' | 'history';

export type DocType = 
  | 'RECIPES' 
  | 'INFORME' 
  | 'ORDEN_LAB' 
  | 'CONSTANCIA' 
  | 'HISTORIA';

export interface PatientData {
  fullName: string;
  idNumber: string;
  age: string;
  date: string;
  phone: string;
  address?: string;
  guideNumber?: string;
  condition?: 'Paciente' | 'Familiar';
}

export interface PatientInfo {
  fullName: string;
  idType: 'V' | 'E' | 'P';
  nationalId: string;
  age: string;
  gender: 'M' | 'F';
  allergies: string;
  phone?: string;
  email?: string;
}

export interface MedicationItem {
  id: string;
  drug: string;
  dose: string;
  frequency: string;
  duration: string;
  instructions?: string;
}

export interface StructuredClinicalData {
  diagnosisPrincipal: string;
  secondaryDiagnoses: string[];
  cie10Suggestions?: string[];
  medications: MedicationItem[];
  generalIndications: string[];
  restDays?: number;
  restStartDate?: string;
  labTests?: string[];
  summaryNote: string;
}

export interface ProcessedDocumentResult {
  id: string;
  docNumber: string;
  documentType: DocumentType;
  patient: PatientInfo;
  structuredData: StructuredClinicalData;
  templateName: string;
  googleDriveFileId: string;
  googleDocUrl: string;
  pdfExportUrl: string;
  generatedAt: string;
  doctorName: string;
  doctorRegistration: string;
}

export interface LogisticsItem {
  id: string;
  sku: string;
  name: string;
  category: 'Biomateriales' | 'Instrumental Quirúrgico' | 'Fármacos' | 'Descartables';
  stock: number;
  unitPriceUsd: number;
}

export interface QuoteLineItem {
  id: string;
  item: LogisticsItem;
  quantity: number;
  discountPct: number;
}

export interface LogisticsQuote {
  id: string;
  quoteNumber: string;
  recipientName: string;
  rif: string;
  doctorReference: string;
  date: string;
  validUntil: string;
  items: QuoteLineItem[];
  taxRate: number;
  observations: string;
}

export type ActiveNavTab = 
  | 'cmi-portal'
  | 'official-sheet'
  | 'clinic-form' 
  | 'clinic-history' 
  | 'synapsis-quoter' 
  | 'synapsis-inventory'
  | 'settings-templates';
