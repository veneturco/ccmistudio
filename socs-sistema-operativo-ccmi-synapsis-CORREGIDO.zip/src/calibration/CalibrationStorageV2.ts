/**
 * CalibrationStorageV2.ts
 * 
 * CAPA DE ALMACENAMIENTO Y AUTORIDAD DE CALIBRACIÓN V2
 * ====================================================
 * Jerarquía estricta de autoridad:
 * 1. MasterTemplateV2 oficial inmutable (código fuente / JSON canónico)
 * 2. Versión validada del sistema
 * 3. Configuración de aplicación
 * 4. localStorage ÚNICAMENTE como caché / preferencias temporales de UI
 * 
 * REGLAS FUNDAMENTALES:
 * - localStorage NO debe convertirse en autoridad final de coordenadas oficiales.
 * - NO permitir que una calibración antigua sobrescriba silenciosamente una nueva.
 * - Manejo explícito de versionado: masterId, version, timestamp, status.
 */

import { MasterTemplateV2 } from './types/MasterTemplateV2';
import { TemplateRegistry } from './TemplateRegistry';

export interface CalibrationStorageSnapshot {
  masterId: string;
  version: string;
  timestamp: string;
  status: 'DRAFT' | 'CALIBRATED' | 'VALIDATED' | 'LOCKED' | 'REQUIRES_CALIBRATION';
  customOverrides?: Partial<MasterTemplateV2>;
}

const STORAGE_PREFIX = 'ccmi_calibration_v2_';

export class CalibrationStorageV2 {
  /**
   * Resuelve la plantilla autoritativa respetando la jerarquía.
   * La autoridad primaria es el MasterTemplateV2 oficial.
   */
  public static getAuthoritativeTemplate(identifier: string): MasterTemplateV2 | undefined {
    const canonicalTemplate = TemplateRegistry.get(identifier);
    if (!canonicalTemplate) return undefined;

    // Si el master está bloqueado (LOCKED) o validado (VALIDATED), la autoridad es absoluta
    if (canonicalTemplate.status === 'LOCKED' || canonicalTemplate.status === 'VALIDATED') {
      return canonicalTemplate;
    }

    // Si está en desarrollo (DRAFT / CALIBRATED), se revisa si hay snapshot local más reciente
    // sin permitir degradación de versión
    try {
      const cached = this.getUiCacheSnapshot(canonicalTemplate.masterId);
      if (cached && cached.version >= canonicalTemplate.version && cached.customOverrides) {
        return {
          ...canonicalTemplate,
          ...cached.customOverrides,
          status: cached.status as any,
        };
      }
    } catch {
      // Ignorar errores de localStorage y devolver el canónico
    }

    return canonicalTemplate;
  }

  /**
   * Guarda una instantánea de desarrollo en localStorage (preferencias de UI)
   */
  public static saveUiCacheSnapshot(
    template: MasterTemplateV2,
    overrides?: Partial<MasterTemplateV2>
  ): void {
    if (!template || !template.masterId) return;

    // Prohibido sobrescribir plantillas LOCKED con copias inferiores
    if (template.status === 'LOCKED') {
      return;
    }

    try {
      const snapshot: CalibrationStorageSnapshot = {
        masterId: template.masterId,
        version: template.version,
        timestamp: new Date().toISOString(),
        status: (template.status as any) || 'CALIBRATED',
        customOverrides: overrides,
      };
      localStorage.setItem(`${STORAGE_PREFIX}${template.masterId}`, JSON.stringify(snapshot));
    } catch {
      // Manejo silencioso en entornos restringidos
    }
  }

  /**
   * Lee la instantánea de UI desde localStorage
   */
  public static getUiCacheSnapshot(masterId: string): CalibrationStorageSnapshot | null {
    try {
      const raw = localStorage.getItem(`${STORAGE_PREFIX}${masterId}`);
      if (!raw) return null;
      return JSON.parse(raw) as CalibrationStorageSnapshot;
    } catch {
      return null;
    }
  }

  /**
   * Limpia la caché local de UI para restaurar el master oficial inmutable
   */
  public static clearUiCache(masterId?: string): void {
    try {
      if (masterId) {
        localStorage.removeItem(`${STORAGE_PREFIX}${masterId}`);
      } else {
        const keysToRemove: string[] = [];
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k && k.startsWith(STORAGE_PREFIX)) {
            keysToRemove.push(k);
          }
        }
        keysToRemove.forEach((k) => localStorage.removeItem(k));
      }
    } catch {
      // Ignorar
    }
  }
}
