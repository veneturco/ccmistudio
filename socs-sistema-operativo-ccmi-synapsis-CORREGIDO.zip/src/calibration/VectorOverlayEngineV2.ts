/**
 * VectorOverlayEngineV2.ts
 * 
 * MOTOR UNIVERSAL DE RENDERIZADO VECTORIAL OVERLAY (ARQUITECTURA V2)
 * ===================================================================
 * REGLAS FUNDAMENTALES:
 * 1. PDF MAESTRO INMUTABLE: Se utiliza como background original no rasterizado.
 * 2. OVERLAY VECTORIAL PURO: El texto, marcas y firmas se inyectan como streams vectoriales nativos.
 * 3. NO INVENCIÓN DE DATOS: Si un dato no existe, no se inyecta nada ni se inventa contenido.
 * 4. PROTECCIÓN DE REGIONES BLOQUEADAS: Detecta colisiones geométricas con membretes o sellos.
 * 5. AUTOAJUSTE TIPOGRÁFICO: Aplica Shrink-to-fit o advertencia de revisión sin truncamiento destructivo.
 */

import { PDFDocument, PDFPage, PDFFont, rgb } from 'pdf-lib';
import {
  MasterTemplateV2,
  PageTemplate,
  OverlayElement,
  TextElement,
  MultilineTextElement,
  CheckboxElement,
  StampElement,
  SignatureElement,
  ImageElement,
  LineElement,
  LockedRegion,
  ElementGeometry,
} from './types/MasterTemplateV2';
import { CalibrationEngine } from './CalibrationEngine';
import { DataResolver } from './DataResolver';

export interface OverlayRenderOptions {
  doctorStampBase64?: string;
  signatureBase64?: string;
  debugOverlay?: boolean;
  debugMode?: boolean;
}

export interface OverlayRenderResult {
  pdfBytes: Uint8Array;
  requiresReview: boolean;
  warnings: string[];
  injectedElementsCount: number;
}

export class VectorOverlayEngineV2 {
  /**
   * Resuelve el valor semántico a partir de una clave con notación de puntos
   * Ej: 'patient.fullName' -> data.patient?.fullName
   */
  public static resolveDataKey(data: Record<string, any>, key: string): any {
    if (!data || !key) return undefined;
    return DataResolver.resolve(data, key);
  }

  /**
   * Comprueba si una geometría colisiona con alguna región bloqueada
   */
  public static checkCollision(
    geom: ElementGeometry,
    lockedRegions: LockedRegion[] = []
  ): { collides: boolean; regionId?: string } {
    for (const region of lockedRegions) {
      const xOverlap = Math.max(0, Math.min(geom.xMm + geom.widthMm, region.xMm + region.widthMm) - Math.max(geom.xMm, region.xMm));
      const yOverlap = Math.max(0, Math.min(geom.yMm + geom.heightMm, region.yMm + region.heightMm) - Math.max(geom.yMm, region.yMm));
      if (xOverlap > 0.5 && yOverlap > 0.5) {
        return { collides: true, regionId: region.id };
      }
    }
    return { collides: false };
  }

  /**
   * Aplica un MasterTemplateV2 con datos semánticos sobre un PDF original
   */
  public static async applyOverlay(
    originalPdfBytes: Uint8Array,
    template: MasterTemplateV2,
    patientData: Record<string, any>,
    options: OverlayRenderOptions = {}
  ): Promise<OverlayRenderResult> {
    const pdfDoc = await PDFDocument.load(originalPdfBytes);
    const fontRegular = await pdfDoc.embedFont('Helvetica');
    const fontBold = await pdfDoc.embedFont('Helvetica-Bold');

    const warnings: string[] = [];
    let requiresReview = false;
    let injectedElementsCount = 0;

    // Embeber sello/firma si está disponible en opciones
    let embeddedStampImage: any = null;
    if (options.doctorStampBase64) {
      try {
        const cleanBase64 = options.doctorStampBase64.replace(/^data:image\/\w+;base64,/, '');
        const imageBytes = Uint8Array.from(atob(cleanBase64), (c) => c.charCodeAt(0));
        embeddedStampImage = options.doctorStampBase64.includes('image/png')
          ? await pdfDoc.embedPng(imageBytes)
          : await pdfDoc.embedJpg(imageBytes);
      } catch (err: any) {
        warnings.push(`No se pudo embeber el sello del médico: ${err.message}`);
      }
    }

    const pages = pdfDoc.getPages();

    for (const pageTemplate of template.pages) {
      if (pageTemplate.pageIndex >= pages.length) {
        warnings.push(`Página ${pageTemplate.pageIndex + 1} no existe en el PDF base (total páginas: ${pages.length}).`);
        continue;
      }

      const page = pages[pageTemplate.pageIndex];
      const actualPageWidthPt = page.getWidth();
      const actualPageHeightPt = page.getHeight();
      const actualPageWidthMm = (actualPageWidthPt * 25.4) / 72;
      const actualPageHeightMm = (actualPageHeightPt * 25.4) / 72;

      // Validación estricta de dimensiones físicas reales vs MasterTemplateV2
      const widthDiffMm = Math.abs(pageTemplate.widthMm - actualPageWidthMm);
      const heightDiffMm = Math.abs(pageTemplate.heightMm - actualPageHeightMm);
      const DIMENSION_TOLERANCE_MM = 3.0;

      if (widthDiffMm > DIMENSION_TOLERANCE_MM || heightDiffMm > DIMENSION_TOLERANCE_MM) {
        const errorMsg = `[VectorOverlayEngineV2] ERROR CRÍTICO DE DIMENSIÓN DEL MASTER: La página ${pageTemplate.pageIndex + 1} del PDF base mide ${actualPageWidthMm.toFixed(1)} × ${actualPageHeightMm.toFixed(1)} mm (${actualPageWidthPt.toFixed(1)} × ${actualPageHeightPt.toFixed(1)} pt), pero el MasterTemplateV2 '${template.masterId}' exige ${pageTemplate.widthMm.toFixed(1)} × ${pageTemplate.heightMm.toFixed(1)} mm. Está terminantemente prohibido estampar sobre un PDF con dimensiones incompatibles (ej. A4 en vez de Media Carta).`;
        console.error(errorMsg);
        warnings.push(errorMsg);
        requiresReview = true;
        if (template.documentType === 'lab_order') {
          throw new Error(errorMsg);
        }
      }

      // La altura física real de la página para la transformación top-down a bottom-up
      const pageHeightMm = actualPageHeightMm;
      const combinedLockedRegions = [
        ...(template.lockedRegions || []),
        ...(pageTemplate.lockedRegions || []),
      ];

      for (const element of pageTemplate.elements) {
        switch (element.type) {
          case 'text': {
            const rawVal = VectorOverlayEngineV2.resolveDataKey(patientData, element.dataKey);
            if (rawVal === undefined || rawVal === null || String(rawVal).trim() === '') {
              break;
            }
            const textToDraw = element.labelPrefix ? `${element.labelPrefix}${String(rawVal).trim()}` : String(rawVal).trim();
            const font = element.typography?.fontWeight === 'bold' ? fontBold : fontRegular;
            let fontSize = element.typography?.fontSizePt || 9.5;

            // Autoajuste si desborda
            const maxChars = Math.max(1, Math.floor(element.geometry.widthMm / ((fontSize * 0.52) * 0.352778)));
            if (element.overflow === 'shrink' && textToDraw.length > maxChars) {
              const shrinkRes = CalibrationEngine.calculateShrinkFontSize(textToDraw, element.geometry.heightMm, fontSize, 7.5, element.geometry.widthMm);
              fontSize = shrinkRes.fontSizePt;
              if (shrinkRes.requiresReview) requiresReview = true;
            }

            const textWidth = font.widthOfTextAtSize(textToDraw, fontSize);
            const alignedX = CalibrationEngine.calculateAlignedXPt(
              element.geometry.xMm,
              element.geometry.widthMm,
              element.typography?.align || 'left',
              textWidth
            );
            const baselineY = CalibrationEngine.calculateBaselineYPt(
              element.geometry.yMm,
              fontSize,
              pageHeightMm,
              font.heightAtSize(fontSize)
            );

            page.drawText(textToDraw, {
              x: alignedX,
              y: baselineY,
              size: fontSize,
              font,
              maxWidth: CalibrationEngine.xMmToPdfPt(element.geometry.widthMm),
              color: rgb(0.08, 0.12, 0.2),
            });
            injectedElementsCount++;
            break;
          }

          case 'multilineText': {
            const rawVal = VectorOverlayEngineV2.resolveDataKey(patientData, element.dataKey);
            if (!rawVal || String(rawVal).trim() === '') break;

            const textToDraw = String(rawVal).trim();
            const font = element.typography?.fontWeight === 'bold' ? fontBold : fontRegular;
            const baseFontSize = element.typography?.fontSizePt || 9.5;

            const shrinkResult = CalibrationEngine.calculateShrinkFontSize(
              textToDraw,
              element.geometry.heightMm,
              baseFontSize,
              7.5,
              element.geometry.widthMm
            );

            if (shrinkResult.requiresReview) {
              requiresReview = true;
              warnings.push(`El texto en '${element.id}' excede el espacio visual asignado y requiere revisión.`);
            }

            const activeFontSize = shrinkResult.fontSizePt;
            const lineHeightPt = element.typography?.lineHeightPt || (activeFontSize * 1.35);

            // Renderizar párrafos y líneas
            const lines = VectorOverlayEngineV2.wrapText(textToDraw, font, activeFontSize, CalibrationEngine.xMmToPdfPt(element.geometry.widthMm));
            let currentYMm = element.geometry.yMm;

            for (let i = 0; i < Math.min(lines.length, element.maxLines || 40); i++) {
              const line = lines[i];
              const textWidth = font.widthOfTextAtSize(line, activeFontSize);
              const alignedX = CalibrationEngine.calculateAlignedXPt(
                element.geometry.xMm,
                element.geometry.widthMm,
                element.typography?.align || 'left',
                textWidth
              );
              const baselineY = CalibrationEngine.calculateBaselineYPt(
                currentYMm,
                activeFontSize,
                pageHeightMm,
                font.heightAtSize(activeFontSize)
              );

              page.drawText(line, {
                x: alignedX,
                y: baselineY,
                size: activeFontSize,
                font,
                maxWidth: CalibrationEngine.xMmToPdfPt(element.geometry.widthMm),
                color: rgb(0.1, 0.15, 0.25),
              });
              currentYMm += CalibrationEngine.ptToMm(lineHeightPt);
            }
            injectedElementsCount++;
            break;
          }

          case 'checkbox': {
            const rawVal = VectorOverlayEngineV2.resolveDataKey(patientData, element.dataKey);
            const isChecked = Boolean(rawVal);
            const isDebug = Boolean(options.debugMode || options.debugOverlay);
            if (!isChecked && !isDebug) break;

            const markChar = element.markStyle === 'CHECK' ? '✓' : 'X';
            const fontSize = element.fontSizePt || 8;
            const markWidth = fontBold.widthOfTextAtSize(markChar, fontSize);
            const boxWidthPt = CalibrationEngine.mmToPt(element.geometry.widthMm);
            const boxHeightPt = CalibrationEngine.mmToPt(element.geometry.heightMm);
            const originXPt = CalibrationEngine.xMmToPdfPt(element.geometry.xMm);
            const originYPt = CalibrationEngine.yMmToPdfPt(element.geometry.yMm, pageHeightMm);

            // Centrado geométrico exacto usando métricas reales de la fuente
            const alignedX = originXPt + (boxWidthPt - markWidth) / 2;
            const capHeight = fontSize * 0.718;
            const baselineY = originYPt - (boxHeightPt + capHeight) / 2;

            if (isChecked) {
              page.drawText(markChar, {
                x: alignedX,
                y: baselineY,
                size: fontSize,
                font: fontBold,
                color: isDebug ? rgb(0.85, 0.1, 0.1) : rgb(0.04, 0.22, 0.43),
              });
              injectedElementsCount++;
            }

            if (isDebug) {
              // Caja de diagnóstico de alta visibilidad para comprobación de superposición
              page.drawRectangle({
                x: originXPt,
                y: originYPt - boxHeightPt,
                width: boxWidthPt,
                height: boxHeightPt,
                borderColor: rgb(0.1, 0.7, 0.2),
                borderWidth: 0.5,
              });
            }
            break;
          }

          case 'stamp':
          case 'signature': {
            if (embeddedStampImage) {
              const xPt = CalibrationEngine.xMmToPdfPt(element.geometry.xMm);
              const yPt = CalibrationEngine.yMmToPdfPt(element.geometry.yMm + element.geometry.heightMm, pageHeightMm);
              const widthPt = CalibrationEngine.xMmToPdfPt(element.geometry.widthMm);
              const heightPt = CalibrationEngine.xMmToPdfPt(element.geometry.heightMm);

              page.drawImage(embeddedStampImage, {
                x: xPt,
                y: yPt,
                width: widthPt,
                height: heightPt,
                opacity: element.opacity !== undefined ? element.opacity : 0.92,
              });
              injectedElementsCount++;
            }
            break;
          }

          case 'line': {
            const startX = CalibrationEngine.xMmToPdfPt(element.geometry.xMm);
            const endX = CalibrationEngine.xMmToPdfPt(element.geometry.xMm + element.geometry.widthMm);
            const yPt = CalibrationEngine.yMmToPdfPt(element.geometry.yMm, pageHeightMm);

            page.drawLine({
              start: { x: startX, y: yPt },
              end: { x: endX, y: yPt },
              thickness: element.thicknessPt || 1,
              color: rgb(0.3, 0.35, 0.4),
            });
            injectedElementsCount++;
            break;
          }
        }
      }
    }

    const pdfBytes = await pdfDoc.save();
    return {
      pdfBytes,
      requiresReview,
      warnings,
      injectedElementsCount,
    };
  }

  /**
   * Divide un texto en líneas respetando el ancho máximo en puntos
   */
  public static wrapText(text: string, font: PDFFont, fontSize: number, maxWidthPt: number): string[] {
    const paragraphs = text.split('\n');
    const resultLines: string[] = [];

    for (const paragraph of paragraphs) {
      if (paragraph.trim() === '') {
        resultLines.push('');
        continue;
      }
      const words = paragraph.split(' ');
      let currentLine = '';

      for (const word of words) {
        const testLine = currentLine === '' ? word : `${currentLine} ${word}`;
        const testWidth = font.widthOfTextAtSize(testLine, fontSize);

        if (testWidth <= maxWidthPt) {
          currentLine = testLine;
        } else {
          if (currentLine !== '') {
            resultLines.push(currentLine);
          }
          currentLine = word;
        }
      }
      if (currentLine !== '') {
        resultLines.push(currentLine);
      }
    }

    return resultLines;
  }
}
