/**
 * SemanticDataMapperV2.ts
 * 
 * Mapeador Semántico Universal (V2):
 * Transforma el modelo clínico de la aplicación (`PatientData`, `PatientInfo`, `StructuredClinicalData`, formularios)
 * a un diccionario semántico jerárquico accesible mediante notación de puntos (ej: 'patient.fullName', 'recipe.pharmacy')
 * para el inyector vectorial VectorOverlayEngineV2.
 */

import { PatientData, PatientInfo, StructuredClinicalData } from '../types';
import labMasterJson from './masters/lab.master.json';

const P1_CHECKBOXES = (labMasterJson.pages as any)?.page1_analitica?.checkboxes || [];

export interface ClinicalWorkspaceContext {
  patient?: Partial<PatientData & PatientInfo>;
  clinical?: Partial<StructuredClinicalData> & Record<string, any>;
  documentDate?: string;
  doctorStampBase64?: string;
  notes?: string;
  recipeLeft?: string;
  recipeRight?: string;
  certificateText?: string;
}

export class SemanticDataMapperV2 {
  /**
   * Genera el diccionario semántico unificado a partir de los datos actuales
   */
  public static mapToSemanticDictionary(ctx: ClinicalWorkspaceContext): Record<string, any> {
    const p = ctx.patient || {};
    const c = ctx.clinical || {};

    const fullName = p.fullName || '';
    const idNumber = (p as any).idNumber || (p as any).nationalId || '';
    const age = p.age || '';
    const phone = p.phone || '';
    const address = (p as any).address || '';
    const date = ctx.documentDate || (p as any).date || new Date().toLocaleDateString('es-VE');

    // Mapear récipe: si no viene texto directo, derivar de medications estructurados
    let rxPharmacy = ctx.recipeLeft || '';
    let rxIndications = ctx.recipeRight || '';

    if (!rxPharmacy && Array.isArray(c.medications) && c.medications.length > 0) {
      rxPharmacy = c.medications
        .map((m, idx) => `${idx + 1}. ${m.drug} ${m.dose} - Dispensar: ${m.duration || 'Tratamiento completo'}`)
        .join('\n');
    }

    if (!rxIndications && Array.isArray(c.medications) && c.medications.length > 0) {
      rxIndications = c.medications
        .map((m, idx) => `${idx + 1}. ${m.drug}: Tomar ${m.dose} cada ${m.frequency} por ${m.duration}`)
        .join('\n');
    }

    // Diagnóstico principal
    const diagnosisPrincipal = c.diagnosisPrincipal || (c as any).diagnostic || (ctx as any).presumptiveDx || (ctx as any).diagnosticoPresuntivo || '';

    // Narrativa de constancia
    const certificateNarrative = ctx.certificateText || (c as any).certificateNarrative || (c as any).restCertificate || '';

    // Informe clínico
    const clinicalReport = (c as any).clinicalReport || (c as any).reportText || c.summaryNote || '';

    // Neuroimágenes checkboxes con soporte tanto para Array como para Record/Object (en ctx.clinical o en ctx raíz)
    const rawLabSource = c.labTests || (ctx as any).labTests;
    const hasLabMatch = (regex: RegExp): boolean => {
      if (Array.isArray(rawLabSource)) {
        return rawLabSource.some((t: string) => regex.test(String(t)));
      }
      if (rawLabSource && typeof rawLabSource === 'object') {
        return Object.entries(rawLabSource).some(([k, v]) => Boolean(v) && regex.test(k));
      }
      return false;
    };

    const rawNeuroSource = (c as any).neuroimagingTests || (c as any).neuroimaging || (ctx as any).neuroimagingTests || (ctx as any).neuroimaging;
    const hasNeuroMatch = (regex: RegExp): boolean => {
      if (Array.isArray(rawNeuroSource)) {
        return rawNeuroSource.some((t: string) => regex.test(String(t)));
      }
      if (rawNeuroSource && typeof rawNeuroSource === 'object') {
        return Object.entries(rawNeuroSource).some(([k, v]) => Boolean(v) && regex.test(k));
      }
      return false;
    };

    const neuroimaging: Record<string, boolean> = {
      rmn: Boolean((c as any).rmn || (ctx as any).rmn || (c as any).neuroimaging?.rmn || (ctx as any).neuroimaging?.rmn || hasNeuroMatch(/resonancia|rmn|mri/i) || hasLabMatch(/resonancia|rmn|mri/i)),
      tac: Boolean((c as any).tac || (ctx as any).tac || (c as any).neuroimaging?.tac || (ctx as any).neuroimaging?.tac || hasNeuroMatch(/tac|tomograf/i) || hasLabMatch(/tac|tomograf/i)),
      radiologia: Boolean((c as any).radiologia || (ctx as any).radiologia || (c as any).neuroimaging?.radiologia || (ctx as any).neuroimaging?.radiologia || hasNeuroMatch(/rx|radiolog/i) || hasLabMatch(/rx|radiolog/i)),
      eeg: Boolean((c as any).eeg || (ctx as any).eeg || (c as any).neuroimaging?.eeg || (ctx as any).neuroimaging?.eeg || hasNeuroMatch(/eeg|electroencefal/i) || hasLabMatch(/eeg|electroencefal/i)),
      emg: Boolean((c as any).emg || (ctx as any).emg || (c as any).neuroimaging?.emg || (ctx as any).neuroimaging?.emg || hasNeuroMatch(/emg|electromiogr/i) || hasLabMatch(/emg|electromiogr/i)),
      pess: Boolean((c as any).pess || (ctx as any).pess || (c as any).neuroimaging?.pess || (ctx as any).neuroimaging?.pess || hasNeuroMatch(/pess|potenciales/i) || hasLabMatch(/pess|potenciales/i)),
      valoracion: Boolean((c as any).valoracion || (ctx as any).valoracion || (c as any).neuroimaging?.valoracion || (ctx as any).neuroimaging?.valoracion || hasNeuroMatch(/valoraci/i) || hasLabMatch(/valoraci/i)),
    };

    // Mapear labTests individuales hacia los dataKeys canónicos del Master sin crear claves ficticias
    const rawTests = c.labTests || (ctx as any).labTests;
    const labTestsMap: Record<string, boolean> = {};
    const unmappedLabTests: string[] = [];

    const testList: string[] = [];
    if (Array.isArray(rawTests)) {
      rawTests.forEach((t: string) => {
        if (typeof t === 'string' && t.trim()) testList.push(t.trim());
      });
    } else if (rawTests && typeof rawTests === 'object') {
      Object.entries(rawTests).forEach(([k, v]) => {
        if (Boolean(v) && k.trim()) testList.push(k.trim());
      });
    }

    const normalize = (s: string) =>
      s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, ' ').trim();

    for (const test of testList) {
      let matched = false;

      // A. Coincidencia directa con checkboxes del Master V2 (dataKey, rawKey, label, id)
      for (const cb of P1_CHECKBOXES) {
        const rawKey = cb.dataKey.replace(/^labTests\./, '');
        if (test === cb.dataKey || test === rawKey || test === cb.label || test === cb.id) {
          labTestsMap[rawKey] = true;
          matched = true;
          break;
        }
      }

      if (matched) continue;

      const norm = normalize(test);

      // B. Reglas semánticas clínicas hacia casillas físicas del Master
      if (/\b(sodio|potasio|cloro|electrolito|electrolitos|ionograma|na|k|cl)\b/.test(norm)) {
        labTestsMap['Electrolitos Séricos (Na, K, Cl)'] = true;
        matched = true;
      } else if (/\b(calcio|fosforo|calcemia|ca|p)\b/.test(norm)) {
        labTestsMap['Calcio Sérico / Fósforo'] = true;
        matched = true;
      } else if (/\b(transaminasas|tgo|tgp|ast|alt)\b/.test(norm)) {
        labTestsMap['Transaminasas (TGO / TGP)'] = true;
        matched = true;
      } else if (/\b(lipidico|lipidos|colesterol|trigliceridos)\b/.test(norm)) {
        labTestsMap['HDL / LDL Colesterol'] = true;
        matched = true;
      } else if (/\b(tiroideo|tiroides|tsh|t3|t4)\b/.test(norm)) {
        labTestsMap['T3, T4 Libre y TSH'] = true;
        matched = true;
      } else if (/\b(hematologia|hemograma|formula|leucocitos|hemoglobina|hematocrito|cbc)\b/.test(norm)) {
        labTestsMap['Hematología Completa'] = true;
        matched = true;
      } else if (/\b(glicemia|glucosa|hba1c|insulina|azucar)\b/.test(norm)) {
        labTestsMap['Glicemia'] = true;
        matched = true;
      } else if (/\b(urea|bun)\b/.test(norm)) {
        labTestsMap['Urea'] = true;
        matched = true;
      } else if (/\b(creatinina)\b/.test(norm)) {
        labTestsMap['Creatinina'] = true;
        matched = true;
      } else if (/\b(orina|uroanalisis|ego)\b/.test(norm)) {
        labTestsMap['Examen General de Orina'] = true;
        matched = true;
      } else if (/\b(preoperatorio)\b/.test(norm)) {
        labTestsMap['Perfil Preoperatorio Completo'] = true;
        matched = true;
      } else if (/\b(tp|pt|protrombina|inr)\b/.test(norm)) {
        labTestsMap['Pt (Tiempo Protrombina)'] = true;
        matched = true;
      } else if (/\b(tpt|ptt|tromboplastina)\b/.test(norm)) {
        labTestsMap['Ptt (Tiempo Parcial de Tromboplastina)'] = true;
        matched = true;
      } else if (/\b(fibrinogeno|fibrinógeno)\b/.test(norm)) {
        labTestsMap['Dosificación de Fibrinógeno'] = true;
        matched = true;
      } else if (/\b(plaqueta|plaquetas|plaquetario)\b/.test(norm)) {
        labTestsMap['Plaquetas'] = true;
        matched = true;
      } else if (/\b(vsg|eritrosedimentacion|eritrosedimentación)\b/.test(norm)) {
        labTestsMap['Eritrosedimentación (VSG)'] = true;
        matched = true;
      } else if (/\b(grupo|rh|tipiaje|factor rh)\b/.test(norm)) {
        labTestsMap['Grupo Sanguíneo, Factor Rh (D)'] = true;
        matched = true;
      } else if (/\b(hiv|vih|sida)\b/.test(norm)) {
        labTestsMap['HIV'] = true;
        matched = true;
      } else if (/\b(vdrl|rpr|luetica|luética|sifilis|sífilis)\b/.test(norm)) {
        labTestsMap['VDRL'] = true;
        matched = true;
      } else if (/\b(pcr|proteina c reactiva|proteína c reactiva)\b/.test(norm)) {
        labTestsMap['Proteina "C" Reactiva'] = true;
        matched = true;
      } else if (/\b(acido urico|ácido úrico|uricemia)\b/.test(norm)) {
        labTestsMap['Ácido Úrico'] = true;
        matched = true;
      } else if (/\b(bilirrubina|bilirrubinas)\b/.test(norm)) {
        labTestsMap['Bilirrubina Total y Fraccionada'] = true;
        matched = true;
      } else if (/\b(amilasa)\b/.test(norm)) {
        labTestsMap['Amilasa'] = true;
        matched = true;
      } else if (/\b(lipasa)\b/.test(norm)) {
        labTestsMap['Lipasa'] = true;
        matched = true;
      } else if (/\b(urocultivo)\b/.test(norm)) {
        labTestsMap['Urocultivo y Antibiograma'] = true;
        matched = true;
      } else if (/\b(coproanalisis|coproanálisis|heces)\b/.test(norm)) {
        labTestsMap['Coproanálisis'] = true;
        matched = true;
      }

      // C. Búsqueda normalizada contra todos los 107 checkboxes del Master
      if (!matched) {
        for (const cb of P1_CHECKBOXES) {
          const rawKey = cb.dataKey.replace(/^labTests\./, '');
          const normRaw = normalize(rawKey);
          const normLabel = normalize(cb.label || '');
          if (
            norm === normRaw ||
            norm === normLabel ||
            (norm.length >= 4 && (normRaw.includes(norm) || normLabel.includes(norm)))
          ) {
            labTestsMap[rawKey] = true;
            matched = true;
            break;
          }
        }
      }

      // D. Si no cayó en ningún checkbox físico preimpreso, va a Otros Exámenes (ej: Magnesio)
      if (!matched) {
        unmappedLabTests.push(test);
      }
    }

    const existingOther = (c as any).otherExams || (c as any).otrosExamenes || (ctx as any).otherExams || (ctx as any).otrosExamenes || '';
    const combinedOtherExams = [existingOther, ...unmappedLabTests]
      .filter((s) => Boolean(s && String(s).trim()))
      .join(', ');

    return {
      patient: {
        fullName,
        idNumber,
        age: age ? (String(age).includes('años') ? String(age) : `${age} años`) : '',
        phone,
        address,
        gender: (p as any).gender || (p as any).sexo || '',
        email: (p as any).email || (p as any).correo || '',
        date,
      },
      document: {
        date,
        type: (ctx as any).documentType || 'medical_document',
      },
      recipe: {
        pharmacy: rxPharmacy,
        indications: rxIndications,
      },
      certificate: {
        title: 'CONSTANCIA MÉDICA DE ASISTENCIA Y REPOSO',
        narrative: certificateNarrative,
      },
      clinical: {
        diagnosisPrincipal,
        diagnosis: diagnosisPrincipal,
        diagnostico: diagnosisPrincipal,
        treatment: (c as any).treatment || (c as any).tratamiento || rxIndications || rxPharmacy || '',
        tratamiento: (c as any).treatment || (c as any).tratamiento || rxIndications || rxPharmacy || '',
        indications: rxIndications || (c as any).indications || (c as any).indicaciones || '',
        notes: (c as any).notes || (c as any).observaciones || ctx.notes || clinicalReport || '',
        observaciones: (c as any).notes || (c as any).observaciones || ctx.notes || clinicalReport || '',
        clinicalReport,
        reportText: clinicalReport,
        motivoConsulta: (c as any).motivoConsulta || (c as any).motivo || '',
        enfermedadActual: (c as any).enfermedadActual || (c as any).enfermedad || '',
        antecedentes: (c as any).antecedentes || '',
        examenFisico: (c as any).examenFisico || (c as any).examen || '',
        otherExams: combinedOtherExams,
        otrosExamenes: combinedOtherExams,
        checkbox: (c as any).checkbox || (c as any).checkboxes || {},
      },
      checkbox: (ctx as any).checkbox || (c as any).checkbox || {},
      doctor: {
        name: 'Dr. Samir Moucharrafie Naime',
        specialty: 'Especialista en Neurocirugía (UCBL Lyon 1 - Francia)',
        mpps: '61231',
        cmeb: '5331',
        stampBase64: ctx.doctorStampBase64,
        signatureBase64: (ctx as any).signatureBase64,
      },
      neuroimaging,
      labTests: labTestsMap,
      ...((ctx as any).customData || {}),
    };
  }
}
