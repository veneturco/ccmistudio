/**
 * MasterRegistryV2.ts
 * 
 * Registro canónico y oficial de los 5 Master Templates V2.
 * Convierte e indexa los esquemas maestros físicos (mm) al contrato universal MasterTemplateV2.
 * 
 * REGLAS FUNDAMENTALES:
 * - BACKGROUND ORIGINAL INMUTABLE (PDF oficial)
 * - COORDINADAS EN MILÍMETROS (origen: top-left, yAxis: down)
 * - NINGÚN DATO CLÍNICO NI COORDENADA INVENTADA
 */

import { MasterTemplateV2, PageTemplate, OverlayElement, LockedRegion } from './types/MasterTemplateV2';
export type { MasterTemplateV2, PageTemplate, OverlayElement, LockedRegion };

// Cargar maestros base JSON
import recipeMasterJson from './masters/recipe.master.json';
import constanciaMasterJson from './masters/constancia.master.json';
import informeMasterJson from './masters/informe.master.json';
import historiaMasterJson from './masters/historia.master.json';
import labMasterJson from './masters/lab.master.json';

/**
 * 1. RECIPE MASTER TEMPLATE V2 (Doble Talón Farmacia / Paciente)
 */
export const RECIPE_MASTER_V2: MasterTemplateV2 = {
  masterId: 'RECIPE-001',
  version: '2.0',
  documentType: 'recipe',
  status: 'LOCKED',
  source: {
    backgroundPdf: '/templates/recipe_base.pdf',
  },
  coordinateSystem: {
    unit: 'mm',
    origin: 'top-left',
    yAxis: 'down',
  },
  lockedRegions: recipeMasterJson.lockedRegions as LockedRegion[],
  pages: [
    {
      pageIndex: 0,
      widthMm: 210,
      heightMm: 297,
      backgroundPdfPage: 1,
      lockedRegions: recipeMasterJson.lockedRegions as LockedRegion[],
      elements: [
        // --- TALÓN IZQUIERDO (FARMACIA) ---
        {
          type: 'text',
          id: 'left_patient_name',
          pageIndex: 0,
          dataKey: 'patient.fullName',
          geometry: { xMm: 25.0, yMm: 44.5, widthMm: 75.0, heightMm: 6.5 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
          overflow: 'shrink',
        },
        {
          type: 'text',
          id: 'left_patient_id',
          pageIndex: 0,
          dataKey: 'patient.idNumber',
          geometry: { xMm: 15.0, yMm: 52.8, widthMm: 32.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'left_patient_age',
          pageIndex: 0,
          dataKey: 'patient.age',
          geometry: { xMm: 51.0, yMm: 52.8, widthMm: 18.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'center' },
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'left_date',
          pageIndex: 0,
          dataKey: 'document.date',
          geometry: { xMm: 74.0, yMm: 52.8, widthMm: 25.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'center' },
          maxLines: 1,
        },
        {
          type: 'multilineText',
          id: 'left_rx_body',
          pageIndex: 0,
          dataKey: 'recipe.pharmacy',
          geometry: { xMm: 10.0, yMm: 72.0, widthMm: 89.0, heightMm: 172.0 },
          typography: { fontSizePt: 10.0, lineHeightPt: 15.0, align: 'left' },
          maxLines: 25,
          overflow: 'shrink',
        },
        {
          type: 'stamp',
          id: 'left_doctor_stamp',
          pageIndex: 0,
          assetKey: 'doctor_stamp_signature',
          geometry: { xMm: 58.0, yMm: 248.0, widthMm: 38.0, heightMm: 22.0 },
          opacity: 0.90,
        },

        // --- TALÓN DERECHO (INDICACIONES PACIENTE) ---
        {
          type: 'text',
          id: 'right_patient_name',
          pageIndex: 0,
          dataKey: 'patient.fullName',
          geometry: { xMm: 129.0, yMm: 44.5, widthMm: 75.0, heightMm: 6.5 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
          overflow: 'shrink',
        },
        {
          type: 'text',
          id: 'right_patient_id',
          pageIndex: 0,
          dataKey: 'patient.idNumber',
          geometry: { xMm: 119.0, yMm: 52.8, widthMm: 32.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'right_patient_age',
          pageIndex: 0,
          dataKey: 'patient.age',
          geometry: { xMm: 155.0, yMm: 52.8, widthMm: 18.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'center' },
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'right_date',
          pageIndex: 0,
          dataKey: 'document.date',
          geometry: { xMm: 178.0, yMm: 52.8, widthMm: 25.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'center' },
          maxLines: 1,
        },
        {
          type: 'multilineText',
          id: 'right_indications_body',
          pageIndex: 0,
          dataKey: 'recipe.indications',
          geometry: { xMm: 114.0, yMm: 72.0, widthMm: 89.0, heightMm: 172.0 },
          typography: { fontSizePt: 10.0, lineHeightPt: 15.0, align: 'left' },
          maxLines: 25,
          overflow: 'shrink',
        },
        {
          type: 'stamp',
          id: 'right_doctor_stamp',
          pageIndex: 0,
          assetKey: 'doctor_stamp_signature',
          geometry: { xMm: 162.0, yMm: 248.0, widthMm: 38.0, heightMm: 22.0 },
          opacity: 0.90,
        },
      ],
    },
  ],
  metadata: {
    name: 'Récipe Médico Oficial Doble Talón (Samir)',
    description: 'Récipe institucional A4 dividido en talón de farmacia y talón de indicaciones para el paciente.',
  },
};

/**
 * 2. CONSTANCIA MÉDICA MASTER TEMPLATE V2
 */
export const CONSTANCIA_MASTER_V2: MasterTemplateV2 = {
  masterId: 'CONSTANCIA-001',
  version: '2.0',
  documentType: 'certificate',
  status: 'LOCKED',
  source: {
    backgroundPdf: '/templates/constancia_base.pdf',
  },
  coordinateSystem: {
    unit: 'mm',
    origin: 'top-left',
    yAxis: 'down',
  },
  lockedRegions: constanciaMasterJson.lockedRegions as LockedRegion[],
  pages: [
    {
      pageIndex: 0,
      widthMm: 210,
      heightMm: 297,
      backgroundPdfPage: 0,
      lockedRegions: constanciaMasterJson.lockedRegions as LockedRegion[],
      elements: [
        {
          type: 'text',
          id: 'cert_title',
          pageIndex: 0,
          dataKey: 'certificate.title',
          geometry: { xMm: 49.39, yMm: 42.98, widthMm: 111.23, heightMm: 6.0 },
          typography: { fontSizePt: 13.0, fontWeight: 'bold', align: 'center' },
        },
        {
          type: 'text',
          id: 'cert_patient_name',
          pageIndex: 0,
          dataKey: 'patient.fullName',
          geometry: { xMm: 17.18, yMm: 58.87, widthMm: 115.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'left' },
          labelPrefix: 'CIUDADANO(A): ',
          maxLines: 1,
          overflow: 'shrink',
        },
        {
          type: 'text',
          id: 'cert_patient_id',
          pageIndex: 0,
          dataKey: 'patient.idNumber',
          geometry: { xMm: 134.05, yMm: 58.87, widthMm: 60.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'left' },
          labelPrefix: 'C.I.: ',
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'cert_patient_age',
          pageIndex: 0,
          dataKey: 'patient.age',
          geometry: { xMm: 17.18, yMm: 67.33, widthMm: 50.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'left' },
          labelPrefix: 'EDAD: ',
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'cert_date',
          pageIndex: 0,
          dataKey: 'document.date',
          geometry: { xMm: 134.05, yMm: 67.33, widthMm: 60.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'left' },
          labelPrefix: 'FECHA: ',
          maxLines: 1,
        },
        {
          type: 'multilineText',
          id: 'cert_diagnosis',
          pageIndex: 0,
          dataKey: 'clinical.diagnosisPrincipal',
          geometry: { xMm: 17.18, yMm: 80.03, widthMm: 176.87, heightMm: 14.81 },
          typography: { fontSizePt: 9.5, lineHeightPt: 13.5, align: 'left' },
          maxLines: 3,
          overflow: 'shrink',
        },
        {
          type: 'multilineText',
          id: 'cert_narrative',
          pageIndex: 0,
          dataKey: 'certificate.narrative',
          geometry: { xMm: 17.18, yMm: 98.0, widthMm: 176.87, heightMm: 110.0 },
          typography: { fontSizePt: 10.0, lineHeightPt: 15.0, align: 'left' },
          maxLines: 18,
          overflow: 'shrink',
        },
        {
          type: 'stamp',
          id: 'cert_stamp',
          pageIndex: 0,
          assetKey: 'doctor_stamp_signature',
          geometry: { xMm: 85.0, yMm: 220.0, widthMm: 45.0, heightMm: 25.0 },
          opacity: 0.95,
        },
      ],
    },
  ],
  metadata: {
    name: 'Constancia Médica Oficial (Samir)',
    description: 'Certificado de asistencia médica y reposo institucional A4.',
  },
};

/**
 * 3. INFORME MÉDICO MASTER TEMPLATE V2
 */
export const INFORME_MASTER_V2: MasterTemplateV2 = {
  masterId: 'INFORME-001',
  version: '2.0',
  documentType: 'report',
  status: 'LOCKED',
  source: {
    backgroundPdf: '/templates/informe_base.pdf',
  },
  coordinateSystem: {
    unit: 'mm',
    origin: 'top-left',
    yAxis: 'down',
  },
  lockedRegions: informeMasterJson.lockedRegions as LockedRegion[],
  pages: [
    {
      pageIndex: 0,
      widthMm: 210,
      heightMm: 297,
      backgroundPdfPage: 0,
      lockedRegions: informeMasterJson.lockedRegions as LockedRegion[],
      elements: [
        {
          type: 'text',
          id: 'inf_patient_name',
          pageIndex: 0,
          dataKey: 'patient.fullName',
          geometry: { xMm: 17.18, yMm: 45.12, widthMm: 110.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.0, fontWeight: 'bold', align: 'left' },
          labelPrefix: 'PACIENTE: ',
          maxLines: 1,
          overflow: 'shrink',
        },
        {
          type: 'text',
          id: 'inf_patient_id',
          pageIndex: 0,
          dataKey: 'patient.idNumber',
          geometry: { xMm: 130.88, yMm: 45.12, widthMm: 65.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.0, fontWeight: 'bold', align: 'left' },
          labelPrefix: 'C.I.: ',
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'inf_patient_age',
          pageIndex: 0,
          dataKey: 'patient.age',
          geometry: { xMm: 17.18, yMm: 53.58, widthMm: 110.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.0, fontWeight: 'bold', align: 'left' },
          labelPrefix: 'EDAD: ',
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'inf_date',
          pageIndex: 0,
          dataKey: 'document.date',
          geometry: { xMm: 130.88, yMm: 53.58, widthMm: 65.0, heightMm: 6.0 },
          typography: { fontSizePt: 9.0, fontWeight: 'bold', align: 'left' },
          labelPrefix: 'FECHA: ',
          maxLines: 1,
        },
        {
          type: 'multilineText',
          id: 'inf_diagnosis',
          pageIndex: 0,
          dataKey: 'clinical.diagnosisPrincipal',
          geometry: { xMm: 17.18, yMm: 64.0, widthMm: 176.87, heightMm: 16.0 },
          typography: { fontSizePt: 9.5, lineHeightPt: 13.5, align: 'left' },
          maxLines: 3,
          overflow: 'shrink',
        },
        {
          type: 'multilineText',
          id: 'inf_content',
          pageIndex: 0,
          dataKey: 'clinical.clinicalReport',
          geometry: { xMm: 17.18, yMm: 85.0, widthMm: 176.87, heightMm: 135.0 },
          typography: { fontSizePt: 9.5, lineHeightPt: 14.5, align: 'left' },
          maxLines: 26,
          overflow: 'shrink',
        },
        {
          type: 'stamp',
          id: 'inf_stamp',
          pageIndex: 0,
          assetKey: 'doctor_stamp_signature',
          geometry: { xMm: 85.0, yMm: 225.0, widthMm: 45.0, heightMm: 25.0 },
          opacity: 0.95,
        },
      ],
    },
  ],
  metadata: {
    name: 'Informe Médico Neuroquirúrgico Oficial (Samir)',
    description: 'Informe clínico formal institucional A4.',
  },
};

/**
 * 4. HISTORIA MÉDICA MASTER TEMPLATE V2
 */
export const HISTORIA_MASTER_V2: MasterTemplateV2 = {
  masterId: 'HISTORIA-001',
  version: '2.0',
  documentType: 'history',
  status: 'LOCKED',
  source: {
    backgroundPdf: '/templates/historia_base.pdf',
  },
  coordinateSystem: {
    unit: 'mm',
    origin: 'top-left',
    yAxis: 'down',
  },
  lockedRegions: historiaMasterJson.lockedRegions as LockedRegion[],
  pages: [
    {
      pageIndex: 0,
      widthMm: 210,
      heightMm: 297,
      backgroundPdfPage: 0,
      lockedRegions: historiaMasterJson.lockedRegions as LockedRegion[],
      elements: [
        {
          type: 'text',
          id: 'hist_fullname',
          pageIndex: 0,
          dataKey: 'patient.fullName',
          geometry: { xMm: 37.56, yMm: 46.55, widthMm: 95.0, heightMm: 7.5 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
          overflow: 'shrink',
        },
        {
          type: 'text',
          id: 'hist_idNumber',
          pageIndex: 0,
          dataKey: 'patient.idNumber',
          geometry: { xMm: 147.05, yMm: 46.02, widthMm: 50.0, heightMm: 7.5 },
          typography: { fontSizePt: 9.5, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'hist_age',
          pageIndex: 0,
          dataKey: 'patient.age',
          geometry: { xMm: 11.9, yMm: 56.6, widthMm: 37.5, heightMm: 7.0 },
          typography: { fontSizePt: 9.0, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'hist_phone',
          pageIndex: 0,
          dataKey: 'patient.phone',
          geometry: { xMm: 60.3, yMm: 56.6, widthMm: 37.5, heightMm: 7.0 },
          typography: { fontSizePt: 9.0, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'hist_date',
          pageIndex: 0,
          dataKey: 'document.date',
          geometry: { xMm: 158.7, yMm: 56.6, widthMm: 39.1, heightMm: 7.0 },
          typography: { fontSizePt: 9.0, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
        },
        {
          type: 'multilineText',
          id: 'hist_motivo',
          pageIndex: 0,
          dataKey: 'clinical.motivoConsulta',
          geometry: { xMm: 10.0, yMm: 78.0, widthMm: 190.0, heightMm: 11.0 },
          typography: { fontSizePt: 9.0, lineHeightPt: 12.0, align: 'left' },
          maxLines: 2,
          overflow: 'shrink',
        },
        {
          type: 'multilineText',
          id: 'hist_enfermedad',
          pageIndex: 0,
          dataKey: 'clinical.enfermedadActual',
          geometry: { xMm: 10.0, yMm: 98.0, widthMm: 190.0, heightMm: 38.0 },
          typography: { fontSizePt: 9.0, lineHeightPt: 12.5, align: 'left' },
          maxLines: 8,
          overflow: 'shrink',
        },
        {
          type: 'multilineText',
          id: 'hist_antecedentes',
          pageIndex: 0,
          dataKey: 'clinical.antecedentes',
          geometry: { xMm: 10.0, yMm: 146.0, widthMm: 190.0, heightMm: 32.0 },
          typography: { fontSizePt: 9.0, lineHeightPt: 12.5, align: 'left' },
          maxLines: 7,
          overflow: 'shrink',
        },
        {
          type: 'multilineText',
          id: 'hist_examen',
          pageIndex: 0,
          dataKey: 'clinical.examenFisico',
          geometry: { xMm: 10.0, yMm: 188.0, widthMm: 190.0, heightMm: 44.0 },
          typography: { fontSizePt: 9.0, lineHeightPt: 12.5, align: 'left' },
          maxLines: 9,
          overflow: 'shrink',
        },
        {
          type: 'multilineText',
          id: 'hist_diagnostico',
          pageIndex: 0,
          dataKey: 'clinical.diagnosisPrincipal',
          geometry: { xMm: 10.0, yMm: 242.0, widthMm: 190.0, heightMm: 38.0 },
          typography: { fontSizePt: 9.0, lineHeightPt: 12.5, align: 'left' },
          maxLines: 8,
          overflow: 'shrink',
        },
      ],
    },
  ],
  metadata: {
    name: 'Historia Médica Oficial (Samir)',
    description: 'Expediente clínico integral institucional A4.',
  },
};

/**
 * 5. ORDEN DE LABORATORIO Y NEUROIMAGEN MASTER TEMPLATE V2 (Multi-página: 2 páginas)
 * Dimensiones físicas originales: 153.5 mm x 215.8 mm (Media Carta / Half-Letter)
 * 114 casillas físicas independientes (107 en Página 1 + 7 en Página 2)
 */
export const LAB_ORDER_MASTER_V2: MasterTemplateV2 = {
  masterId: 'LAB-001',
  version: '3.0',
  documentType: 'lab_order',
  status: 'CALIBRATED',
  source: {
    backgroundPdf: '/templates/orden_lab_base.pdf',
  },
  coordinateSystem: {
    unit: 'mm',
    origin: 'top-left',
    yAxis: 'down',
  },
  lockedRegions: [
    { id: 'p1_header', xMm: 0, yMm: 0, widthMm: 153.5, heightMm: 31.0 },
    { id: 'p1_footer', xMm: 0, yMm: 205.0, widthMm: 153.5, heightMm: 10.8 },
  ],
  pages: [
    // PÁGINA 1: ANALÍTICA SANGUÍNEA Y PRUEBAS ESPECIALES (153.5 mm x 215.8 mm, 107 casillas)
    {
      pageIndex: 0,
      widthMm: 153.5,
      heightMm: 215.8,
      backgroundPdfPage: 0,
      lockedRegions: [
        { id: 'header', xMm: 0, yMm: 0, widthMm: 153.5, heightMm: 31.0 },
        { id: 'footer', xMm: 0, yMm: 205.0, widthMm: 153.5, heightMm: 10.8 },
      ],
      elements: [
        {
          type: 'text',
          id: 'lab_p1_fullname',
          label: 'Nombre del Paciente',
          pageIndex: 0,
          dataKey: 'patient.fullName',
          geometry: (labMasterJson.pages as any).page1_analitica.patientHeader.fullName,
          typography: { fontSizePt: 7.5, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
          overflow: 'shrink',
        },
        {
          type: 'text',
          id: 'lab_p1_idNumber',
          label: 'Cédula de Identidad',
          pageIndex: 0,
          dataKey: 'patient.idNumber',
          geometry: (labMasterJson.pages as any).page1_analitica.patientHeader.idNumber,
          typography: { fontSizePt: 7.5, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'lab_p1_age',
          label: 'Edad',
          pageIndex: 0,
          dataKey: 'patient.age',
          geometry: (labMasterJson.pages as any).page1_analitica.patientHeader.age,
          typography: { fontSizePt: 7.5, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
        },
        {
          type: 'text',
          id: 'lab_p1_date',
          label: 'Fecha',
          pageIndex: 0,
          dataKey: 'document.date',
          geometry: (labMasterJson.pages as any).page1_analitica.patientHeader.date,
          typography: { fontSizePt: 7.5, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
        },
        {
          type: 'stamp',
          id: 'lab_p1_stamp',
          label: 'Sello Médico',
          pageIndex: 0,
          assetKey: 'doctor_stamp_signature',
          geometry: (labMasterJson.pages as any).page1_analitica.doctorStamp,
          opacity: 0.90,
        },
        {
          type: 'multilineText',
          id: 'lab_p1_other_exams',
          label: 'Otros Exámenes',
          pageIndex: 0,
          dataKey: 'clinical.otherExams',
          geometry: (labMasterJson.pages as any).page1_analitica.otherExams || { xMm: 10.4, yMm: 175.5, widthMm: 88, heightMm: 24 },
          typography: { fontSizePt: 7.5, lineHeightPt: 9.5, align: 'left' },
          maxLines: 4,
          overflow: 'shrink',
        },
        // 107 CHECKBOXES CALIBRADAS PÁGINA 1
        ...((labMasterJson.pages as any).page1_analitica.checkboxes || []).map((cb: any) => ({
          type: 'checkbox' as const,
          id: cb.id,
          label: cb.label,
          pageIndex: 0,
          dataKey: cb.dataKey,
          geometry: { xMm: cb.xMm, yMm: cb.yMm, widthMm: cb.widthMm, heightMm: cb.heightMm },
          markStyle: 'X' as const,
          fontSizePt: cb.fontSizePt || 8,
          requiresCalibration: cb.requiresCalibration || false,
        })),
      ],
    },
    // PÁGINA 2: NEUROIMÁGENES Y ESTUDIOS ESPECIALES (153.5 mm x 215.8 mm, 7 casillas)
    {
      pageIndex: 1,
      widthMm: 153.5,
      heightMm: 215.8,
      backgroundPdfPage: 1,
      lockedRegions: [
        { id: 'header_neuro', xMm: 0, yMm: 0, widthMm: 153.5, heightMm: 44.0 },
        { id: 'signature_block', xMm: 80.0, yMm: 185.0, widthMm: 66.0, heightMm: 22.0 },
      ],
      elements: [
        {
          type: 'text',
          id: 'lab_p2_fullname',
          label: 'Practicar a (Paciente)',
          pageIndex: 1,
          dataKey: 'patient.fullName',
          geometry: (labMasterJson.pages as any).page2_neuroimagen.fields.practicarA,
          typography: { fontSizePt: 8.0, fontWeight: 'bold', align: 'left' },
          maxLines: 1,
          overflow: 'shrink',
        },
        {
          type: 'multilineText',
          id: 'lab_p2_diagnosis',
          label: 'Diagnóstico e Indicación Clínica',
          pageIndex: 1,
          dataKey: 'clinical.diagnosisPrincipal',
          geometry: (labMasterJson.pages as any).page2_neuroimagen.fields.diagnosticoIdx,
          typography: { fontSizePt: 7.5, lineHeightPt: 10.0, align: 'left' },
          maxLines: 3,
          overflow: 'shrink',
        },
        // 7 CHECKBOXES CALIBRADAS PÁGINA 2
        ...((labMasterJson.pages as any).page2_neuroimagen.checkboxes || []).map((cb: any) => ({
          type: 'checkbox' as const,
          id: cb.id,
          label: cb.label,
          pageIndex: 1,
          dataKey: cb.dataKey,
          geometry: { xMm: cb.xMm, yMm: cb.yMm, widthMm: cb.widthMm, heightMm: cb.heightMm },
          markStyle: 'X' as const,
          fontSizePt: cb.fontSizePt || 9,
          requiresCalibration: cb.requiresCalibration || false,
        })),
        {
          type: 'stamp',
          id: 'lab_p2_stamp',
          label: 'Sello Médico',
          pageIndex: 1,
          assetKey: 'doctor_stamp_signature',
          geometry: (labMasterJson.pages as any).page2_neuroimagen.fields.doctorStamp,
          opacity: 0.90,
        },
      ],
    },
  ],
  metadata: {
    name: 'Orden de Laboratorio y Neuroimagen Oficial (Samir)',
    description: 'Solicitud médica de 2 páginas con 114 casillas físicas calibradas (107 en P1 + 7 en P2) en formato físico Media Carta (153.5 x 215.8 mm).',
  },
};

/**
 * Registro Universal de Templates V2 indexado por tipo canónico o masterId
 */
export const MASTER_REGISTRY_V2: Record<string, MasterTemplateV2> = {
  recipe: RECIPE_MASTER_V2,
  certificate: CONSTANCIA_MASTER_V2,
  report: INFORME_MASTER_V2,
  history: HISTORIA_MASTER_V2,
  lab_order: LAB_ORDER_MASTER_V2,
  'lab-001': LAB_ORDER_MASTER_V2,
  'recipe-001': RECIPE_MASTER_V2,
  'constancia-001': CONSTANCIA_MASTER_V2,
  'informe-001': INFORME_MASTER_V2,
  'historia-001': HISTORIA_MASTER_V2,
};

/**
 * Registra o actualiza en memoria un MasterTemplateV2 (p. ej. al cargar un PDF maestro original)
 */
export function setMasterTemplateV2(key: string, template: MasterTemplateV2): void {
  const normalizedKey = key.toLowerCase().trim();
  MASTER_REGISTRY_V2[normalizedKey] = template;
  if (template.documentType) {
    MASTER_REGISTRY_V2[template.documentType.toLowerCase().trim()] = template;
  }
  if (template.masterId) {
    MASTER_REGISTRY_V2[template.masterId.toLowerCase().trim()] = template;
  }
}

/**
 * Obtener MasterTemplateV2 oficial por tipo de documento o ID
 */
export function getMasterTemplateV2(key: string): MasterTemplateV2 | null {
  const normalized = key.toLowerCase().trim();
  return MASTER_REGISTRY_V2[normalized] || null;
}

/**
 * Obtiene la lista completa de Masters disponibles en el registro
 */
export function getAllMasterTemplatesV2(): MasterTemplateV2[] {
  const uniqueMasters = new Map<string, MasterTemplateV2>();
  Object.values(MASTER_REGISTRY_V2).forEach(m => {
    uniqueMasters.set(m.masterId, m);
  });
  return Array.from(uniqueMasters.values());
}

