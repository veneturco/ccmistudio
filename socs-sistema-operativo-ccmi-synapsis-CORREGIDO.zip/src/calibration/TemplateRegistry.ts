/**
 * TemplateRegistry.ts
 * 
 * REGISTRO DINÁMICO DE PLANTILLAS MAESTRAS (ARQUITECTURA V2)
 * ==========================================================
 * Permite registrar, consultar y gestionar plantillas MasterTemplateV2
 * sin necesidad de modificar múltiples archivos al incorporar nuevos documentos
 * (ej: AUTORIZACION-001, RECIBO-001, ORDEN-IMAGEN-001).
 * 
 * Jerarquía de autoridad:
 * 1. MasterTemplateV2 oficial validado
 * 2. Registro dinámico en memoria
 */

import { MasterTemplateV2 } from './types/MasterTemplateV2';
import {
  RECIPE_MASTER_V2,
  CONSTANCIA_MASTER_V2,
  INFORME_MASTER_V2,
  HISTORIA_MASTER_V2,
  LAB_ORDER_MASTER_V2,
  setMasterTemplateV2,
} from './MasterRegistryV2';

export class TemplateRegistry {
  private static templates: Map<string, MasterTemplateV2> = new Map();
  private static initialized: boolean = false;

  /**
   * Inicializa el registro cargando los 5 masters canónicos del sistema
   */
  private static ensureInitialized(): void {
    if (this.initialized) return;

    // Registrar los cinco documentos maestros
    this.register(RECIPE_MASTER_V2);
    this.register(CONSTANCIA_MASTER_V2);
    this.register(INFORME_MASTER_V2);
    this.register(HISTORIA_MASTER_V2);

    // Atención especial: LAB se registra con estado REQUIRES_CALIBRATION
    // hasta comprobar y calibrar físicamente contra el PDF original (114 checkboxes individuales)
    this.register(LAB_ORDER_MASTER_V2);

    this.initialized = true;
  }

  /**
   * Registra o actualiza una plantilla maestra en el catálogo
   */
  public static register(template: MasterTemplateV2): void {
    if (!template || !template.masterId) {
      throw new Error('[TemplateRegistry] Plantilla inválida: falta masterId.');
    }
    // Indexar tanto por masterId ('RECIPE-001') como por documentType ('recipe')
    this.templates.set(template.masterId.toUpperCase(), template);
    setMasterTemplateV2(template.masterId, template);
    if (template.documentType) {
      this.templates.set(template.documentType.toLowerCase(), template);
      setMasterTemplateV2(template.documentType, template);
    }
  }

  /**
   * Obtiene una plantilla maestra por su ID ('RECIPE-001') o tipo ('recipe')
   */
  public static get(identifier: string): MasterTemplateV2 | undefined {
    this.ensureInitialized();
    if (!identifier) return undefined;
    return (
      this.templates.get(identifier.toUpperCase()) ||
      this.templates.get(identifier.toLowerCase())
    );
  }

  /**
   * Comprueba si una plantilla está registrada
   */
  public static has(identifier: string): boolean {
    this.ensureInitialized();
    if (!identifier) return false;
    return (
      this.templates.has(identifier.toUpperCase()) ||
      this.templates.has(identifier.toLowerCase())
    );
  }

  /**
   * Retorna todas las plantillas únicas registradas
   */
  public static getAll(): MasterTemplateV2[] {
    this.ensureInitialized();
    const unique = new Map<string, MasterTemplateV2>();
    for (const t of this.templates.values()) {
      unique.set(t.masterId, t);
    }
    return Array.from(unique.values());
  }

  /**
   * Limpia y reinicia el registro (útil para pruebas de integración)
   */
  public static reset(): void {
    this.templates.clear();
    this.initialized = false;
  }
}
