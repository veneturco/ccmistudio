import React from 'react';
import { Dashboard } from './components/Dashboard';

export default function App() {
  return (
    <div id="socs-app-container" className="min-h-screen bg-slate-50 text-slate-900 selection:bg-blue-600 selection:text-white">
      <Dashboard />
    </div>
  );
}
