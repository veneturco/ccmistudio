// Sistema de Persistencia e Historial Local de Fichas Clínicas
// Indexado por Cédula de Identidad (CI) con Auditoría de Cambios
// Dr. Samir Moucharrafie Naime (CCMI / Neurocirugía)

export interface PatientRecord {
  id: string;
  nationalId: string; // Clave de índice principal (ej. "V-16.482.903")
  fullName: string;
  age: string;
  phone: string;
  address: string;
  lastConsultationDate: string;
  lastDiagnosis: string;
  documentStates: {
    recipe: {
      rxLeft: string;
      indicationsRight: string;
    };
    informe: {
      motivo: string;
      antecedentes: string;
      enfermedadActual: string;
      examenFisico: string;
      estudiosParaclinicos: string;
      diagnostico: string;
      planConducta: string;
    };
    ordenLab: {
      perfilPreoperatorio: string[];
      neuroimagen: string[];
      otrosEstudios: string[];
      otherExams?: string;
      diagnosticoPresuntivo: string;
    };
    constancia: {
      attendedDate: string;
      condition: 'Paciente' | 'Familiar';
      needsRest: boolean;
      restDays: string;
      restFrom: string;
      restTo: string;
      idx: string;
    };
    historia: {
      motivoConsulta: string;
      enfermedadActual: string;
      antecedentes: string;
      examenNeurologico: string;
      diagnostico: string;
    };
  };
  auditLog: Array<{
    timestamp: string;
    action: string;
    note?: string;
  }>;
}

const STORAGE_KEY = 'socs_ccmi_patients_v2';

// Fichas clínicas iniciales vacías para instalaciones limpias
const SEED_PATIENTS: PatientRecord[] = [];

// Obtener todas las fichas guardadas
export function getAllPatients(): PatientRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // Guardar seed inicial
      localStorage.setItem(STORAGE_KEY, JSON.stringify(SEED_PATIENTS));
      return SEED_PATIENTS;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error leyendo pacientes de localStorage:', err);
    return SEED_PATIENTS;
  }
}

// Buscar paciente por Cédula (normalizada)
export function getPatientByCedula(nationalId: string): PatientRecord | null {
  const cleanQuery = nationalId.replace(/[^\d]/g, '');
  if (!cleanQuery) return null;

  const all = getAllPatients();
  return (
    all.find(p => p.nationalId.replace(/[^\d]/g, '') === cleanQuery) || null
  );
}

// Guardar o actualizar ficha de paciente
export function savePatientRecord(record: PatientRecord): void {
  try {
    const all = getAllPatients();
    const cleanId = record.nationalId.replace(/[^\d]/g, '');
    const index = all.findIndex(p => p.nationalId.replace(/[^\d]/g, '') === cleanId);

    const now = new Date();
    const timeString = `${now.toLocaleDateString('es-VE')} ${now.toLocaleTimeString('es-VE', { hour: '2-digit', minute: '2-digit' })}`;

    const newAuditEntry = {
      timestamp: timeString,
      action: index >= 0 ? 'Actualización y sincronización de los 5 documentos' : 'Alta y registro de nuevo paciente',
    };

    const updatedRecord: PatientRecord = {
      ...record,
      auditLog: [newAuditEntry, ...(record.auditLog || [])],
    };

    if (index >= 0) {
      all[index] = updatedRecord;
    } else {
      all.unshift(updatedRecord);
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
  } catch (err) {
    console.error('Error guardando paciente en localStorage:', err);
  }
}

// Eliminar ficha de paciente
export function deletePatientRecord(nationalId: string): boolean {
  try {
    const cleanId = nationalId.replace(/[^\d]/g, '');
    const all = getAllPatients();
    const filtered = all.filter(p => p.nationalId.replace(/[^\d]/g, '') !== cleanId);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
    return true;
  } catch (err) {
    console.error('Error eliminando paciente:', err);
    return false;
  }
}
