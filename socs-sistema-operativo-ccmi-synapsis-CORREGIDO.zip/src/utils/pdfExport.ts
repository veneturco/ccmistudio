import jsPDF from 'jspdf';
import html2canvas from 'html2canvas-pro';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { DocType, PatientData } from '../types';
import { CalibrationEngine } from '../calibration/CalibrationEngine';
import recipeMaster from '../calibration/masters/recipe.master.json';
import labMaster from '../calibration/masters/lab.master.json';
import informeMaster from '../calibration/masters/informe.master.json';
import constanciaMaster from '../calibration/masters/constancia.master.json';
import historiaMaster from '../calibration/masters/historia.master.json';
import { PDFDocumentPipelineV2 } from './PDFDocumentPipelineV2';
import type { ClinicalWorkspaceContext } from '../calibration/SemanticDataMapperV2';

export const DOCUMENT_DEFINITIONS: Record<
  DocType,
  { label: string; shortName: string; filenamePrefix: string }
> = {
  RECIPES: {
    label: 'Récipe Médico (Doble Talón)',
    shortName: 'Récipe Médico',
    filenamePrefix: 'Recipe_Doble_Talon',
  },
  INFORME: {
    label: 'Informe Médico Neuroquirúrgico',
    shortName: 'Informe Médico',
    filenamePrefix: 'Informe_Medico',
  },
  ORDEN_LAB: {
    label: 'Orden de Laboratorio y Neuroimagen',
    shortName: 'Orden de Laboratorio',
    filenamePrefix: 'Orden_Laboratorio_Neuroimagen',
  },
  CONSTANCIA: {
    label: 'Constancia Médica de Reposo',
    shortName: 'Constancia Médica',
    filenamePrefix: 'Constancia_Medica_Reposo',
  },
  HISTORIA: {
    label: 'Historia Clínica Especializada',
    shortName: 'Historia Clínica',
    filenamePrefix: 'Historia_Clinica_CCMI',
  },
};

export const TEMPLATE_IMAGE_PATHS: Record<DocType, string> = {
  RECIPES: '/templates/recipes_bg.jpg',
  INFORME: '/templates/informe_bg.jpg',
  ORDEN_LAB: '/templates/orden_lab_bg.jpg',
  CONSTANCIA: '/templates/constancia_bg.jpg',
  HISTORIA: '/templates/historia_bg.jpg',
};

/**
 * Normaliza y formatea el teléfono para formato internacional de WhatsApp (E.164 sin signo +)
 */
export function formatWhatsAppPhone(phone: string): string {
  if (!phone) return '';
  let clean = phone.replace(/[^\d+]/g, '');
  if (clean.startsWith('+')) clean = clean.slice(1);
  
  // Si comienza por 0 (ej: 04249124481 -> 584249124481)
  if (clean.startsWith('0')) {
    clean = '58' + clean.slice(1);
  } else if (
    clean.length === 10 &&
    (clean.startsWith('412') ||
      clean.startsWith('414') ||
      clean.startsWith('424') ||
      clean.startsWith('416') ||
      clean.startsWith('426'))
  ) {
    clean = '58' + clean;
  }
  return clean;
}

/**
 * Sanitiza nombres de archivo para descarga segura de PDFs
 */
export function sanitizeFileName(name: string): string {
  return name
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9_\-\.]/g, '_')
    .replace(/_+/g, '_');
}

// ============================================================================
// MOTOR DE INYECCIÓN DIRECTA SOBRE ARCHIVOS PDF BASE (PDF-LIB)
// INSTITUTO DE CIRUGÍA DE COLUMNA MÍNIMAMENTE INVASIVA (CCMI)
// DR. SAMIR MOUCHARRAFIE NAIME
// ============================================================================

/**
 * Carga el binario PDF original maestro desde /public/templates/ sin alterar
 * ni redibujar nada de su estructura gráfica oficial.
 */
export async function loadBasePdf(filename: string): Promise<PDFDocument> {
  let existingPdfBytes: ArrayBuffer | Uint8Array;
  if (typeof window !== 'undefined') {
    existingPdfBytes = await fetch(`/templates/${filename}`).then((res) => {
      if (!res.ok) throw new Error(`No se pudo cargar la plantilla base: ${filename}`);
      return res.arrayBuffer();
    });
  } else {
    const fs = await import('fs');
    const path = await import('path');
    existingPdfBytes = fs.readFileSync(path.join(process.cwd(), 'public/templates', filename));
  }
  return await PDFDocument.load(existingPdfBytes);
}

/**
 * Descarga en el navegador un buffer de bytes como archivo PDF
 */
export function downloadBlob(bytes: Uint8Array, filename: string): void {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  const blob = new Blob([bytes], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ----------------------------------------------------------------------------
// 1. ORDEN DE LABORATORIO Y ESTUDIOS ESPECIALES (2 PÁGINAS EXACTAS)
// ----------------------------------------------------------------------------
export interface LabOrderExportOptions {
  labTests?: Record<string, boolean> | string[];
  neuroimagingTests?: Record<string, boolean> | string[];
  neuroimagingDetails?: Record<string, string>;
  selectedCheckboxes?: Record<string, { x: number; y: number; page: number }>;
}

/**
 * FUNCIÓN CANÓNICA INTERNA PARA ORDEN DE LABORATORIO Y ESTUDIOS ESPECIALES:
 * Inyecta datos clínicos y marcas sobre el PDF oficial inmutable /templates/orden_lab_base.pdf.
 * Obtiene toda la geometría en milímetros exclusivamente desde labMaster (Única Fuente de Verdad).
 */
export async function createOfficialLabOrderPdf(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string; phone?: string; address?: string },
  orderData: LabOrderExportOptions | Record<string, any>,
  presumptiveDx: string = '',
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const context: ClinicalWorkspaceContext = {
    patient: {
      fullName: patient.fullName || '',
      idNumber: patient.idNumber || '',
      age: patient.age !== undefined && patient.age !== null && patient.age !== '' ? String(patient.age) : '',
      phone: (patient as any).phone || '',
      address: (patient as any).address || '',
    },
    clinical: {
      diagnosisPrincipal: presumptiveDx || '',
      labTests: (orderData as any)?.labTests || orderData,
      neuroimagingTests: (orderData as any)?.neuroimagingTests,
      otherExams: (orderData as any)?.otherExams || '',
    },
    documentDate: patient.date || new Date().toLocaleDateString('es-VE'),
  };

  const result = await PDFDocumentPipelineV2.generateDocument({
    documentType: 'lab_order',
    context,
    customFileName,
  });

  return {
    pdfBytes: result.pdfBytes,
    blob: result.blob,
    file: result.file,
    fileName: result.fileName,
    requiresReview: result.requiresReview,
  };
}

export async function exportOfficialLabOrderPDF(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string; phone?: string; address?: string },
  orderData: LabOrderExportOptions | Record<string, any>,
  presumptiveDx: string,
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  // Conexión Canónica V2: TemplateRegistry -> Master V2 -> DataResolver -> PDFDocumentPipelineV2
  const context: ClinicalWorkspaceContext = {
    patient: {
      fullName: patient.fullName || '',
      idNumber: patient.idNumber || '',
      age: patient.age ? String(patient.age) : '',
      phone: (patient as any).phone || '',
      address: (patient as any).address || '',
    },
    clinical: {
      diagnosisPrincipal: presumptiveDx || '',
      labTests: (orderData as any)?.labTests || orderData,
      neuroimagingTests: (orderData as any)?.neuroimagingTests,
      otherExams: (orderData as any)?.otherExams || '',
    },
    documentDate: patient.date || new Date().toLocaleDateString('es-VE'),
  };

  const result = await PDFDocumentPipelineV2.generateDocument({
    documentType: 'lab_order',
    context,
    customFileName,
  });

  downloadBlob(result.pdfBytes, result.fileName);
  return {
    pdfBytes: result.pdfBytes,
    blob: result.blob,
    file: result.file,
    fileName: result.fileName,
    requiresReview: result.requiresReview,
  };
}

// ----------------------------------------------------------------------------
// 2. HISTORIA CLÍNICA OFICIAL (INYECCIÓN DIRECTA BASADA EN HISTORIA.MASTER)
// ----------------------------------------------------------------------------
/**
 * FUNCIÓN CANÓNICA INTERNA PARA HISTORIA CLÍNICA:
 * Inyecta datos clínicos mediante overlay vectorial directamente sobre
 * el PDF oficial inmutable /templates/historia_base.pdf.
 * Toda la geometría en milímetros se obtiene exclusivamente desde historiaMaster.
 */
export async function createOfficialHistoriaPdf(
  patient: { fullName?: string; idNumber?: string; age?: string | number; phone?: string; address?: string; date?: string },
  clinical: {
    motivo?: string;
    motivoConsulta?: string;
    enfermedadActual?: string;
    antecedentes?: string;
    neuroExam?: string;
    examenNeurologico?: string;
    dx?: string;
    diagnostico?: string;
  },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const pdfDoc = await loadBasePdf('historia_base.pdf');
  const page = pdfDoc.getPages()[0];
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);

  let requiresReview = false;
  const pageHeightMm = historiaMaster.pageSize.heightMm || 297;

  const safeName = (patient.fullName || '').toUpperCase();
  const safeId = patient.idNumber || '';
  const safeAge = patient.age ? String(patient.age) : '';
  const safePhone = patient.phone || '';
  const safeAddress = patient.address || '';

  const pHeader = historiaMaster.editableFields.patientHeader;

  // 1. Cabecera Paciente
  if (safeName) {
    page.drawText(safeName, {
      x: CalibrationEngine.xMmToPdfPt(pHeader.fullName.xMm),
      y: CalibrationEngine.yMmToPdfPt(pHeader.fullName.yMm, pageHeightMm),
      size: pHeader.fullName.fontSizePt || 9.5,
      font: fontBold,
      color: rgb(0.1, 0.1, 0.1),
    });
  } else {
    requiresReview = true;
  }

  if (safeId) {
    page.drawText(safeId, {
      x: CalibrationEngine.xMmToPdfPt(pHeader.idNumber.xMm),
      y: CalibrationEngine.yMmToPdfPt(pHeader.idNumber.yMm, pageHeightMm),
      size: pHeader.idNumber.fontSizePt || 9.5,
      font: fontBold,
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  if (safeAge) {
    page.drawText(safeAge, {
      x: CalibrationEngine.xMmToPdfPt(pHeader.age.xMm),
      y: CalibrationEngine.yMmToPdfPt(pHeader.age.yMm, pageHeightMm),
      size: pHeader.age.fontSizePt || 9.0,
      font: fontBold,
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  if (safePhone) {
    page.drawText(safePhone, {
      x: CalibrationEngine.xMmToPdfPt(pHeader.phone.xMm),
      y: CalibrationEngine.yMmToPdfPt(pHeader.phone.yMm, pageHeightMm),
      size: pHeader.phone.fontSizePt || 9.0,
      font: fontBold,
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  if (safeAddress) {
    page.drawText(safeAddress, {
      x: CalibrationEngine.xMmToPdfPt(pHeader.address.xMm),
      y: CalibrationEngine.yMmToPdfPt(pHeader.address.yMm, pageHeightMm),
      size: pHeader.address.fontSizePt || 8.5,
      font: fontRegular,
      maxWidth: CalibrationEngine.xMmToPdfPt(pHeader.address.widthMm),
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  // 2. Secciones Clínicas con Shrink-to-fit
  const cSections = historiaMaster.editableFields.clinicalSections;

  const motivoText = clinical.motivo || clinical.motivoConsulta || '';
  if (motivoText) {
    const shrink = CalibrationEngine.calculateShrinkFontSize(
      motivoText,
      cSections.motivo.heightMm,
      cSections.motivo.fontSizePt || 9.0,
      7.5
    );
    if (shrink.requiresReview) requiresReview = true;
    const lineHeight = Math.max(10, Math.round(shrink.fontSizePt * 1.4 * 10) / 10);
    page.drawText(motivoText, {
      x: CalibrationEngine.xMmToPdfPt(cSections.motivo.xMm),
      y: CalibrationEngine.yMmToPdfPt(cSections.motivo.yMm, pageHeightMm),
      size: shrink.fontSizePt,
      font: fontRegular,
      lineHeight,
      maxWidth: CalibrationEngine.xMmToPdfPt(cSections.motivo.widthMm),
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  const enfText = clinical.enfermedadActual || '';
  if (enfText) {
    const shrink = CalibrationEngine.calculateShrinkFontSize(
      enfText,
      cSections.enfermedad.heightMm,
      cSections.enfermedad.fontSizePt || 9.0,
      7.5
    );
    if (shrink.requiresReview) requiresReview = true;
    const lineHeight = Math.max(10, Math.round(shrink.fontSizePt * 1.4 * 10) / 10);
    page.drawText(enfText, {
      x: CalibrationEngine.xMmToPdfPt(cSections.enfermedad.xMm),
      y: CalibrationEngine.yMmToPdfPt(cSections.enfermedad.yMm, pageHeightMm),
      size: shrink.fontSizePt,
      font: fontRegular,
      lineHeight,
      maxWidth: CalibrationEngine.xMmToPdfPt(cSections.enfermedad.widthMm),
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  const antText = clinical.antecedentes || '';
  if (antText) {
    const shrink = CalibrationEngine.calculateShrinkFontSize(
      antText,
      cSections.antecedentes.heightMm,
      cSections.antecedentes.fontSizePt || 9.0,
      7.5
    );
    if (shrink.requiresReview) requiresReview = true;
    const lineHeight = Math.max(10, Math.round(shrink.fontSizePt * 1.4 * 10) / 10);
    page.drawText(antText, {
      x: CalibrationEngine.xMmToPdfPt(cSections.antecedentes.xMm),
      y: CalibrationEngine.yMmToPdfPt(cSections.antecedentes.yMm, pageHeightMm),
      size: shrink.fontSizePt,
      font: fontRegular,
      lineHeight,
      maxWidth: CalibrationEngine.xMmToPdfPt(cSections.antecedentes.widthMm),
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  const exText = clinical.neuroExam || clinical.examenNeurologico || '';
  if (exText) {
    const shrink = CalibrationEngine.calculateShrinkFontSize(
      exText,
      cSections.examen.heightMm,
      cSections.examen.fontSizePt || 9.0,
      7.5
    );
    if (shrink.requiresReview) requiresReview = true;
    const lineHeight = Math.max(10, Math.round(shrink.fontSizePt * 1.4 * 10) / 10);
    page.drawText(exText, {
      x: CalibrationEngine.xMmToPdfPt(cSections.examen.xMm),
      y: CalibrationEngine.yMmToPdfPt(cSections.examen.yMm, pageHeightMm),
      size: shrink.fontSizePt,
      font: fontRegular,
      lineHeight,
      maxWidth: CalibrationEngine.xMmToPdfPt(cSections.examen.widthMm),
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  const dxText = clinical.dx || clinical.diagnostico || '';
  if (dxText) {
    const shrink = CalibrationEngine.calculateShrinkFontSize(
      dxText,
      cSections.diagnostico.heightMm,
      cSections.diagnostico.fontSizePt || 9.0,
      7.5
    );
    if (shrink.requiresReview) requiresReview = true;
    const lineHeight = Math.max(10, Math.round(shrink.fontSizePt * 1.4 * 10) / 10);
    page.drawText(dxText, {
      x: CalibrationEngine.xMmToPdfPt(cSections.diagnostico.xMm),
      y: CalibrationEngine.yMmToPdfPt(cSections.diagnostico.yMm, pageHeightMm),
      size: shrink.fontSizePt,
      font: fontBold,
      lineHeight,
      maxWidth: CalibrationEngine.xMmToPdfPt(cSections.diagnostico.widthMm),
      color: rgb(0.08, 0.22, 0.44),
    });
  }

  const pdfBytes = await pdfDoc.save();
  const fileName = customFileName || `Historia_Clinica_${(safeName || 'Paciente').replace(/\s+/g, '_')}.pdf`;
  const blob = new Blob([pdfBytes], { type: 'application/pdf' });
  const file = new File([blob], fileName, { type: 'application/pdf' });
  return { pdfBytes, blob, file, fileName, requiresReview };
}

export async function exportOfficialHistoriaPDF(
  patient: { fullName?: string; idNumber?: string; age?: string | number; address?: string; phone?: string; date?: string },
  clinical: {
    motivo?: string;
    motivoConsulta?: string;
    enfermedadActual?: string;
    antecedentes?: string;
    neuroExam?: string;
    examenNeurologico?: string;
    dx?: string;
    diagnostico?: string;
  },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const result = await createOfficialHistoriaPdf(patient, clinical, customFileName);
  downloadBlob(result.pdfBytes, result.fileName);
  return result;
}

// ----------------------------------------------------------------------------
// 3. RÉCIPE MÉDICO (DOBLE TALÓN) - INYECCIÓN DIRECTA
// ----------------------------------------------------------------------------
/**
 * FUNCIÓN CANÓNICA INTERNA PARA RÉCIPE MÉDICO (DOBLE TALÓN):
 * Inyecta los datos clínicos mediante overlay vectorial directamente
 * sobre el PDF oficial inmutable /templates/recipe_base.pdf.
 * Toda la geometría en milímetros se obtiene exclusivamente desde recipeMaster.
 */
export async function createOfficialRecipePdf(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string },
  recipeData: { rxLeft?: string; indicationsRight?: string },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const pdfDoc = await loadBasePdf('recipe_base.pdf');
  const page = pdfDoc.getPages()[0];

  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);

  let requiresReview = false;
  const pageHeightMm = recipeMaster.pageSize.heightMm || 297;
  const leftTalon = recipeMaster.editableFields.left_talon;
  const rightTalon = recipeMaster.editableFields.right_talon;

  const safeName = (patient.fullName || '').toUpperCase();
  const safeId = patient.idNumber || '';
  const safeAge = patient.age !== undefined && patient.age !== null && patient.age !== '' ? `${patient.age}` : '';
  const safeDate = patient.date || new Date().toLocaleDateString('es-VE');

  // === TALÓN IZQUIERDO: CABECERA PACIENTE (FARMACIA) ===
  if (safeName) {
    page.drawText(safeName, {
      x: CalibrationEngine.xMmToPdfPt(leftTalon.patientFullName.xMm),
      y: CalibrationEngine.yMmToPdfPt(leftTalon.patientFullName.yMm, pageHeightMm),
      size: leftTalon.patientFullName.fontSizePt || 9.5,
      font: fontBold,
      maxWidth: CalibrationEngine.xMmToPdfPt(leftTalon.patientFullName.widthMm),
      color: rgb(0.1, 0.2, 0.35),
    });
  }

  if (safeId) {
    page.drawText(safeId, {
      x: CalibrationEngine.xMmToPdfPt(leftTalon.patientId.xMm),
      y: CalibrationEngine.yMmToPdfPt(leftTalon.patientId.yMm, pageHeightMm),
      size: leftTalon.patientId.fontSizePt || 9.5,
      font: fontBold,
      maxWidth: CalibrationEngine.xMmToPdfPt(leftTalon.patientId.widthMm),
      color: rgb(0.1, 0.2, 0.35),
    });
  }

  if (safeAge) {
    const ageFontSize = leftTalon.patientAge.fontSizePt || 9.5;
    const textWidth = fontBold.widthOfTextAtSize(safeAge, ageFontSize);
    const alignedX = CalibrationEngine.calculateAlignedXPt(
      leftTalon.patientAge.xMm,
      leftTalon.patientAge.widthMm,
      leftTalon.patientAge.align || 'center',
      textWidth
    );
    page.drawText(safeAge, {
      x: alignedX,
      y: CalibrationEngine.yMmToPdfPt(leftTalon.patientAge.yMm, pageHeightMm),
      size: ageFontSize,
      font: fontBold,
      maxWidth: CalibrationEngine.xMmToPdfPt(leftTalon.patientAge.widthMm),
      color: rgb(0.1, 0.2, 0.35),
    });
  }

  if (safeDate) {
    const dateFontSize = leftTalon.date.fontSizePt || 9.5;
    const textWidth = fontBold.widthOfTextAtSize(safeDate, dateFontSize);
    const alignedX = CalibrationEngine.calculateAlignedXPt(
      leftTalon.date.xMm,
      leftTalon.date.widthMm,
      leftTalon.date.align || 'center',
      textWidth
    );
    page.drawText(safeDate, {
      x: alignedX,
      y: CalibrationEngine.yMmToPdfPt(leftTalon.date.yMm, pageHeightMm),
      size: dateFontSize,
      font: fontBold,
      maxWidth: CalibrationEngine.xMmToPdfPt(leftTalon.date.widthMm),
      color: rgb(0.1, 0.2, 0.35),
    });
  }

  // === TALÓN DERECHO: CABECERA PACIENTE (INDICACIONES) ===
  if (safeName) {
    page.drawText(safeName, {
      x: CalibrationEngine.xMmToPdfPt(rightTalon.patientFullName.xMm),
      y: CalibrationEngine.yMmToPdfPt(rightTalon.patientFullName.yMm, pageHeightMm),
      size: rightTalon.patientFullName.fontSizePt || 9.5,
      font: fontBold,
      maxWidth: CalibrationEngine.xMmToPdfPt(rightTalon.patientFullName.widthMm),
      color: rgb(0.1, 0.2, 0.35),
    });
  }

  if (safeId) {
    page.drawText(safeId, {
      x: CalibrationEngine.xMmToPdfPt(rightTalon.patientId.xMm),
      y: CalibrationEngine.yMmToPdfPt(rightTalon.patientId.yMm, pageHeightMm),
      size: rightTalon.patientId.fontSizePt || 9.5,
      font: fontBold,
      maxWidth: CalibrationEngine.xMmToPdfPt(rightTalon.patientId.widthMm),
      color: rgb(0.1, 0.2, 0.35),
    });
  }

  if (safeAge) {
    const ageFontSize = rightTalon.patientAge.fontSizePt || 9.5;
    const textWidth = fontBold.widthOfTextAtSize(safeAge, ageFontSize);
    const alignedX = CalibrationEngine.calculateAlignedXPt(
      rightTalon.patientAge.xMm,
      rightTalon.patientAge.widthMm,
      rightTalon.patientAge.align || 'center',
      textWidth
    );
    page.drawText(safeAge, {
      x: alignedX,
      y: CalibrationEngine.yMmToPdfPt(rightTalon.patientAge.yMm, pageHeightMm),
      size: ageFontSize,
      font: fontBold,
      maxWidth: CalibrationEngine.xMmToPdfPt(rightTalon.patientAge.widthMm),
      color: rgb(0.1, 0.2, 0.35),
    });
  }

  if (safeDate) {
    const dateFontSize = rightTalon.date.fontSizePt || 9.5;
    const textWidth = fontBold.widthOfTextAtSize(safeDate, dateFontSize);
    const alignedX = CalibrationEngine.calculateAlignedXPt(
      rightTalon.date.xMm,
      rightTalon.date.widthMm,
      rightTalon.date.align || 'center',
      textWidth
    );
    page.drawText(safeDate, {
      x: alignedX,
      y: CalibrationEngine.yMmToPdfPt(rightTalon.date.yMm, pageHeightMm),
      size: dateFontSize,
      font: fontBold,
      maxWidth: CalibrationEngine.xMmToPdfPt(rightTalon.date.widthMm),
      color: rgb(0.1, 0.2, 0.35),
    });
  }

  // === CUERPO TALÓN IZQUIERDO: Rp. / Prescripción médica ===
  if (recipeData.rxLeft) {
    const rxShrink = CalibrationEngine.calculateShrinkFontSize(
      recipeData.rxLeft,
      leftTalon.rxBody.heightMm,
      leftTalon.rxBody.fontSizePt || 10.0,
      7.5
    );
    if (rxShrink.requiresReview) {
      requiresReview = true;
    }

    const calculatedLineHeight = Math.max(10, Math.round(rxShrink.fontSizePt * 1.4 * 10) / 10);
    page.drawText(recipeData.rxLeft, {
      x: CalibrationEngine.xMmToPdfPt(leftTalon.rxBody.xMm),
      y: CalibrationEngine.yMmToPdfPt(leftTalon.rxBody.yMm, pageHeightMm),
      size: rxShrink.fontSizePt,
      font: fontRegular,
      lineHeight: calculatedLineHeight,
      maxWidth: CalibrationEngine.xMmToPdfPt(leftTalon.rxBody.widthMm),
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  // === CUERPO TALÓN DERECHO: Indicaciones al Paciente ===
  if (recipeData.indicationsRight) {
    const indShrink = CalibrationEngine.calculateShrinkFontSize(
      recipeData.indicationsRight,
      rightTalon.indicationsBody.heightMm,
      rightTalon.indicationsBody.fontSizePt || 10.0,
      7.5
    );
    if (indShrink.requiresReview) {
      requiresReview = true;
    }

    const calculatedLineHeight = Math.max(10, Math.round(indShrink.fontSizePt * 1.4 * 10) / 10);
    page.drawText(recipeData.indicationsRight, {
      x: CalibrationEngine.xMmToPdfPt(rightTalon.indicationsBody.xMm),
      y: CalibrationEngine.yMmToPdfPt(rightTalon.indicationsBody.yMm, pageHeightMm),
      size: indShrink.fontSizePt,
      font: fontRegular,
      lineHeight: calculatedLineHeight,
      maxWidth: CalibrationEngine.xMmToPdfPt(rightTalon.indicationsBody.widthMm),
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  const pdfBytes = await pdfDoc.save();
  const fileName = customFileName || `Recipe_${(safeName || 'Paciente').replace(/\s+/g, '_')}.pdf`;
  const blob = new Blob([pdfBytes], { type: 'application/pdf' });
  const file = new File([blob], fileName, { type: 'application/pdf' });
  return { pdfBytes, blob, file, fileName, requiresReview };
}

export async function exportOfficialRecipePDF(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string },
  recipeData: { rxLeft?: string; indicationsRight?: string },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const result = await createOfficialRecipePdf(patient, recipeData, customFileName);
  downloadBlob(result.pdfBytes, result.fileName);
  return result;
}

// ----------------------------------------------------------------------------
// 4. INFORME MÉDICO OFICIAL (INYECCIÓN DIRECTA BASADA EN INFORME.MASTER)
// ----------------------------------------------------------------------------
/**
 * FUNCIÓN CANÓNICA INTERNA PARA INFORME MÉDICO:
 * Inyecta datos clínicos mediante overlay vectorial directamente sobre
 * el PDF oficial inmutable /templates/informe_base.pdf.
 * Toda la geometría en milímetros se obtiene exclusivamente desde informeMaster.
 */
export async function createOfficialInformePdf(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string },
  reportData: { content?: string; diagnosis?: string; bodyText?: string },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const pdfDoc = await loadBasePdf('informe_base.pdf');
  const page = pdfDoc.getPages()[0];

  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);

  let requiresReview = false;
  const pageHeightMm = informeMaster.pageSize.heightMm || 297;

  const safeName = (patient.fullName || '').toUpperCase();
  const safeId = patient.idNumber || '';
  const safeAge = patient.age ? (String(patient.age).toLowerCase().includes('año') ? String(patient.age) : `${patient.age} años`) : '';
  const safeDate = patient.date || new Date().toLocaleDateString('es-VE');

  const pHeader = informeMaster.editableFields.patientHeader;

  // Cabecera paciente: Fila 1 (Nombre y C.I.)
  if (safeName) {
    page.drawText(`${pHeader.fullName.labelPrefix || 'PACIENTE: '}${safeName}`, {
      x: CalibrationEngine.xMmToPdfPt(pHeader.fullName.xMm),
      y: CalibrationEngine.yMmToPdfPt(pHeader.fullName.yMm, pageHeightMm),
      size: pHeader.fullName.fontSizePt || 9.0,
      font: fontBold,
      color: rgb(0.06, 0.16, 0.3),
    });
  } else {
    requiresReview = true;
  }

  if (safeId) {
    page.drawText(`${pHeader.idNumber.labelPrefix || 'C.I.: '}${safeId}`, {
      x: CalibrationEngine.xMmToPdfPt(pHeader.idNumber.xMm),
      y: CalibrationEngine.yMmToPdfPt(pHeader.idNumber.yMm, pageHeightMm),
      size: pHeader.idNumber.fontSizePt || 9.0,
      font: fontBold,
      color: rgb(0.06, 0.16, 0.3),
    });
  }

  // Cabecera paciente: Fila 2 (Edad y Fecha)
  if (safeAge) {
    page.drawText(`${pHeader.age.labelPrefix || 'EDAD: '}${safeAge}`, {
      x: CalibrationEngine.xMmToPdfPt(pHeader.age.xMm),
      y: CalibrationEngine.yMmToPdfPt(pHeader.age.yMm, pageHeightMm),
      size: pHeader.age.fontSizePt || 9.0,
      font: fontBold,
      color: rgb(0.06, 0.16, 0.3),
    });
  }

  if (safeDate) {
    page.drawText(`${pHeader.date.labelPrefix || 'FECHA: '}${safeDate}`, {
      x: CalibrationEngine.xMmToPdfPt(pHeader.date.xMm),
      y: CalibrationEngine.yMmToPdfPt(pHeader.date.yMm, pageHeightMm),
      size: pHeader.date.fontSizePt || 9.0,
      font: fontBold,
      color: rgb(0.06, 0.16, 0.3),
    });
  }

  // Cuerpo del Informe con Shrink-to-fit
  const textToDraw = reportData.bodyText || reportData.content || reportData.diagnosis || '';
  const bodyField = informeMaster.editableFields.body.bodyText;

  if (textToDraw) {
    const shrink = CalibrationEngine.calculateShrinkFontSize(
      textToDraw,
      bodyField.heightMm,
      bodyField.fontSizePt || 9.5,
      7.5
    );
    if (shrink.requiresReview) {
      requiresReview = true;
    }
    const calculatedLineHeight = Math.max(10, Math.round(shrink.fontSizePt * 1.55 * 10) / 10);
    page.drawText(textToDraw, {
      x: CalibrationEngine.xMmToPdfPt(bodyField.xMm),
      y: CalibrationEngine.yMmToPdfPt(bodyField.yMm, pageHeightMm),
      size: shrink.fontSizePt,
      font: fontRegular,
      lineHeight: calculatedLineHeight,
      maxWidth: CalibrationEngine.xMmToPdfPt(bodyField.widthMm),
      color: rgb(0.1, 0.1, 0.1),
    });
  } else {
    requiresReview = true;
  }

  const pdfBytes = await pdfDoc.save();
  const fileName = customFileName || `Informe_${(safeName || 'Paciente').replace(/\s+/g, '_')}.pdf`;
  const blob = new Blob([pdfBytes], { type: 'application/pdf' });
  const file = new File([blob], fileName, { type: 'application/pdf' });
  return { pdfBytes, blob, file, fileName, requiresReview };
}

export async function exportOfficialInformePDF(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string },
  reportData: { content?: string; diagnosis?: string; bodyText?: string },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const result = await createOfficialInformePdf(patient, reportData, customFileName);
  downloadBlob(result.pdfBytes, result.fileName);
  return result;
}

// ----------------------------------------------------------------------------
// 5. CONSTANCIA MÉDICA DE REPOSO (INYECCIÓN DIRECTA BASADA EN CONSTANCIA.MASTER)
// ----------------------------------------------------------------------------
/**
 * FUNCIÓN CANÓNICA INTERNA PARA CONSTANCIA MÉDICA DE REPOSO:
 * Inyecta datos clínicos mediante overlay vectorial directamente sobre
 * el PDF oficial inmutable /templates/constancia_base.pdf.
 * Toda la geometría en milímetros se obtiene exclusivamente desde constanciaMaster.
 */
export async function createOfficialConstanciaPdf(
  patient: { fullName?: string; idNumber?: string; date?: string; guideNumber?: string; condition?: string },
  certificateData: {
    restDays?: string | number;
    diagnosis?: string;
    idx?: string;
    condition?: string;
    needsRest?: boolean;
    attendedDate?: string;
    restFrom?: string;
    restTo?: string;
    requestDay?: string;
    requestMonth?: string;
    requestYear?: string;
  },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const pdfDoc = await loadBasePdf('constancia_base.pdf');
  const page = pdfDoc.getPages()[0];

  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);

  let requiresReview = false;
  const pageHeightMm = constanciaMaster.pageSize.heightMm || 297;

  const safeName = (patient.fullName || '').toUpperCase();
  const safeId = patient.idNumber || '';
  const safeDate = patient.date || new Date().toLocaleDateString('es-VE');
  const safeGuide = patient.guideNumber || 'ING-2026-0842';
  const cond = (certificateData.condition || patient.condition || 'Paciente').toUpperCase();
  const isPaciente = cond === 'PACIENTE';
  const isFamiliar = cond === 'FAMILIAR';
  const needsRest = typeof certificateData.needsRest === 'boolean' ? certificateData.needsRest : (Number(certificateData.restDays) > 0);
  const safeDays = String(certificateData.restDays || (needsRest ? '7' : '0'));
  const attendedDate = certificateData.attendedDate || safeDate;

  const fields = constanciaMaster.editableFields;

  // Título central
  if (fields.title && fields.title.text) {
    const titleFontSize = fields.title.fontSizePt || 13.0;
    const titleWidth = fontBold.widthOfTextAtSize(fields.title.text, titleFontSize);
    const alignedTitleX = CalibrationEngine.calculateAlignedXPt(
      fields.title.xMm,
      fields.title.widthMm,
      fields.title.align || 'center',
      titleWidth
    );
    page.drawText(fields.title.text, {
      x: alignedTitleX,
      y: CalibrationEngine.yMmToPdfPt(fields.title.yMm, pageHeightMm),
      size: titleFontSize,
      font: fontBold,
      color: rgb(0.04, 0.22, 0.43),
    });
  }

  // Ciudadano(a)
  if (safeName) {
    page.drawText(`${fields.patientHeader.fullName.labelPrefix || 'CIUDADANO(A): '}${safeName}`, {
      x: CalibrationEngine.xMmToPdfPt(fields.patientHeader.fullName.xMm),
      y: CalibrationEngine.yMmToPdfPt(fields.patientHeader.fullName.yMm, pageHeightMm),
      size: fields.patientHeader.fullName.fontSizePt || 9.5,
      font: fontBold,
      color: rgb(0.06, 0.16, 0.3),
    });
  } else {
    requiresReview = true;
  }

  // Cédula de Identidad
  if (safeId) {
    page.drawText(`${fields.patientHeader.idNumber.labelPrefix || 'CÉDULA DE IDENTIDAD: '}${safeId}`, {
      x: CalibrationEngine.xMmToPdfPt(fields.patientHeader.idNumber.xMm),
      y: CalibrationEngine.yMmToPdfPt(fields.patientHeader.idNumber.yMm, pageHeightMm),
      size: fields.patientHeader.idNumber.fontSizePt || 9.5,
      font: fontBold,
      color: rgb(0.06, 0.16, 0.3),
    });
  }

  // Fecha Emisión
  if (safeDate) {
    page.drawText(`${fields.patientHeader.date.labelPrefix || 'FECHA EMISIÓN: '}${safeDate}`, {
      x: CalibrationEngine.xMmToPdfPt(fields.patientHeader.date.xMm),
      y: CalibrationEngine.yMmToPdfPt(fields.patientHeader.date.yMm, pageHeightMm),
      size: fields.patientHeader.date.fontSizePt || 9.0,
      font: fontBold,
      color: rgb(0.06, 0.16, 0.3),
    });
  }

  // Guía Ingreso
  if (safeGuide) {
    page.drawText(`${fields.patientHeader.guideNumber.labelPrefix || 'GUÍA INGRESO: '}${safeGuide}`, {
      x: CalibrationEngine.xMmToPdfPt(fields.patientHeader.guideNumber.xMm),
      y: CalibrationEngine.yMmToPdfPt(fields.patientHeader.guideNumber.yMm, pageHeightMm),
      size: fields.patientHeader.guideNumber.fontSizePt || 9.0,
      font: fontBold,
      color: rgb(0.06, 0.16, 0.3),
    });
  }

  // Condición [X] PACIENTE   [ ] FAMILIAR
  page.drawText(`CONDICIÓN: [${isPaciente ? 'X' : ' '}] PACIENTE    [${isFamiliar ? 'X' : ' '}] FAMILIAR`, {
    x: CalibrationEngine.xMmToPdfPt(fields.patientHeader.condition.xMm),
    y: CalibrationEngine.yMmToPdfPt(fields.patientHeader.condition.yMm, pageHeightMm),
    size: fields.patientHeader.condition.fontSizePt || 9.0,
    font: fontBold,
    color: rgb(0.06, 0.16, 0.3),
  });

  // Asistencia a Consulta
  page.drawText(`Asistió a la consulta médica especializada el día: ${attendedDate}`, {
    x: CalibrationEngine.xMmToPdfPt(fields.attendance.xMm),
    y: CalibrationEngine.yMmToPdfPt(fields.attendance.yMm, pageHeightMm),
    size: fields.attendance.fontSizePt || 9.5,
    font: fontBold,
    color: rgb(0.1, 0.1, 0.1),
  });

  // Pregunta reposo
  page.drawText(fields.reposoQuestion.text || '¿Amerita reposo médico domiciliario?', {
    x: CalibrationEngine.xMmToPdfPt(fields.reposoQuestion.xMm),
    y: CalibrationEngine.yMmToPdfPt(fields.reposoQuestion.yMm, pageHeightMm),
    size: fields.reposoQuestion.fontSizePt || 9.5,
    font: fontBold,
    color: rgb(0.06, 0.16, 0.3),
  });

  // Respuestas [X] SÍ AMERITA   [ ] NO AMERITA
  page.drawText(`[${needsRest ? 'X' : ' '}] SÍ AMERITA         [${!needsRest ? 'X' : ' '}] NO AMERITA`, {
    x: CalibrationEngine.xMmToPdfPt(fields.reposoAnswers.xMm),
    y: CalibrationEngine.yMmToPdfPt(fields.reposoAnswers.yMm, pageHeightMm),
    size: fields.reposoAnswers.fontSizePt || 9.5,
    font: fontBold,
    color: rgb(0.06, 0.16, 0.3),
  });

  // Cláusula de reposo
  if (needsRest) {
    const restFrom = certificateData.restFrom || safeDate;
    const restTo = certificateData.restTo || safeDate;
    const line1 = `Por presentar cuadro clínico que requiere reposo médico continuo por ${safeDays} DÍAS continuos.`;
    const line2 = `Comprendido desde el ${restFrom} hasta el ${restTo} (ambas fechas inclusive).`;
    page.drawText(line1, {
      x: CalibrationEngine.xMmToPdfPt(fields.restClause.xMm),
      y: CalibrationEngine.yMmToPdfPt(fields.restClause.yMm, pageHeightMm),
      size: fields.restClause.fontSizePt || 9.0,
      font: fontRegular,
      color: rgb(0.1, 0.1, 0.1),
    });
    page.drawText(line2, {
      x: CalibrationEngine.xMmToPdfPt(fields.restClause.xMm),
      y: CalibrationEngine.yMmToPdfPt(fields.restClause.yMm + 5.0, pageHeightMm),
      size: fields.restClause.fontSizePt || 9.0,
      font: fontRegular,
      color: rgb(0.1, 0.1, 0.1),
    });
  } else {
    page.drawText('El/la paciente no amerita reposo médico. Se encuentra facultado(a) para sus labores habituales.', {
      x: CalibrationEngine.xMmToPdfPt(fields.restClause.xMm),
      y: CalibrationEngine.yMmToPdfPt(fields.restClause.yMm, pageHeightMm),
      size: fields.restClause.fontSizePt || 9.0,
      font: fontRegular,
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  // Diagnóstico / Impresión Clínica con Shrink-to-fit
  const diag = certificateData.idx || certificateData.diagnosis;
  if (diag) {
    page.drawText(fields.diagnosisHeader.text || 'DIAGNÓSTICO / IMPRESIÓN CLÍNICA (CIE-10):', {
      x: CalibrationEngine.xMmToPdfPt(fields.diagnosisHeader.xMm),
      y: CalibrationEngine.yMmToPdfPt(fields.diagnosisHeader.yMm, pageHeightMm),
      size: fields.diagnosisHeader.fontSizePt || 9.0,
      font: fontBold,
      color: rgb(0.06, 0.16, 0.3),
    });

    const shrink = CalibrationEngine.calculateShrinkFontSize(
      diag,
      fields.diagnosis.heightMm,
      fields.diagnosis.fontSizePt || 9.0,
      7.5
    );
    if (shrink.requiresReview) {
      requiresReview = true;
    }
    const calculatedLineHeight = Math.max(10, Math.round(shrink.fontSizePt * 1.5 * 10) / 10);
    page.drawText(diag, {
      x: CalibrationEngine.xMmToPdfPt(fields.diagnosis.xMm),
      y: CalibrationEngine.yMmToPdfPt(fields.diagnosis.yMm, pageHeightMm),
      size: shrink.fontSizePt,
      font: fontRegular,
      lineHeight: calculatedLineHeight,
      maxWidth: CalibrationEngine.xMmToPdfPt(fields.diagnosis.widthMm),
      color: rgb(0.1, 0.1, 0.1),
    });
  }

  // Cláusula de expedición
  const d = new Date();
  const months = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const expDay = certificateData.requestDay || String(d.getDate());
  const expMonth = certificateData.requestMonth || months[d.getMonth()];
  const expYear = certificateData.requestYear || String(d.getFullYear());
  const expText = `Se expide a solicitud de la parte interesada en Puerto Ordaz, a los ${expDay} días de ${expMonth} de ${expYear}.`;

  page.drawText(expText, {
    x: CalibrationEngine.xMmToPdfPt(fields.expeditionClause.xMm),
    y: CalibrationEngine.yMmToPdfPt(fields.expeditionClause.yMm, pageHeightMm),
    size: fields.expeditionClause.fontSizePt || 8.5,
    font: fontRegular,
    color: rgb(0.2, 0.2, 0.2),
  });

  const pdfBytes = await pdfDoc.save();
  const fileName = customFileName || `Constancia_Reposo_${(safeName || 'Paciente').replace(/\s+/g, '_')}.pdf`;
  const blob = new Blob([pdfBytes], { type: 'application/pdf' });
  const file = new File([blob], fileName, { type: 'application/pdf' });
  return { pdfBytes, blob, file, fileName, requiresReview };
}

export async function exportOfficialConstanciaPDF(
  patient: { fullName?: string; idNumber?: string; date?: string; guideNumber?: string; condition?: string },
  certificateData: {
    restDays?: string | number;
    diagnosis?: string;
    idx?: string;
    condition?: string;
    needsRest?: boolean;
    attendedDate?: string;
    restFrom?: string;
    restTo?: string;
    requestDay?: string;
    requestMonth?: string;
    requestYear?: string;
  },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  const result = await createOfficialConstanciaPdf(patient, certificateData, customFileName);
  downloadBlob(result.pdfBytes, result.fileName);
  return result;
}

// ----------------------------------------------------------------------------
// DISPATCHER CANÓNICO UNIFICADO (ÚNICA FUENTE DE VERDAD PARA TODOS LOS CANALES)
// ----------------------------------------------------------------------------
export interface ClinicalDataBundle {
  recipeData?: { pharmacy?: string; patientIndications?: string; rxLeft?: string; indicationsRight?: string };
  labData?: {
    labTests?: Record<string, boolean> | string[];
    neuroimagingTests?: Record<string, boolean> | string[];
    neuroimagingDetails?: Record<string, string>;
    presumptiveDx?: string;
    otherExams?: string;
  };
  informeData?: { bodyText?: string };
  constanciaData?: {
    restDays?: string | number;
    diagnosis?: string;
    idx?: string;
    condition?: string;
    needsRest?: boolean;
    attendedDate?: string;
    restFrom?: string;
    restTo?: string;
    requestDay?: string;
    requestMonth?: string;
    requestYear?: string;
  };
  historiaData?: {
    motivo?: string;
    motivoConsulta?: string;
    enfermedadActual?: string;
    antecedentes?: string;
    neuroExam?: string;
    examenNeurologico?: string;
    dx?: string;
    diagnostico?: string;
  };
}

/**
 * GENERADOR CANÓNICO ÚNICO:
 * Punto de entrada centralizado para Descarga, Previsualización y WhatsApp.
 * Garantiza de forma innegociable que TODO documento oficial emitido por cualquier canal
 * provenga exclusivamente de: PDF ORIGINAL INMUTABLE + OVERLAY VECTORIAL = PDF FINAL.
 */
export async function generateCanonicalDocumentPDF(
  docKey: DocType,
  patient: PatientData,
  bundle: ClinicalDataBundle,
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  switch (docKey) {
    case 'RECIPES':
      return await createOfficialRecipePdf(
        {
          fullName: patient.fullName,
          idNumber: patient.idNumber,
          age: patient.age,
          date: patient.date,
        },
        {
          rxLeft: bundle.recipeData?.rxLeft || bundle.recipeData?.pharmacy,
          indicationsRight: bundle.recipeData?.indicationsRight || bundle.recipeData?.patientIndications,
        },
        customFileName
      );

    case 'ORDEN_LAB':
      return await createOfficialLabOrderPdf(
        {
          fullName: patient.fullName,
          idNumber: patient.idNumber,
          age: patient.age,
          date: patient.date,
        },
        {
          labTests: bundle.labData?.labTests || [],
          neuroimagingTests: bundle.labData?.neuroimagingTests,
          neuroimagingDetails: bundle.labData?.neuroimagingDetails,
          otherExams: bundle.labData?.otherExams || '',
        },
        bundle.labData?.presumptiveDx || '',
        customFileName
      );

    case 'INFORME':
      return await createOfficialInformePdf(
        {
          fullName: patient.fullName,
          idNumber: patient.idNumber,
          age: patient.age,
          date: patient.date,
        },
        {
          bodyText: bundle.informeData?.bodyText,
        },
        customFileName
      );

    case 'CONSTANCIA':
      return await createOfficialConstanciaPdf(
        {
          fullName: patient.fullName,
          idNumber: patient.idNumber,
          date: patient.date,
          guideNumber: patient.guideNumber,
          condition: bundle.constanciaData?.condition || patient.condition,
        },
        {
          restDays: bundle.constanciaData?.restDays,
          diagnosis: bundle.constanciaData?.diagnosis || bundle.constanciaData?.idx,
          idx: bundle.constanciaData?.idx || bundle.constanciaData?.diagnosis,
          condition: bundle.constanciaData?.condition || patient.condition,
          needsRest: bundle.constanciaData?.needsRest,
          attendedDate: bundle.constanciaData?.attendedDate,
          restFrom: bundle.constanciaData?.restFrom,
          restTo: bundle.constanciaData?.restTo,
          requestDay: bundle.constanciaData?.requestDay,
          requestMonth: bundle.constanciaData?.requestMonth,
          requestYear: bundle.constanciaData?.requestYear,
        },
        customFileName
      );

    case 'HISTORIA':
      return await createOfficialHistoriaPdf(
        {
          fullName: patient.fullName,
          idNumber: patient.idNumber,
          age: patient.age,
          phone: patient.phone,
          address: patient.address,
          date: patient.date,
        },
        {
          motivoConsulta: bundle.historiaData?.motivoConsulta || bundle.historiaData?.motivo,
          enfermedadActual: bundle.historiaData?.enfermedadActual,
          antecedentes: bundle.historiaData?.antecedentes,
          examenNeurologico: bundle.historiaData?.examenNeurologico || bundle.historiaData?.neuroExam,
          diagnostico: bundle.historiaData?.diagnostico || bundle.historiaData?.dx,
        },
        customFileName
      );

    default:
      throw new Error(`Tipo de documento clínico oficial desconocido: ${docKey}`);
  }
}

/**
 * GENERADOR OFICIAL DE RÉCIPE MÉDICO (DELEGADO A createOfficialRecipePdf):
 * Mantiene compatibilidad total con invocadores que requieren los bytes/blob
 * del récipe sin forzar la descarga automática en el navegador.
 */
export async function generateOfficialRecipePDF(
  patient: { fullName?: string; idNumber?: string; age?: string | number; date?: string },
  recipeData: { rxLeft?: string; indicationsRight?: string },
  customFileName?: string
): Promise<{ pdfBytes: Uint8Array; blob: Blob; file: File; fileName: string; requiresReview?: boolean }> {
  return await createOfficialRecipePdf(patient, recipeData, customFileName);
}

/**
 * EXPORTACIÓN WYSIWYG EXACTA A4 (300 DPI):
 * Captura el contenedor visible en pantalla con la plantilla física de fondo
 * y los textos/inputs transparentes sobre ella, garantizando fidelidad 1:1 absoluta.
 */
/**
 * @deprecated ARQUITECTURA LEGACY (RASTERIZADO DOM):
 * Esta función utiliza html2canvas para rasterizar el DOM del navegador.
 * PROHIBIDO su uso para la emisión de documentos oficiales en Arquitectura V2.
 * Los documentos oficiales deben generarse exclusivamente con la ruta canónica
 * PDF ORIGINAL + VECTOR OVERLAY (CanonicalDocumentGeneratorV2 / PDFDocumentPipelineV2).
 * Se mantiene temporalmente solo para compatibilidad retrospectiva si alguna vista antigua lo invoca.
 */
export async function exportElementToExactA4PDF(
  elementId: string,
  filename: string
): Promise<{ pdf: jsPDF; blob: Blob; file: File; success: boolean }> {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error(`Elemento #${elementId} no encontrado en el DOM.`);
    throw new Error(`Elemento #${elementId} no encontrado en el DOM.`);
  }

  // Captura el contenedor exactamente como se ve (plantilla de fondo + texto encima)
  const canvas = await html2canvas(element, {
    scale: 3, // 300 DPI de resolución médica
    useCORS: true,
    allowTaint: true,
    backgroundColor: '#ffffff',
    logging: false,
    windowWidth: 794,
    windowHeight: 1123,
    onclone: (clonedDoc) => {
      const clonedContainer = clonedDoc.getElementById(elementId);
      if (!clonedContainer) return;

      clonedContainer.style.width = '794px';
      clonedContainer.style.minHeight = '1123px';
      clonedContainer.style.maxHeight = '1123px';
      clonedContainer.style.height = '1123px';

      // Preservar exactamente los valores de inputs como divs con estilos calculados
      const inputs = clonedContainer.querySelectorAll<HTMLInputElement>('input');
      inputs.forEach((input) => {
        const div = clonedDoc.createElement('div');
        const comp = window.getComputedStyle(input);
        div.textContent = input.value || input.placeholder || '';
        div.className = input.className;
        div.style.fontFamily = comp.fontFamily;
        div.style.fontSize = comp.fontSize;
        div.style.fontWeight = comp.fontWeight;
        div.style.lineHeight = comp.lineHeight;
        div.style.textAlign = comp.textAlign;
        div.style.color = comp.color;
        div.style.backgroundColor = 'transparent';
        div.style.borderRadius = comp.borderRadius;
        div.style.border = 'none';
        div.style.padding = comp.padding;
        div.style.width = comp.width;
        div.style.height = comp.height;
        div.style.display = 'inline-flex';
        div.style.alignItems = 'center';
        div.style.boxSizing = 'border-box';
        div.style.boxShadow = 'none';
        div.style.outline = 'none';
        input.parentNode?.replaceChild(div, input);
      });

      // Preservar textareas manteniendo saltos de línea y espaciados
      const textareas = clonedContainer.querySelectorAll<HTMLTextAreaElement>('textarea');
      textareas.forEach((ta) => {
        const div = clonedDoc.createElement('div');
        const comp = window.getComputedStyle(ta);
        div.textContent = ta.value || ta.placeholder || '';
        div.className = ta.className;
        div.style.fontFamily = comp.fontFamily;
        div.style.fontSize = comp.fontSize;
        div.style.fontWeight = comp.fontWeight;
        div.style.lineHeight = comp.lineHeight;
        div.style.textAlign = comp.textAlign;
        div.style.color = comp.color;
        div.style.backgroundColor = 'transparent';
        div.style.border = 'none';
        div.style.borderRadius = comp.borderRadius;
        div.style.padding = comp.padding;
        div.style.whiteSpace = 'pre-wrap';
        div.style.wordBreak = 'break-word';
        div.style.minHeight = comp.height;
        div.style.boxSizing = 'border-box';
        div.style.boxShadow = 'none';
        div.style.outline = 'none';
        ta.parentNode?.replaceChild(div, ta);
      });
    },
  });

  const imgData = canvas.toDataURL('image/jpeg', 0.98);

  // Hoja estándar A4: 210mm x 297mm
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  pdf.addImage(imgData, 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
  pdf.save(filename);

  const blob = pdf.output('blob');
  const file = new File([blob], filename, { type: 'application/pdf' });

  return { pdf, blob, file, success: true };
}

/**
 * Captura directa del contenedor A4 oficial con la plantilla original de fondo
 * ejecutando html2canvas a 300 DPI y jsPDF en formato A4 retrato (210mm x 297mm).
 * Sustituye completamente cualquier generador antiguo de texto plano en blanco y negro.
 */
/**
 * @deprecated ARQUITECTURA LEGACY (RASTERIZADO DOM):
 * Utiliza html2canvas para rasterizar el DOM del navegador.
 * PROHIBIDO para la emisión de documentos oficiales en Arquitectura V2.
 */
export const exportOfficialSheetToPDF = async (
  containerId: string,
  filename: string
): Promise<{ pdf: jsPDF; success: boolean }> => {
  const element = document.getElementById(containerId);
  if (!element) {
    console.error(`Contenedor #${containerId} no encontrado.`);
    throw new Error(`Contenedor #${containerId} no encontrado.`);
  }

  // Captura el contenedor exactamente como se ve en pantalla (fondo original + texto encima)
  const canvas = await html2canvas(element, {
    scale: 3, // Alta resolución 300 DPI
    useCORS: true,
    allowTaint: true,
    backgroundColor: null,
    logging: false,
    windowWidth: 794,
    windowHeight: 1123,
  });

  const imgData = canvas.toDataURL('image/jpeg', 0.98);
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  pdf.addImage(imgData, 'JPEG', 0, 0, 210, 297, undefined, 'FAST');
  pdf.save(filename);
  return { pdf, success: true };
};

/**
 * Enviar PDF por WhatsApp:
 * 1. Usa Web Share API nativo si el dispositivo soporta adjuntar archivos (Android/iOS y navegadores modernos).
 * 2. Si no soporta compartir archivos por API nativa, descarga automáticamente el PDF y abre el chat de WhatsApp con mensaje formal.
 */
export async function sharePdfToWhatsApp(options: {
  file: File;
  fileName: string;
  phoneNumber?: string;
  messageText: string;
}): Promise<{ method: 'native-share' | 'download-and-whatsapp'; success: boolean }> {
  const { file, fileName, phoneNumber, messageText } = options;

  // Intento 1: Web Share API con archivo adjunto directo
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try {
      await navigator.share({
        title: fileName,
        text: messageText,
        files: [file],
      });
      return { method: 'native-share', success: true };
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // El usuario cerró el diálogo de compartir
        return { method: 'native-share', success: false };
      }
      console.warn('Web Share API falló, activando flujo de descarga + WhatsApp Web/App:', err);
    }
  }

  // Intento 2: Descarga automática inmediata del PDF en el dispositivo
  const url = URL.createObjectURL(file);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 10000);

  // Abrir WhatsApp con el número del paciente y el mensaje estructurado
  const cleanPhone = formatWhatsAppPhone(phoneNumber || '');
  const encodedMsg = encodeURIComponent(messageText);
  const waUrl = cleanPhone
    ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedMsg}`
    : `https://api.whatsapp.com/send?text=${encodedMsg}`;

  window.open(waUrl, '_blank');

  return { method: 'download-and-whatsapp', success: true };
}

/**
 * Genera el mensaje médico profesional para WhatsApp
 */
export function buildWhatsAppMessage(
  docTitles: string[],
  patientName: string,
  patientId: string,
  date: string
): string {
  let msg = `*INSTITUTO DE CIRUGÍA DE COLUMNA MÍNIMAMENTE INVASIVA (CCMI)*\n`;
  msg += `*DR. SAMIR MOUCHARRAFIE NAIME*\n`;
  msg += `Especialista en Neurocirugía (UCBL Lyon 1 - Francia)\n`;
  msg += `MPPS: 61231 | CMEB: 5331\n\n`;
  msg += `Estimado(a) paciente *${patientName || 'Paciente'}* (C.I. ${patientId || 'N/A'}),\n\n`;

  if (docTitles.length === 1) {
    msg += `Le hacemos entrega de su *${docTitles[0]}* en formato PDF oficial.\n`;
  } else {
    msg += `Le hacemos entrega de sus *${docTitles.length} documentos médicos oficiales* en formato PDF:\n`;
    docTitles.forEach((t, idx) => {
      msg += `• ${idx + 1}. *${t}*\n`;
    });
  }

  msg += `\n📅 *Fecha de Emisión:* ${date || new Date().toLocaleDateString('es-VE')}\n`;
  msg += `📍 *Sede:* Puerto Ordaz, Edo. Bolívar\n`;
  msg += `📞 *Contacto CCMI:* 0424-938.16.74 | cerebro.columna.mi@gmail.com\n\n`;
  msg += `_Documento médico oficial emitido sobre papelería institucional del especialista._`;

  return msg;
}

// ----------------------------------------------------------------------------
// ARQUITECTURA V2: RE-EXPORTACIONES COMPATIBLES Y EXTENSIBLES
// ----------------------------------------------------------------------------
export { PDFDocumentPipelineV2 } from './PDFDocumentPipelineV2';
export type { DocumentPipelineRequest, DocumentPipelineResponse } from './PDFDocumentPipelineV2';
