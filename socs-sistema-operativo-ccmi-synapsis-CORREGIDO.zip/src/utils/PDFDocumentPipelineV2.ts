/**
 * PDFDocumentPipelineV2.ts
 * 
 * PIPELINE UNIVERSAL DE GENERACIÓN DE DOCUMENTOS MÉDICOS (ARQUITECTURA V2)
 * =======================================================================
 * Flujo estricto:
 * 1. PDF MAESTRO ORIGINAL (Background inmutable de /public/templates/*.pdf)
 * 2. MASTER TEMPLATE V2 (Esquema físico canónico en mm de /src/calibration/MasterRegistryV2)
 * 3. MAPEO SEMÁNTICO (Data de paciente y clínica estructurada a notación de puntos)
 * 4. OVERLAY VECTORIAL PURO (pdf-lib, inyección directa sin rasterizar)
 * 5. VALIDACIÓN Y AUDITORÍA (Verificación de desbordamiento, colisiones y campos)
 * 6. SALIDA COMPLETA (Uint8Array, Blob, File, descarga o distribución directa)
 */

import { PDFDocument } from 'pdf-lib';
import { getMasterTemplateV2, MasterTemplateV2 } from '../calibration/MasterRegistryV2';
import { TemplateRegistry } from '../calibration/TemplateRegistry';
import { VectorOverlayEngineV2, OverlayRenderResult } from '../calibration/VectorOverlayEngineV2';
import { SemanticDataMapperV2, ClinicalWorkspaceContext } from '../calibration/SemanticDataMapperV2';
import { downloadBlob, formatWhatsAppPhone, buildWhatsAppMessage, sharePdfToWhatsApp } from './pdfExport';
import { getCustomTemplateOriginalPdf } from './templateStorage';

export interface DocumentPipelineRequest {
  documentType: string; // 'recipe' | 'certificate' | 'report' | 'history' | 'lab_order' o cualquier tipo maestro
  context: ClinicalWorkspaceContext;
  customFileName?: string;
  doctorStampBase64?: string;
  template?: MasterTemplateV2;
  templateBytes?: Uint8Array;
}

export interface DocumentPipelineResponse {
  pdfBytes: Uint8Array;
  blob: Blob;
  file: File;
  fileName: string;
  template: MasterTemplateV2;
  requiresReview: boolean;
  warnings: string[];
  injectedCount: number;
}

export class PDFDocumentPipelineV2 {
  /**
   * Carga el buffer del PDF base inmutable.
   * Prioridad 1: Si el usuario cargó un PDF original oficial en IndexedDB con dimensiones válidas, usa ese buffer.
   * Prioridad 2: Ruta estática en /templates/*.pdf
   */
  private static async loadOriginalPdf(path: string, documentType?: string): Promise<Uint8Array> {
    if (documentType) {
      try {
        const storedPdf = await getCustomTemplateOriginalPdf(documentType);
        if (storedPdf && storedPdf.length > 0) {
          // Validar dimensiones antes de aceptar el PDF de IndexedDB
          try {
            const pdfDoc = await PDFDocument.load(storedPdf, { ignoreEncryption: true });
            if (pdfDoc.getPageCount() > 0) {
              const p0 = pdfDoc.getPage(0);
              const wMm = (p0.getWidth() * 25.4) / 72;
              const hMm = (p0.getHeight() * 25.4) / 72;
              if (documentType === 'lab_order' && (wMm > 180 || hMm > 260)) {
                console.warn(
                  `[PDFDocumentPipelineV2] El PDF en IndexedDB para 'lab_order' tiene dimensiones A4 (${wMm.toFixed(1)} × ${hMm.toFixed(1)} mm). Se invalida para el pipeline oficial y se requiere el Master físico original Media Carta (153.5 × 215.8 mm).`
                );
              } else {
                return storedPdf;
              }
            }
          } catch (e) {
            console.warn(`[PDFDocumentPipelineV2] Error validando PDF de IndexedDB para ${documentType}:`, e);
          }
        }
      } catch (err) {
        console.warn(`[PDFDocumentPipelineV2] Error leyendo PDF original de IndexedDB para ${documentType}:`, err);
      }
    }

    const cleanPath = path.startsWith('/') ? path : `/${path}`;
    
    // Fallback para entornos SSR / CLI / Node.js
    if (typeof window === 'undefined') {
      try {
        const fs = await import('fs');
        const nodePath = await import('path');
        const localFilePath = nodePath.join(process.cwd(), 'public', cleanPath.replace(/^\//, ''));
        if (fs.existsSync(localFilePath)) {
          return new Uint8Array(fs.readFileSync(localFilePath));
        }
      } catch {
        // Seguir con fetch
      }
    }

    const response = await fetch(cleanPath);
    if (!response.ok) {
      throw new Error(`No se pudo cargar el PDF maestro original desde ${cleanPath} (HTTP ${response.status})`);
    }
    const arrayBuffer = await response.arrayBuffer();
    return new Uint8Array(arrayBuffer);
  }

  /**
   * Genera el documento PDF final utilizando la Arquitectura V2 completa
   */
  public static async generateDocument(request: DocumentPipelineRequest): Promise<DocumentPipelineResponse> {
    const template = request.template || getMasterTemplateV2(request.documentType) || TemplateRegistry.get(request.documentType);
    if (!template) {
      throw new Error(`No existe un MasterTemplateV2 registrado para el tipo '${request.documentType}'`);
    }

    // 1. Cargar el PDF maestro original (Bytes directos, IndexedDB o ruta estática)
    const originalPdfBytes = request.templateBytes || (await this.loadOriginalPdf(template.source.backgroundPdf, request.documentType));

    // 2. Mapear datos semánticos del paciente
    const semanticDictionary = SemanticDataMapperV2.mapToSemanticDictionary(request.context);

    // 3. Aplicar Overlay Vectorial con protección y autoajuste
    const renderResult: OverlayRenderResult = await VectorOverlayEngineV2.applyOverlay(
      originalPdfBytes,
      template,
      semanticDictionary,
      {
        doctorStampBase64: request.doctorStampBase64 || request.context.doctorStampBase64,
      }
    );

    // 4. Construir Blob y File
    const patientNameSafe = (semanticDictionary.patient.fullName || 'Paciente')
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 30);
    const dateSafe = (semanticDictionary.document.date || '').replace(/[\/\\]/g, '-');
    const defaultFileName = `${template.documentType.toUpperCase()}_${patientNameSafe}_${dateSafe || 'doc'}.pdf`;
    const finalFileName = request.customFileName || defaultFileName;

    const blob = new Blob([renderResult.pdfBytes], { type: 'application/pdf' });
    const file = new File([blob], finalFileName, { type: 'application/pdf' });

    return {
      pdfBytes: renderResult.pdfBytes,
      blob,
      file,
      fileName: finalFileName,
      template,
      requiresReview: renderResult.requiresReview,
      warnings: renderResult.warnings,
      injectedCount: renderResult.injectedElementsCount,
    };
  }

  /**
   * Genera y descarga directamente el documento PDF
   */
  public static async generateAndDownload(request: DocumentPipelineRequest): Promise<DocumentPipelineResponse> {
    const response = await this.generateDocument(request);
    downloadBlob(response.pdfBytes, response.fileName);
    return response;
  }

  /**
   * Genera y prepara el documento para envío por WhatsApp y descarga
   */
  public static async generateAndShareWhatsApp(
    request: DocumentPipelineRequest,
    targetPhone?: string
  ): Promise<{ pipelineResponse: DocumentPipelineResponse; shareResult: any }> {
    const pipelineResponse = await this.generateDocument(request);
    const semanticData = SemanticDataMapperV2.mapToSemanticDictionary(request.context);

    const docName = pipelineResponse.template.metadata?.name || pipelineResponse.template.documentType;
    const msg = buildWhatsAppMessage(
      [docName],
      semanticData.patient.fullName,
      semanticData.patient.idNumber,
      semanticData.document.date
    );

    const shareResult = await sharePdfToWhatsApp({
      file: pipelineResponse.file,
      fileName: pipelineResponse.fileName,
      phoneNumber: targetPhone || semanticData.patient.phone || '',
      messageText: msg,
    });

    return { pipelineResponse, shareResult };
  }
}
